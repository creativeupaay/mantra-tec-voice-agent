[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Products](https://www.mantratec.com/Products) Access Control

# Access Control

Access control system is designed to control the access of personnel into an Organization by the process of authorization. The Biometric access control system provides a convenient and quick access to an authorized person.

[Get In Touch](https://www.mantratec.com/Products-Inquiry-Form)

UIDAI Approved STQC Certified Real-time Sync

![Access Control Device](https://www.mantratec.com/Assets/Images/Pages/Products/Products_banner/Access-Control_Second_Section.png)

## Our Access Control

Access control system manages the entry of an individual into the facilities and allows access to an authorized person only. Mantra's access control device presents a comprehensive logical or physical access control solution to secure your premises, assets, facilities or data. Technically, two types of Access control systems are recognized in the world of Biometrics namely - physical and logical.

Biometric Access Control system authenticates and authorizes an individual based upon his/her physiological characteristics or attributes and then permits him/her to enter the sensitive area or zone. The Biometric access control system ensures greater security of the premises and proves to be significant in monitoring the vital assets or facilities of your business or enterprise.

### However, based on the usability and requirement, the access control system can be classified as:

- Proximity access control system
- Door access control system
- Security access control system
- Visitor access control system and many more

### Our Access control system renders:

- Access control for highly secured areas
- Mechanism to manage level of access
- Environment to protect facilities, personnel, and assets
- Control over visitor management and much more

PHYSICAL ACCESS CONTROL

## Advanced _Access Control_ Terminals

Our professional range of biometric terminals is designed for high-security environments, offering precision, durability, and seamless integration for physical access and attendance management.

![BioNIC Xtreme FX](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-FX/pro1.png)

Access Terminal\|Model: BFX-L100

AI Powered

### BioNIC Xtreme FX

A powerful Linux-based facial recognition terminal engineered for precision and speed. Featuring deep learning AI, it delivers secure, touchless authentication for enterprise environments.

Processor1.2GHz Quad-core

Capacity50,000 Face DB

Display5" IPS Display

PowerPoE Supported

[Explore Product](https://www.mantratec.com/Face-Recognition-Attendance-System-BioNIC-Xtreme-FX) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-FX/BioNIC-Xtreme-FX.pdf)

![BioNIC Xtreme XI](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XI/pro1.png)

Access Terminal\|Model: BXI-8IP

IP65 Rated

### BioNIC Xtreme XI

Enterprise-grade facial recognition terminal with a large 8-inch display and IP65 ruggedized casing. Built for longevity and high-precision authentication in demanding physical access scenarios.

Processor2.2GHz Quad-core

Capacity50,000 Face

Display8" IPS Display

RuggednessIP65 Rated

[Explore Product](https://www.mantratec.com/Face-Recognition-Access-Control-BioNIC-Xtreme-XI) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XI/BioNIC-Xtreme-XI.pdf)

![BioNIC F6](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-F6/pro1.png)

Attendance Device\|Model: BF6-5WC

Sleek Design

### BioNIC F6

Providing seamless security and user-friendly interaction, the BioNIC F6 is designed for modern corporate offices. It delivers quick, contactless verification with a sophisticated aesthetic.

HardwareQuad-core ARM

Capacity50,000 Face

Display5" IPS Display

ConnectivityWi-Fi & LAN

[Explore Product](https://www.mantratec.com/Face-Scanning-Attendance-System-BioNIC-F6) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-F6/BioNIC-F6.pdf)

![IPAS-AI](https://www.mantratec.com/Assets/Images/Pages/Products/IPAS-AI/pro1.png)

Safety Terminal\|Model: IPAS-A100

Breath Analyzer

### IPAS-AI

An innovative safety-focused terminal combining AI facial recognition with an integrated breath analyzer. Ideal for mining, oil & gas, and logistics sectors where safety compliance is critical.

AnalyzerBuilt-in Sensor

Capacity50,000 Face DB

ProtectionIP65 & IK08

NPU2.2GHz + AI NPU

[Explore Product](https://www.mantratec.com/Face-Recognition-Breath-Analyzer-IPAS) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/IPAS-AI/IPAS-AI.pdf)

![BioNIC FP6](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-FP6/pro1.png)

Multi-Modal Terminal\|Model: BFP6-Dual

Dual Factor

### BioNIC FP6

Providing the best of both worlds, the FP6 integrates facial recognition with fingerprint sensing. This multi-modal approach ensures maximum security and flexible authentication options.

BiometricsFace + Finger

Capacity50,000 Face

Display5" IPS Display

WirelessDual-band Wi-Fi

[Explore Product](https://www.mantratec.com/Fingerprint-Face-Detection-Attendance-System-BioNIC-FP6) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-FP6/BioNIC-FP6.pdf)

![Bio HHT](https://www.mantratec.com/Assets/Images/Pages/Products/Bio-HHT/pro1.png)

Mobile Terminal\|Model: BHHT-M5

Mobility

### Bio HHT

A rugged handheld biometric terminal for on-the-go authentication. Equipped with an L1 fingerprint sensor and high-speed mobile connectivity, it's the perfect tool for field operations.

PortabilityHandheld Rugged

SensorL1 Fingerprint

Network4G LTE & Wi-Fi

Display5" HD Display

[Explore Product](https://www.mantratec.com/Biometric-Handheld-Device-Bio-HHT) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/Bio-HHT/Bio-HHT.pdf)

![BioNIC Xtreme XII](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XII/pro1.png)

Extreme Rugged\|Model: BXII-10IK

IK09 Rated

### BioNIC Xtreme XII

The definitive choice for extreme outdoor environments. With a 10.1-inch IPS display and military-grade IK09 vandal resistance, it offers unrivaled durability and performance.

Screen10.1" IPS

Capacity50,000 Face DB

DurabilityIP65 & IK09

NPU2.2GHz Quad + NPU

[Explore Product](https://www.mantratec.com/Rugged-Multi-Biometric-Terminal-BioNIC-Xtreme-XII) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XII/BioNIC-Xtreme-XII.pdf)

![MBAS50](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/pro1.png)

AEBAS TerminalModel: MBAS-50F

Aadhaar Ready

### MBAS50

A compact and efficient facial recognition device tailored for AEBAS and corporate attendance. It offers high-speed matching in a slim, modern form factor.

ClockQuad-core 1.5GHz

Users5,000 Face Capacity

Display5" IPS Display

WirelessWi-Fi & Bluetooth

[Explore Product](https://www.mantratec.com/Face-Recognition-Biometric-Device-MBAS50) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/MBAS50.pdf)

![MBAS40](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS40/pro1.png)

Multi-Modal AEBAS\|Model: MBAS-40M

Large Screen

### MBAS40

Providing versatile authentication for large-scale programs, the MBAS40 features a 7-inch display and multi-biometric support, ensuring reliable identity management.

EngineQuad-core 2.0GHz

Users5,000 Users Max

Screen7" IPS Display

Mobile4G LTE Built-in

[Explore Product](https://www.mantratec.com/Multi-Modal-Biometric-Device-for-AEBAS-MBAS40) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS40/MBAS40.pdf)

![MBAS30](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS30/pro1.png)

Attendance System\|Model: MBAS-30A

Battery Backup

### MBAS30

Dedicated Aadhaar Enabled attendance terminal. With its integrated fingerprint sensor and long-lasting battery, it ensures continuous operation for critical attendance tracking.

HardwareQuad-core 1.3GHz

Capacity3,000 Users

Display5" IPS Display

Battery4000mAh Battery

[Explore Product](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System-MBAS30) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS30/MBAS30.pdf)

## Secure Digital Access with Biometric Precision

Mantra's Logical Access Control System redefines digital security by replacing traditional passwords with biometric verification, ensuring that only authorized users can access sensitive applications, systems, or data. Whether deployed in government, enterprise, or high-compliance sectors, our solution brings unmatched identity assurance to your digital ecosystem.

### Key Features:

**Biometric Authentication (Face/Fingerprint/Iris):** Ensures secure and non-transferable access.

**Multi-Factor Authentication (MFA):** Combines biometrics with smart cards, PINs, or OTPs for added security.

**Single Sign-On (SSO):** Simplifies login experience across multiple platforms with centralized authentication.

**Role-Based Access Control:** Assign user privileges based on department, designation, or clearance level.

### Ideal For:

Banks & Financial Institutions

Government and Defense Agencies

IT/ITES and Corporate Enterprises

Data Centers and R&D Facilities

![Secure Digital Access Dashboard](https://www.mantratec.com/Assets/Images/Pages/Products/Products_banner/Access-Control_Fifth_Section.png)

LOGICAL ACCESS CONTROL

## Secure _Identity_ & Access Solutions

Our logical access control solutions provide a secure bridge between biometric identity and digital resources, ensuring robust security for your IT infrastructure and application access.

![BioNIC V7](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-V7/pro1.png)

Desktop Reader\|Model: BV7-DSK

Multi-Factor

### BioNIC V7

An advanced fingerprint and card reader designed for secure logical access. It provides high-assurance authentication for Windows login, enterprise applications, and cloud services.

BiometricsFingerprint + Card

InterfaceUSB 2.0 High Speed

SecurityBuilt-in Secure Element

CompliancePC/SC & CCID

[Explore Product](https://www.mantratec.com/Fingerprint-Card-Reader-BioNIC-V7) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-V7/BioNIC-V7.pdf)

![MSCR100](https://www.mantratec.com/Assets/Images/Pages/Products/MSCR100/pro1.png)

Smart Card Reader\|Model: MSCR-100C

ISO Certified

### MSCR100

High-performance contactless smart card reader designed for secure digital identification. Supporting a wide range of RFID technologies, it ensures seamless integration for secure access.

TypeContact Smart Card

InterfaceUSB 2.0 Powered

StandardISO 7816 Compliant

Communication848 kbps Speed

[Explore Product](https://www.mantratec.com/Contactless-Smart-Card-Reader-MSCR100) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MSCR100/MSCR100.pdf)

![MSCR200](https://www.mantratec.com/Assets/Images/Pages/Products/MSCR200/pro1.png)

RFID Reader\|Model: MSCR-200R

NFC Ready

### MSCR200

Specifically designed for 13.56MHz contactless technology, the MSCR200 is a compact reader providing reliable authentication for access control and cashless payment systems.

TechnologyContactless (RFID)

InterfaceUSB 2.0 Plug & Play

SupportISO 14443 A/B

Speed848 kbps Rate

[Explore Product](https://www.mantratec.com/Smart-Card-Reader-MSCR200) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MSCR200/MSCR200.pdf)

![MSKB100](https://www.mantratec.com/Assets/Images/Pages/Products/MSKB100/pro1.png)

Secure Keyboard\|Model: MSKB-100K

3-in-1 Device

### MSKB100

Combining a professional keyboard with an integrated fingerprint sensor and smart card reader, the MSKB100 offers an all-in-one workstation security solution.

KeyboardFull QWERTY Layout

BiometricBuilt-in Fingerprint

Card ReaderContactless HID/RFID

UsageUSB Bus Powered

[Explore Product](https://www.mantratec.com/Keyboard-With-Fingerprint-Reader-MSKB100) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MSKB100/MSKB100.pdf)

## Let's Get in Touch

Feel free to give us a call with any questions; we are waiting to hear from you. For your bulk requirement, just ask for a quote.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")