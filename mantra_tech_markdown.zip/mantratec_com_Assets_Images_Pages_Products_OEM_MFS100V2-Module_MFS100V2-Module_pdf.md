Benefits

Handy device

Convenient to use

Easy-to-handle

Features
\[Image: Im0\]

FAP10 fingerprint device
\[Image: Im0\]

Simple to operate

Error-free

500 DPI optical
fingerprint sensor
\[Image: Im0\]

Support Aadhaar auth
API specification V2.0
\[Image: Im0\]

Lowest FAR and FRR
\[Image: Im0\]

High speed USB 2.0 interface
with plug and play
\[Image: Im0\]

* * *

Optical Fingerprint Scanner
Model : MFS100 V2 \| Module : MOPv1.2

MFS100 V2 is an elegant fingerprint device used for identification, verification and
authentication processes of an individual. MFS100 V2 offers secure, error-free and reliable
identification based on unique fingerprint biometric technology. It is fast & easy-to-use. It
can be used as an alternative or a complement to those hard-to-remember passwords.

At a Glance

| Sensor Characteristics |  |
| --- | --- |
| Parameters |  |
| Fingerprint Sensor |  |
| Image Resolution |  |
| Platen Size |  |
| Active Platen Size |  |
| Image Size |  |
| Image Grayscale |  |
| Image Capture Speed(Continuous) |  |
| Maximum Acquisition Time |  |
| Light Source |  |
| Approx Dimensions(L x W x H) |  |
| Approx Weight |  |
| Electrical Characteristics |  |
| Parameters |  |
| Operating Voltage |  |
| Operating Current(max) |  |
| Stand by Current(max) |  |
| Interface |  |
| Environmental Characteristics |  |
| Parameters |  |
| Operating Temperature |  |
| Storage Temperature |  |
| Humidity(Operating/Storage) |  |
| Compliant to Following Standard |  |
| Parameters |  |
| Biometric Data Interchange Format |  |
| Environmental,Health and Safety |  |
| BIS |  |
| Safety |  |
| EMI/EMC Compliance |  |
| \*FBI PIV Certification |  |
| \*STQC Certification |  |
| IP Rating |  |
| Device Driver |  |
| OS Supports |  |
| \*Applied for certification |  |

| Specification |  |
| --- | --- |
| : Optical Scratch Free Sensor |  |
| : 500 DPI +/-2% |  |
| : 16.4 mm x 20.0 mm |  |
| : 15 mm x 18 mm |  |
| : 296 x 354 Pixels |  |
| : 256 (8 - Bit Gray Level) |  |
| : 10 FPS |  |
| : <2 sec |  |
| : RED LED |  |
| : 28.5 x 23 x 62 mm |  |
| : 0.025 Kg |  |
|  |  |
| Specification |  |
| : 5V+/-5% (USB Powered Device) |  |
| : 100 mA |  |
| : 70 mA |  |
| : USB 2.0(Std/OTG Supported) |  |
|  |  |
| Specification |  |
| : 0 to 50 degC |  |
| : 0 to 50 degC |  |
| : <90% RH, Non-condensing |  |
|  |  |
| Specification |  |
| : ISO 19794-2 for minutiae&ISO 19794-4 for Image Template |  |
| : RoHS Certification |  |
| : IS 13252(Part 1) |  |
| : IEC60950 |  |
| : CE&FCC Class A |  |
| : Compliance |  |
| : Yes |  |
| : IP54 |  |
| : WHQL Certified with Unique Serial Number |  |
| : Windows x86&x64,Linux,Android |  |

[www.mantratec.com](http://www.mantratec.com/)
\[Image: Im0\]