Benefits

Easy to integrate

Offers high accuracy

Easy to use

Rapid capturing

Features
\[Image: Im0\]

Supports multiple devices
\[Image: Im0\]

High speed interface

500 DPI optical
fingerprint sensor
\[Image: Im0\]

Support Aadhaar auth
API specification V2.0
\[Image: Im0\]

Device securely sign the
biometric data
\[Image: Im0\]

* * *

Optical Fingerprint Scanner
Model : MFS500 \| Module : MOPv2.0

MFS500 is a high-quality fingerprint scanner utilized for accurate fingerprint authentication
process. MFS500 is devised with an optical scratch free sensor for efficient recognition of
poor quality fingerprint. MFS500 can be used for the process of identification, verification
and authentication that captures the fingerprint images in a faster and reliable manner.

At a Glance

| Sensor Characteristics |  |
| --- | --- |
| Parameters |  |
| Fingerprint Sensor |  |
| Image Resolution |  |
| Platen Size |  |
| Active Platen Size |  |
| Image Size |  |
| Image Grayscale |  |
| Light Source |  |
| Approx Dimensions(L×W×H) |  |
| Approx Weight |  |

| Specification |
| --- |
| : Optical Scratch Free Sensor |
| : 500 DPI +/-2% |
| : 16.4 mm x 20.0 mm |
| : 15 mm x 18 mm |
| : 296 x 354 Pixels |
| : 256 (8-Bit Gray Level) |
| : RED LED |
| : 61x23x28.5 |
| : 0.026 Kg |

Electrical Characteristics
Parameters

| Parameters | Specification |
| --- | --- |
| Operating Voltage | :5V+/-5% (USB Powered Device) |
| Operating Current(max) | :80mA |
| Stand by Current(max) | :40mA |
| Interface | :USB2.0(Std/OTG Supported) |

Environmental Characteristics
Parameters

| Parameters |
| --- |
| Biometric Data Interchange Format |
| Environmental, Health and Safety |
| BIS |
| Safety |
| EMI/EMC Compliance |
| \*STQC Certification |
| IP Rating |
| Device Driver |
| OS Supports |

| Specification |
| --- |
| :ISO 19794-2 for minutiae&ISO 19794-4 for Image Template |
| :RoHS Certification |
| :IS 13252(Part1) |
| :IEC60950 |
| :CE&FCC ClassA |
| :Yes |
| :IP54 |
| :WHQL Certified with Unique Serial Number |
| :Window x86&x64,Linux,Android |

| Parameters | Specification |
| --- | --- |
| Operating Temperature | :0 to 50 degC |
| Storage Temperature | :0 to 50 degC |
| Humidity(Operating/Storage) | :＜90%RH,Non-condensing |

\*Applied for certification
\[Image: Im0\]