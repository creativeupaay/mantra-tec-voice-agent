[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Solutions](https://www.mantratec.com/Solutions) Airport Solutions

Digiyatra Initiative

# India's Most Deployed Airport Biometric Platform

BCAS, STQC and FBI certified. Deployed at 50+ airports. From check-in kiosks to airside access control - every passenger touchpoint, one platform.

[Enquire Now](https://www.mantratec.com/Solutions-Inquiry-Form)

![Smart Airport Solutions](https://www.mantratec.com/Assets/Images/Pages/Solutions/Airport-Solution/smart-airport-solutions-hero.png)

Airport Deployements50+

Passengers Processed10M+

Recognition Accuracy99.9%

Solutions

## Securing Every Passenger Touchpoint

From landside entry to airside boarding, Mantra's platform connects each step of the airport journey - no paper, no queues, no gaps in security.

###### E-Boarding &    DigiYatra Integration

**↓ 40% faster boarding per gate**

India's DigiYatra-native boarding solution. Passengers link their Aadhaar or travel document once - and walk through every checkpoint with a glance, from entry gate to seat.

- Aadhaar-linked enrollment at self-service kiosks

- 1:1 and 1:N facial matching at boarding gates

- Real-time DGCA and airline system sync

- Anti-spoofing liveness detection built in


###### Touchless Self    Check In Kiosks

**↓ 60% drop in counter queue time**

Passengers check in, drop bags and print boarding passes without touching a screen. Biometric authentication replaces manual document verification at every step.

- Face, fingerprint or iris - passenger's choice

- Verifies 60+ document types in under 2 seconds

- PNR and passport auto-fetch via OCR

- Baggage weight and tag printing in one flow


###### Access Control for    Restricted Zones

**Zero tailgating in pilot deployments**

CISF and ground handler zones require airtight access control. Mantra's multi-factor system ties biometric identity to role, shift schedule and zone clearance in real time.

- Face plus fingerprint dual-factor for red zones

- Integration with CUTE, CUSS, and airport HRMS

- Immediate deactivation on shift end or role change

- Full access audit trail with CCTV correlation


* * *

![Airport Staff and Visitor Identity Management](https://www.mantratec.com/Assets/Images/Pages/Solutions/Airport-Solution/staff-visitor-identity-management.png)

###### Airport Staff and Visitor Identity Management

Single enrollment, all access points

One enrollment covers every entry point across the terminal. Ground crew, airline staff, vendors and contractors are enrolled once and verified in milliseconds at every door.

- Works with existing RFID and smart card systems

- Visitor pass issuance with escort tracking

- Contractor permit expiry and renewal alerts

- Multimodal fallback - fingerprint, iris or face


![Real-Time Operations Analytics Dashboard](https://www.mantratec.com/Assets/Images/Pages/Solutions/Airport-Solution/real-time-operations-dashboard.png)

###### Real-Time Operations Analytics Dashboard

Proactive issue detection before delays happen

Passenger flow data, queue build-up alerts and gate throughput metrics update every 30 seconds. Operations teams respond to congestion before it becomes a delay.

- Queue depth and wait-time forecasting

- Per-gate boarding completion percentages

- Hourly and shift-level throughput reports

- API feed to Airport Operations Control Centre


![Immigration and Border Control Integration](https://www.mantratec.com/Assets/Images/Pages/Solutions/Airport-Solution/immigration-border-control.png)

###### Immigration and Border Control Integration

Under 8-second processing per traveller

Designed for seamless walk-through and e-gate deployments at international terminals. Mantra's system links to immigration databases and flags watchlist matches before a passenger reaches an officer.

- Interpol and national watchlist screening

- MRZ and chip-reading for e-passports

- Dual-camera 1:N matching at speed

- BCAS-compliant data handling throughout


![Lost and Found and Unattended Baggage Detection](https://www.mantratec.com/Assets/Images/Pages/Solutions/Airport-Solution/unattended-baggage-detection.png)

###### Lost and Found and Unattended Baggage Detection

↓ 70% faster bag-to-owner resolution

When a bag is left unattended beyond a set threshold, the system flags the location, timestamps the alert and cross-references nearby biometric events to identify the last person in contact with it.

- Configurable dwell-time alerts per zone - 2 minutes at gates, 10 at arrivals

- Biometric trail linking a bag to the last verified identity near it

- Direct alert push to security control room and nearest officer

- Lost item claim verification via passenger identity match at counter


## Impact Backed by Verifiable Data

We do not publish stats that cannot be verified. Every figure represents a live airport deployment across India and the globe.

50+Airport Deployements

10M+Passengers Processed

99.9%Face Match Accuracy

24/7Support Available

## What Actually Makes Mantra Different

In a crowded biometric landscape, here is what separates Mantra.

The Only Vendor with BCAS, STQC and FBI Certification

Built and Manufactured in India - No Supply Chain Risk

US Patent Holder - Sensor and Recognition Technology

Aadhaar-Grade Enrollment Engine - Now in Airports

Integrates with What You Already Have

Hybrid or Cloud - Your Choice

A Deployment Team That Has Done This Before - at Your Scale

Tested at Government Scale Before It Reached Your Terminal

## Technical Capabilities

For IT managers and systems integrators who need specifics before a procurement decision.

###### Multimodal Biometric Engine

- Facial recognition with anti-spoofing liveness check
- Fingerprint matching at 1:N scale across millions of templates
- Iris recognition for highest-security checkpoints
- Fusion scoring across multiple modalities for maximum accuracy
- Under 500ms matching latency at 1:N scale

###### Integration and API Layer

- REST and SOAP APIs for DCS, CUTE, CUSS, FIMS and AOCC
- DigiYatra platform integration - certified and production-proven
- MQ-based event streaming for real-time downstream notifications
- LDAP, Active Directory and SSO support for staff identity
- Custom SDK available for airline and ground handler apps

###### Security and Data Privacy

- Data encrypted at rest and in transit - AES-256
- Biometric template stored as irreversible mathematical representation
- DigiYatra-mandated passenger data deletion within 24 hours of flight
- Role-based access to all admin functions with full audit log
- PDPB and GDPR compliant data handling architectures available

###### Deployment and Infrastructure

- On-premise, hybrid and private cloud deployment models
- Air-gapped option for CISF and paramilitary-controlled zones
- 99.9% uptime SLA with failover to secondary matching node
- Edge processing on device for sub-second response
- Remote monitoring, patch management and fleet management console

## Our Track Record

The advantage of partnering with pioneers who have specialized in biometric engineering since 2006.

###### In-House Manufacturing Since 2006

Hardware designed and built at Mantra's Ahmedabad facility.

###### No Third-Party SDK Dependency

Mantra's matching algorithms are proprietary and in-house.

###### Deployed in 50+ Countries

Including multiple national ID and voter registration programs.

###### In-House AI That is Harder to Spoof

Every attempted spoof pattern feeds back into the model.

###### Data Never Leaves Your Network

No passenger data is transmitted to Mantra's servers.

###### Scales from 1 Gate to an Entire Terminal

Expand across the terminal without re-architecting.

![Built for DigiYatra from the Ground Up](https://www.mantratec.com/Assets/Images/Pages/Solutions/Airport-Solution/centralized-command-control.jpg)

Domestic Terminal

## Built for DigiYatra from the Ground Up

Mantra was among the first vendors to complete DigiYatra certification. The integration is not an add-on - it is the core of how our boarding solution was designed.

###### 38%

Faster gate processing

###### 90%

Daily departures covered

Command and Control

## A Unified View for Security Operations

The Mantra command dashboard pulls access logs, CCTV feeds, biometric alerts and queue analytics into a single interface. Security managers act on real events, not delayed reports.

###### Role-based access

For CISF, airline ops, ground handlers and airport authority teams

###### Full audit trail

Every door event linked to an identity and a timestamp

![One Screen for Every Security - Command and Control](https://www.mantratec.com/Assets/Images/Pages/Solutions/Airport-Solution/frictionless-passenger-experience.png)

FAQ

## Airport Operators Deployment FAQs

Straight answers to the questions every IT head, security manager and procurement team asks.

Solution Inquiry [079-49068001](tel:+917949068001)

###### Where is passenger biometric data stored? Does it leave our network?

In compliance with DigiYatra privacy-by-design principles, there is no central storage of personally identifiable biometric data (PII). Passenger biometrics are stored locally on their own mobile devices in an encrypted format. During travel, the data is shared temporarily with the airport's local departure system only for the duration of transit and is automatically purged from the airport's local servers within 24 hours of flight departure.

###### What happens if the biometric system goes offline?

The system is architected with Edge Processing capabilities. If the central server connectivity is lost, individual e-gates and biometric touchpoints can continue to operate using locally cached flight manifests and credentials for a limited time. Once connectivity is restored, all transaction logs and boarding records are automatically synchronized with the central DCS.

###### Is the system compliant with India's Personal Data Protection Bill?

Yes, the solution is fully compliant with the Digital Personal Data Protection (DPDP) Act, 2023. It adheres to strict data minimization protocols - collecting only necessary data, obtaining explicit user consent through the DigiYatra app, ensuring purpose limitation (boarding only), and implementing automated data purging cycles to meet "Right to be Forgotten" standards.

###### Can the platform handle 1:N matching at high passenger volume?

Yes, the system utilizes NIST-benchmarked algorithms capable of high-speed 1:N (One-to-Many) matching. It is optimized to process thousands of passengers per hour with a matching latency of less than 1 second per passenger, maintaining high accuracy and low False Acceptance Rates (FAR) even during peak airport traffic.

###### Can the biometric camera identify passengers wearing face masks or eyewear?

Yes. The AI-driven facial recognition engine is trained on diverse datasets to handle partial occlusion. It maintains high matching accuracy even when passengers are wearing medical masks, prescription glasses, or have undergone minor changes in facial hair, reducing the need for passengers to remove accessories.

## Let's Talk About Your Airport

We will review, identify, and walk you through a live demo of the exact configuration you would deploy.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule a Consultation](https://www.mantratec.com/Solutions-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")