Applications
\[Image: Im70\]

l Banking

l Corporates

l Public distribution system
\[Image: Im70\]

l Payment

l Institution

l Merchant Payment
E-Governance

l E-Governance

Scratch free
sensor surface
\[Image: Im29\]

Features
\[Image: Im29\]

USB 2.0 interface
with plug and play
\[Image: Im29\]

Latent Finger Detection
\[Image: Im29\]

500 DPI Optical
fingerprint sensor
\[Image: Im29\]

FBI PIV Certified
Image Quality
\[Image: Im29\]

Lower FAR and FRR
\[Image: Im29\]

Support
Windows, Android, Linux
\[Image: Im29\]

[www.mantratec.com](http://www.mantratec.com/)
\[Image: Im29\]

* * *

Optical Fingerprint Scanner
Model : MFS200 \| OEM Sensor Module : MOPvO200

The Mantra MFS200 optical fingerprint scanner boasts the highest standards
in image quality, reliability, and compatibility, being FBI PIV certified. Fully
compliant with ANSI 378 and ISO 19794-2 standards, this scanner also
supports the WSQ image format. It is ideally suited for a range of applications,
such as financial services, E-Governance, public security, and PC security.
Additionally, its Latent Finger Detection capabilities ensure accurate and
secure fingerprint recognition.

The Mantra MFS200 optical fingerprint scanner boasts the highest standards
in image quality, reliability, and compatibility, being FBI PIV certified. Fully
compliant with ANSI 378 and ISO 19794-2 standards, this scanner also
supports the WSQ image format. It is ideally suited for a range of applications,
such as financial services, E-Governance, public security, and PC security.
Additionally, its Latent Finger Detection capabilities ensure accurate and

At a Glance

| Sensor |  |
| --- | --- |
| Parameters | Specification |
| Fingerprint Sensor Type | :Scratch Free Optical Sensor |
| Pixel Resolution | :500 DPI+/-2% |
| Sensing Area | :15.24mmx20.32mm(0.6x0.8Inch) |
| Image Size | :300x400 Pixels |
| Image Grayscale | :256(8-Bit Gray Level) |
| FRR&FAR | <0.1%&<0.001% |
| Maximum Acquisition time | <2Sec(Placement to Template) |
| Capture mode | :Auto Finger detection functionality&Auto capture with built-in quality check(Incorporates NIST quality considerations) |
| Illumination Source | :RED LED |
|  |  |
| Electrical |  |
| Parameters | Specification |
| Protocol | :USB2.0 |
| Operating Voltage | :5V±5%(USB Powered Device) |
| Operating Current | :Operating Current:<100mA&Standby Current:<50mA |
|  |  |
| Environmental |  |
| Parameters | Specification |
| Operating Temperature | :-10℃to+70℃ |
| Storage Temperature | :-20℃to+85℃ |
| Humidity(Operating/Storage) | <90%RH,Non-condensing |

\ 20^{\\circ}\\mathrm{C},\\mathrm{t O}85^{\\circ}\\mathrm{C}

* * *

Optical Fingerprint Scanner
Model : MFS200 \| OEM Sensor Module : MOPvO200

| Parameters | Specification |
| --- | --- |
| Biometric Data Interchange Format | :RAW/WSQ/JPEG/ISO19794-2/4:2005 and 2011,ANSI378 for minutiae Image Template |
| EMI/EMC Compliance | :CE&FCC Part 15B class A |
| ESD protection | :Contact Discharge:+/-8kV,Air Discharge:+/-15kV |
| Environmental,Health and Safety | :RoHS |
| Safety | :EN/IEC62368-1,IS13252(Part1) |
| Image Quality | :FBIPIV Certification |
| IP Rating | :IP65 |
| Device Driver | :WBF Driver |
| USB-IF Certification | :Yes |

| Dimensions |  |
| --- | --- |
| Parameters | Specification |
| Device Dimensions(LxWxH) | :68x56.5x31.5mm |
| Device Weight | :105grams |
| Module Dimensions(LxWxH) | :44.10x38x28.7mm |
| Module Weight | :35grams |

| System Requirements |  |
| --- | --- |
| Parameters | Specification |
| Operating System | :Windows-x86&x64,Android-7&Above |
| Standard Software/SDK | :1:1 Morfin Authentication1:N Morfin Search |