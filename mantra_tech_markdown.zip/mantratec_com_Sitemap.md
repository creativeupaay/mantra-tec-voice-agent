[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home") Sitemap

# Sitemap

## [Home](https://www.mantratec.com/)

* * *

- [Solutions](https://www.mantratec.com/Solutions)
- [Enterprise Security Solutions](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions)
- [RFID Security Solution](https://www.mantratec.com/Solutions/RFID-Security-Solution)
- [Face Recognition Attendance](https://www.mantratec.com/Face-Recognition)
- [Access Control System](https://www.mantratec.com/Solutions/Access-Control-System)
- [Biometrics Attendance System](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)
- [Citizen Identification](https://www.mantratec.com/Solutions/Citizen-Identification)
- [Smart City Solution](https://www.mantratec.com/Solutions/Smart-City-Solution)
- [Airport Solution](https://www.mantratec.com/Solutions/Airport-Solution)
- [Biometric Technologies](https://www.mantratec.com/Solutions/Biometric-Technologies)

- [Operational Excellence](https://www.mantratec.com/Operational-Excellence)
- [Project Management](https://www.mantratec.com/Operational-Excellence/Project-Management)
- [Operations & Maintenance](https://www.mantratec.com/Operational-Excellence/Operations-and-Maintenance)
- [Industries & Markets](https://www.mantratec.com/Operational-Excellence/Industries-and-Markets)

- [Research & Development](https://www.mantratec.com/Research-and-Development)
- [Innovation & Knowledge](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)
- [Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering)
- [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering)
- [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering)
- [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering)

- [Security Software Development](https://www.mantratec.com/Security-Software-Development)
- [Consulting](https://www.mantratec.com/Security-Software-Development/Security-Software-Consulting)
- [Biometrics Software](https://www.mantratec.com/Security-Software-Development/Biometrics-Software)

* * *

- [Biometric Technologies](https://www.mantratec.com/Solutions/Biometric-Technologies)
- [Palm-vein Scanner](https://www.mantratec.com/Palm-Vein-Scanner)
- [Fingerprint Scanner](https://www.mantratec.com/Fingerprint-Scanner)
- [Face Recognition](https://www.mantratec.com/Face-Recognition)
- [Iris Scanner](https://www.mantratec.com/IRIS-Scanner)

- [Palm-vein Scanner](https://www.mantratec.com/Palm-Vein-Scanner)
- [PV1000](https://www.mantratec.com/Palm-Vein-Scanner/PV1000)
- [PV2000](https://www.mantratec.com/Palm-Vein-Scanner/PV2000)

- [Fingerprint Scanner](https://www.mantratec.com/Fingerprint-Scanner)
- [mDESK7](https://www.mantratec.com/Products/Fingerprint-Sensors/mDESK7)

- [Iris Scanner](https://www.mantratec.com/IRIS-Scanner)
- [MIS100V2](https://www.mantratec.com/Products/IRIS-Sensor/MIS100V2-IRIS-Scanner)

* * *

#### [Products](https://www.mantratec.com/Products)

- [Fingerprint Sensors](https://www.mantratec.com/Products/Fingerprint-Sensors)
- [MOXA7](https://www.mantratec.com/Products/Fingerprint-Sensors/Biometric-Fingerprint-Tablet-MOXA7)
- [MFSTAB II](https://www.mantratec.com/Products/Fingerprint-Sensors/Biometric-Fingerprint-Tablet-MFSTAB-II)
- [MORPHS](https://www.mantratec.com/Products/Fingerprint-Sensors/MORPHS)
- [MFS500](https://www.mantratec.com/Products/Fingerprint-Sensors/MFS500)
- [MFS500 LX](https://www.mantratec.com/Products/Fingerprint-Sensors/MFS500-LX)
- [mDESK7](https://www.mantratec.com/Products/Fingerprint-Sensors/mDESK7)
- [MFS110](https://www.mantratec.com/Products/Fingerprint-Sensors/MFS110-Fingerprint-Reader)

- [IRIS Sensor](https://www.mantratec.com/Products/IRIS-Sensor)
- [MATIS DX](https://www.mantratec.com/Products/IRIS-Sensor/MATIS-DX)
- [MIS100V2](https://www.mantratec.com/Products/IRIS-Sensor/MIS100V2-IRIS-Scanner)

- [Integrated Fingerprint Devices](https://www.mantratec.com/Products/Integrated-Fingerprint-Devices)
- [MFSTAB 4G](https://www.mantratec.com/Products/Integrated-Fingerprint-Devices/MFSTAB-4G)
- [MFSTAB 3G + LAN](https://www.mantratec.com/Products/Integrated-Fingerprint-Devices/MFSTAB-3G-lAN)
- [MFSTAB 3G](https://www.mantratec.com/Products/Integrated-Fingerprint-Devices/MFSTAB-3G)

- [Integrated IRIS Devices](https://www.mantratec.com/Products/Integrated-IRIS-Devices)
- [MISTAB](https://www.mantratec.com/Products/Integrated-IRIS-Devices/MISTAB)

* * *

- [POS / MicroATM / Financial Terminal](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal)
- [mTerminal100](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal/mTerminal100)
- [mTerminal200](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal/mTerminal200)

- [Biometric Enrollment Devices](https://www.mantratec.com/Products/Biometric-Enrollment-Devices)
- [MORPHS](https://www.mantratec.com/Products/Fingerprint-Sensors/MORPHS)
- [MATIS DX](https://www.mantratec.com/Products/IRIS-Sensor/MATIS-DX)

- [Access Control](https://www.mantratec.com/Products/Access-Control)
- [mBrix](https://www.mantratec.com/Products/Access-Control/mBrix)
- [Bionic7](https://www.mantratec.com/Products/Access-Control/Bionic7)

- [OEM Modules](https://www.mantratec.com/Products/OEM-Modules)
- [MFS100 Module](https://www.mantratec.com/Products/OEM-Modules/MFS100-Module)
- [MFS100V2 Module](https://www.mantratec.com/Products/OEM-Modules/MFS100V2-Module)
- [MFS500 Module](https://www.mantratec.com/Products/OEM-Modules/MFS500-Module)
- [MFS500LX Module](https://www.mantratec.com/Products/OEM-Modules/MFS500LX-Module)
- [MAPROOX Module](https://www.mantratec.com/Products/OEM-Modules/MAPROOX-Module)
- [MAPROCX Module](https://www.mantratec.com/Products/OEM-Modules/MAPROCX-Module)
- [MIS100V2 Module](https://www.mantratec.com/Products/OEM-Modules/MIS100V2-Module)
- [MOBIIRIS-Module](https://www.mantratec.com/Products/OEM-Modules/MOBIIRIS-Module)

* * *

- [Aadhaar Products](https://www.mantratec.com/Products/Aadhaar-Products)
- [Aadhaar-Kit](https://www.mantratec.com/Aadhaar-Kit)
- [MFSTAB 4G](https://www.mantratec.com/Products/Integrated-Fingerprint-Devices/MFSTAB-4G)
- [Ayushman Aadhaar Products](https://www.mantratec.com/Ayushman-Aadhaar-Products)
- [Biometric Device Jeevan Pramaan](https://www.mantratec.com/Biometric-Device-Jeevan-Pramaan)
- [Aadhaar Enabled Biometric Attendance System](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System)
- [Aadhaar Based GPS Biometric Attendance System](https://www.mantratec.com/Aadhaar-Based-GPS-Biometric-Attendance-System)
- [Aadhaar Biometric Device for Yuva Swabhiman Yojana](https://www.mantratec.com/Aadhaar-Biometric-Device-for-Yuva-Swabhiman-Yojana)

- [Aadhaar Enabled Biometric Fingerprint Scanner Device for CSC](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Fingerprint-Scanner-Device-for-CSC)
- [VTP Aadhaar Biometric Devices for Vocational Training Program](https://www.mantratec.com/VTP-Aadhaar-Biometric-Devices-for-Vocational-Training-Program)
- [Aadhaar Biometric Devices for DigiLocker](https://www.mantratec.com/Aadhaar-Biometric-Devices-for-DigiLocker)
- [Aadhaar Biometric Fingerprint and IRIS scanner Devices for BHIM](https://www.mantratec.com/Aadhaar-Biometric-Fingerprint-and-IRIS-scanner-Devices-for-BHIM)
- [Aadhaar Enabled Biometric Micro ATM for AePS](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Micro-ATM-for-AePS)
- [NDLM Aadhaar Biometric Devices](https://www.mantratec.com/NDLM-Aadhaar-Biometric-Devices)
- [Aadhaar Biometric Device for PMKVY](https://www.mantratec.com/Aadhaar-Biometric-Device-for-PMKVY)
- [Biometric Device for Comprehensive Health Insurance Scheme](https://www.mantratec.com/Biometric-Device-for-Comprehensive-Health-Insurance-Scheme)

* * *

#### [About Us](https://www.mantratec.com/About-Us)

- [About Mantra](https://www.mantratec.com/About-Us)
- [Company Profile](https://www.mantratec.com/Company-Profile)
- [Company Philosophy](https://www.mantratec.com/Company-Philosophy)
- [Clientele](https://www.mantratec.com/Clientele)
- [Accreditation](https://www.mantratec.com/Accreditation)
- [News & Events](https://www.mantratec.com/News-and-Events)

#### [Brands](https://www.mantratec.com/Brands)

- [MyRFID](https://www.mantratec.com/MyRFID)
- [Moreze](https://www.mantratec.com/Moreze)
- [MXFace](https://www.mantratec.com/Mxface)
- [Mikshi AI](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

#### [Support](https://www.mantratec.com/Support)

- [Warranty & RMA Process](https://www.mantratec.com/Warranty-and-RMA-Process)
- [Ticket Creation](https://www.mantratec.com/Ticket-Creation)
- [Knowledge Base / FAQ's](https://www.mantratec.com/Knowledge-Base-FAQs)
- [Drivers / SDK](https://www.mantratec.com/Drivers-SDK)

#### [Partners](https://www.mantratec.com/Partners)

- [Distribution Partner](https://www.mantratec.com/Partners/Distribution)
- [Solution Partner](https://www.mantratec.com/Partners/Solution)

* * *

#### Contact

- [Contact Details](https://www.mantratec.com/Contact-Details)
- [Inquiry Form](https://www.mantratec.com/Products-Inquiry-Form)
- [Careers](https://www.mantratec.com/Careers)

#### Others

- [Blog](https://blog.mantratec.com/)
- [Insights Hub](https://www.mantratec.com/Insights)
- [Media](https://www.mantratec.com/Media)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")