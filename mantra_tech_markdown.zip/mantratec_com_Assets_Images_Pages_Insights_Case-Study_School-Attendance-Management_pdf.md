# Case Study

## Andhra Pradesh Technology Services Limited Aadhaar Enabled Biometric Attendance System (AEBAS)

Real-time and efficient centralized attendance monitoring solution based on Aadhaar authentication, particularly utilized for Government officials. u **13 Administrative Districts of Andhra Pradesh are Covered** u **17500+ Aadhaar-Enabled Biometric Attendance Systems Installed** u **45 Days – Project Implementation within a Short Span**

* * *

# Client Overview

Andhra Pradesh Technology Services Limited (APTS) is an Andhra Pradesh State Government undertaking company incorporated under the Companies Act, 1956 focusing on e-Governance. It provides consultancy, procurement services and implementation support to the government entities for their IT/ ICT related initiatives. APTS is a pioneer in consultancy services to all State Government Departments of Andhra Pradesh.

# Challenges

## Dealing with the management and monitoring of attendance of all the state employees

APTS employs several government officials working across 13 administrative districts of the state which includes Anantapur, Chittoor, East Godavari, Guntur, YSR Kadapa, Krishna, Kurnool, Sri Potti Sri Ramulu Nellore, Prakasam, Srikakulam, Visakhapatnam, Vizianagaram, and West Godavari. Monitoring the attendance of all APTS employees working under these 13 districts through the manual system is a complex but necessary task since the presence of officials in offices directly impact productivity and efficiency.

Customarily, the attendance of APTS employees was managed through registers where officials use to mark their attendance utilizing the manual method after reaching the office. However, supervision of this system was difficult and also liable for incorrect information being entered into the system. Therefore APTS felt the need to implement a centralized system for monitoring employee attendance in various government offices across the state, leveraging the existing identity infrastructure created by Aadhaar.

* * *

Solution

Solution
Employing Mantra’s AEBAS for a real-time, accurate and reliable attendance management system

Employing Mantra’s AEBAS for a real-time, accurate and reliable attendance management system
As part of the “Digital India” Programme of Government of India, GOI has decided to implement common Aadhaar
Enabled Biometric Attendance System (AEBAS) across the country. The proposed system enables an employee to
register attendance by presenting his/her biometric details (fingerprint / IRIS) which will be authenticated online by
carrying out a 1:1 match with the stored biometric data in the UIDAI database (CIDR) against an employee’s Aadhaar
number.

Following the cumbersome and inaccurate attendance management process in the wake of the standard attendance
monitoring system, the APTS authorities decided to implement Mantra’s Aadhaar-enabled biometric attendance
system across 13 districts of Andhra Pradesh to authenticate an identity of all state employees by verifying their
fingerprint impression and Aadhaar number.

Several government offices across the state implemented AEBAS with more than 17500 Mantra’s biometric
attendance devices installed across the state including remote areas of the districts. Mantra’s AEBAS devices
streamline the process of managing time-attendance of all APTS employees across the state supporting advanced
biometric technology, easy to use functionality and centralized data functions.

Salience

Salience
u Simple to Deploy

u Simple to Deploy
u Portable and Easily Re-locatable

u Portable and Easily Re-locatable
u Online Self Registration Requiring Only Aadhaar

u Online Self Registration Requiring Only Aadhaar
u Works on Multiple Platforms & Devices

* * *

Team Structure for Development & Implementation Phase

| Engineer Name |
| --- |
| Shiva |
| Touseff |
| Rajesh Nadu |
| Jayaprakash |
| Venkatesh |
| Ravi Teja |

|  | Location |
| --- | --- |
|  | Kadapa |
|  | Kurnool |
|  | Ananthpur |
|  | Chitoor |
|  | Nellor |
|  | Prakasam |

Team Structure for Operation and Maintenance phase

* * *

Mantra's Devices Utilized in Multiple Govt. Offices across the Country

Mantra's Devices Utilized in Multiple Govt. Offices across the Country
Mantra’s Aadhaar-enabled biometric attendance devices are currently deployed in multiple Government offices
across the county to monitor attendance of Govt. officials in real-time on a live dashboard for improving efficiency and
offering scalability. The biometric details of all the employees get collected by installed Mantra AEBAS devices and
later on, uploaded in a central server for creating a biometric database that assists in ensuring the timely arrival and
departure of government employees.

Integrated Fingerprint Biometric Device - MFSTAB-4G

Support STQC/Aadhaar
Certified Fingerprint Reader

1:1 or 1:N Fingerprint
Matching Functions

Inbuilt Battery Backup to
Ensure 99.9% Uptime

Wifi Means Cable Less
Installations

Compatible with State-
of-the-Art Time Trak,
BioPay Software

u Higher Accuracy
u Fast Biometric Identification

Contemporary Aesthetic
that Blends Perfectly with
Modern Ar chitecture

Benefits

u User-Friendly
u Higher Accuracy

u User-Friendly

Data Retention in Case
of Power Failure,
No Loss of Data

Tough Casing Protects your
Device From Drops
and Scratches

MFSTAB 4G is a wall mount STQC certied biometric ngerprint scanner
used efficiently for Aadhaar verication. The integrated Fingerprint Sensor
is one of the most secure biometric authentication device. Not only does it
serve the purpose of scanning and recording but also verifying the identity
of a person. With 2 GB of RAM, it allows users to do multitasking with super
fast speed.

u Easy Installation
u Quick Response