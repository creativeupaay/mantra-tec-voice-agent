[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Solutions](https://www.mantratec.com/Solutions) Defence Security & Surveillance

Situational Awareness \| Perimeter Control \| Mission Readiness

# Defence Security & Surveillance for High-Risk and Mission-Critical Environments

Strengthen situational awareness, perimeter control, and rapid response across defence sites with surveillance systems engineered for operational reliability, biometric precision, and security readiness.

[Get In Touch](https://www.mantratec.com/Solutions-Inquiry-Form)

![Defence Security & Surveillance](https://www.mantratec.com/Assets/Images/Pages/Solutions/Business-Security-Systems/business-security-hero.png)

### 24/7 Awareness

Continuous visibility and mission readiness.

Overview

## Built for Demanding Defence Environments

Defence environments operate under demanding conditions where security cannot depend on fragmented monitoring or delayed decision-making. Strategic facilities, restricted zones, storage sites, and operational areas require surveillance systems that deliver continuous visibility, dependable performance, and actionable intelligence in real time.

###### Real-time Monitoring

Instant verification at every access point and situational awareness across all zones.

###### Permit Management

Centralized permit issuing and revoking through a single console for complete entry control.

###### Multi-modal Biometric Authentication

Face, fingerprint, iris and RFID combined for high-security multi-modal authentication.

###### Field-Ready Design

Robust and durable hardware engineered specifically for defence-grade field conditions.

Indigenous Innovation

## Powering Defence Security For the World

Designed and manufactured in India, these platforms are positioned for compliant, future-ready security and surveillance deployment across defence and research environments.

20+

###### Years of Expertise

Advanced capability across biometric, RFID, and integrated security systems since 2006.

150,000 sq. ft.

###### Indigenous Mfg.

Make in India security platforms for high-risk and operationally sensitive environments.

1,400+

###### Workforce

Strong engineering and manufacturing base supporting defence-focused delivery at scale.

40+

###### Global Presence

Established export footprint and broad global deployment experience across continents.

Defence Solution Portfolio

## Integrated Platforms for Mission-Ready Defence Stacks

Our portfolio combines access control, analytics, AI, logical security, and border surveillance into a comprehensive, mission-ready defence architecture.

SOLUTION 01

##### Defence Entry Permit System (DEPS)

Integrated RFID and biometric access solution for defence entry workflows, with real-time monitoring, instant permit validation, centralized management, and durable field-ready deployment.

- RFID + biometric dual-layer entry control
- Real-time permit monitoring & validation
- Centralized permit issuing & revoking
- Durable, field-ready hardware design
- Full audit trail of all entry events

SOLUTION 02

##### MARS AI & IPAS AI

MARS AI supports facial recognition-based weapon issuance, OCR-based weapon recognition, AI-assisted weapon proving and verification, and custom report generation. IPAS AI adds integrated breath analysis with dual RGB and IR cameras.

- Facial-based weapon issue & recognition
- OCR-based weapon number identification
- AI-based weapon proving verification
- Integrated breath analysis (IPAS AI)
- Dual RGB + IR camera, rugged certified

SOLUTION 03

##### Logical Security & ANPR

Multi-factor biometric logon for network access and non-repudiable audit trails protecting classified systems, paired with AI-powered vehicle recognition and barrier integration.

- Multi-factor biometric network logon
- Non-repudiable audit trails for classified systems
- AI-powered ANPR vehicle recognition
- Automatic flagging of unauthorized vehicles
- Barrier integration & gate automation

SOLUTION 04

##### VMS, Crowd Recognition & Border Security

AI-powered surveillance with crowd recognition, visitor tracking, and unauthorized access detection - plus integrated PIDS and FIDS with remote command and control.

- AI-powered video management system (VMS)
- Crowd recognition & behaviour analytics
- Unauthorized access detection & alerts
- Integrated PIDS & FIDS border systems
- Remote command & control for smart borders

Key Capabilities

## Defence Architecture for Faster Decisions & Stronger Control

The defence architecture combines surveillance, access governance, identity assurance, and command visibility.

###### Perimeter Surveillance

Monitor fencing, boundary walls, and sensitive approach areas with continuous visual coverage and real-time alerts.

###### High-Security Monitoring

Track activity around strategic buildings, armouries, restricted zones, and operational corridors at all times.

###### Intelligent Threat Detection

Event-based alerts for intrusion, unauthorized movement, and loitering using AI-led video analytics.

###### Central Command Visibility

Unified situational awareness through centralized monitoring - all sites, all sensors, one screen.

###### Biometric Identity Assurance

Multi-factor biometric authentication and access control tighten entry governance for classified areas.

###### Fast Response

Enable quicker security action through analytics-led alerting and coordinated escalation workflows.

Deployment Areas

## Securing Every Environment Where Control & Readiness Are Essential

Defence security solutions support diverse operating environments where visibility and discipline cannot be compromised.

###### Military Stations

High-security visibility across headquarters, barracks, and command centres.

###### Border Facilities

Strengthen perimeter oversight across sensitive border locations with integrated PIDS and FIDS.

###### Ammunition Storage

Protect assets with continuous surveillance, biometric entry, and tamper-proof audit trails.

Operational Integrity

## Vigilance, Readiness, and Control Without Compromise

In defence operations, security systems must support vigilance, readiness, and control without compromise. A robust surveillance architecture helps protect strategic assets, strengthen site discipline, and deliver real-time awareness.

###### Protect Strategic Assets

Continuous surveillance of sensitive sites and critical infrastructure.

###### Strengthen Site Discipline

Biometric governance and permit control enforce operational discipline.

###### Improve Auditability

Tamper-proof logs and AI-generated reports support compliance and review.

Defence Security FAQ

## Frequently Asked Questions

Below are clear answers to common questions about our indigenous defence security platforms.

Solution Inquiry [079-49068001](tel:+917949068001)

###### What is DEPS and how does it secure defence perimeters?

DEPS - Defence Electronic Perimeter Security - is Mantra's purpose-built perimeter intrusion detection system for high-risk military and government sites. It combines intelligent sensor arrays, AI-based motion analytics, and real-time alert management to detect, classify, and report intrusion attempts along physical perimeters. The system is designed for harsh outdoor environments, supports 24/7 operations, and integrates directly with CCTV, lighting control, and command-room dashboards.

###### What are MARS AI and IPAS AI, and how are they different?

MARS AI (Multi-modal AI Recognition System) is Mantra's intelligent analytics platform for real-time identification and threat classification using video and biometric inputs. IPAS AI (Intelligent Perimeter and Access Security) extends this into access enforcement - combining AI-driven surveillance with automated gate control, biometric verification, and permit management. Together, they provide end-to-end identity assurance from the perimeter to interior restricted zones.

###### Is Mantra's defence security platform indigenously manufactured?

Yes. Mantra designs and manufactures its defence security platforms in India across a 1.5 lakh sq.ft. shop floor. All hardware - biometric terminals, RFID readers, sensor modules, and edge processing units - is developed under Make in India with in-house R&D and global technology patents. This ensures supply-chain security, customisation without vendor dependency, and alignment with government procurement preferences for critical infrastructure.

###### How does Mantra's Logical Security and ANPR module work in a defence context?

The Logical Security module governs digital access to defence networks, command systems, and classified data environments - enforcing multi-factor authentication and role-based access control. The ANPR (Automatic Number Plate Recognition) layer handles vehicle movement at garrison gates, ammunition depots, and restricted entry points - identifying, logging, and controlling vehicle access in real time with tamper alerts and full audit trails.

###### What Video Management and Border Security capabilities does Mantra offer?

Mantra's VMS (Video Management System) provides centralised recording, live monitoring, event-triggered playback, and AI-based video analytics across distributed camera networks at defence sites. For border security, the platform extends to perimeter surveillance, multi-sensor fusion, command-level situational awareness, and integration with ANPR and biometric checkpoints - supporting applications from forward operating bases to border fencing zones.

###### Which defence and government environments has Mantra deployed in?

Mantra's security systems are operational across military stations, ammunition storage facilities, naval installations, border infrastructure, government research campuses, and restricted government sites. Internationally, the platform is deployed in 40+ countries, with specific defence and critical infrastructure references across South Asia, the Middle East, and Africa.

###### How does the system maintain 24/7 situational awareness in remote or austere environments?

Mantra's platforms are engineered for continuous operation in demanding conditions - ruggedized hardware, edge processing to reduce bandwidth dependency, offline-capable biometric verification, and redundant communication paths. The central command layer receives live feeds, automated alerts, and event logs from all nodes, enabling commanders to maintain visibility even in connectivity-constrained environments.

###### Can the platform be customised for classified or sensitive defence requirements?

Yes. Because Mantra owns the full technology stack - from hardware design through firmware, application software, and integration APIs - the platform can be customised for specific classification levels, communication protocols, data isolation requirements, and interoperability with existing defence command and communication infrastructure. Customisation does not incur premium third-party licensing or vendor lock-in.

###### What certifications and compliance standards does the platform meet?

Mantra holds global technology patents and its platforms are designed to comply with government procurement frameworks, including those relevant to Make in India, domestic content requirements, and defence-grade quality standards. Specific certification details for individual platforms are provided during formal procurement engagement. The team can supply compliance documentation upon request.

###### How do we initiate a procurement or demonstration request?

You can reach Mantra's defence solutions team at servico@mantratec.com or use the Request a Demo form on this page. Mantra's defence engagement process begins with a confidential requirements assessment, followed by a platform demonstration against your site profile and threat model. Proposal timelines and demonstration formats are aligned to defence procurement schedules.

## Ready to Strengthen **Defence Surveillance?**

Connect with our team to explore biometric, access control, AI, and surveillance systems built for high-risk environments.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Solutions-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")