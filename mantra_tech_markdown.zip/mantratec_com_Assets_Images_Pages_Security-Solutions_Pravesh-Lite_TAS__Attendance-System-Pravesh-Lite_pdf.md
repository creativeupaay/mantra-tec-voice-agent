# PRAVESH-LITE

Powered by

## Aendance System

* * *

# Attendance System

Mantra’s attendance management provides you with a practical solution to reduce processing of employee time sheets and decrease human errors associated with manual time keeping process. It not only improves personal efficiency but also results in saving time & money both and undoubtedly, it enhances transparency in the system and further assists in building trusts in all level of engagements.

Attendance system design and structure supports quick and effective integration with ERP’s and HRMS solutions including SAP & Oracle and integral elements of corporate system strategy and execution.

The system provides end-to-end automation of tracking, managing and scheduling employee hours in a seamless manner with the interoperable Bio-metric technology and hardware controllers.

# Key highlights of Attendance Management system are as under:

u Highly configurable attendance rule engine u Employee perspective, beautiful views of own attendance, encourage punctuality, and bespoke u Quick and efficient attendance processing development for report generation. u Extensive shift management, with grouping and u Secured and real-time integration system integrated with holiday calendar

u Attendance raw data capture from hardware, seamless sync

Attendance Correction Time-saving attendance

Real-Time clock Calculates in/out time data overtime

# Attendance Management

Easy to Leave integrate management

Accurate time recording Eliminates data manipulation

* * *

Attendance System

| Product | Pravesh Lite X1 |  |
| --- | --- | --- |
| Variant Model | Card+FingerPrint |  |
| Kit/Box Material Details | Smart Card-10Card Hooks-10Card Holders-10AdapterSoftware BrochureHardware BrochureHardware Installation GuideEnrolment Guide |  |
| Hardware | MFS TabX |  |
| User Capacity | 1000 users |  |
| Hosting |  |  |
| Cloud | ✘ |  |
| On-Premise | ✓ |  |
| Device/Terminal Type |  |  |
| Non Mantra | ✘ |  |
| Mantra | ✓ |  |
| Smart Card | ✓ |  |
| Fingerprint | ✓ |  |
| Facial | ✘ |  |
| License | ✓ |  |
| Application | ✓ |  |
| Box Size | Large |  |

| Pravesh Lite X2 | Pravesh Lite X3 |
| --- | --- |
| Card+Face | Card+Face+Fingerprint |
| DeviceSmart Card-10Card Hooks-10Card Holders-10AdapterSoftware BrochureHardware BrochureHardware Installation GuideEnrolment Guide | Face+Fingerprint+Card DeviceSmart Card10NosLanyard10NosCard Holder10NosUser ManualLicence document |
| BioNIC F9 | BioNIC F9 |
| 1000 users | 1000 users |
| ✘ | ✘ |
| ✓ | ✓ |
| ✘ | ✘ |
| ✓ | ✓ |
| ✘ | ✓ |
| ✓ | ✓ |
| Large | Large |

* * *

Powered by

# [sales@mantratec.com](mailto:sales@mantratec.com) +91-79-49068001

Copyrights 2021 Mantra Sofech (India) Pvt Ltd. All Rights Reserved.