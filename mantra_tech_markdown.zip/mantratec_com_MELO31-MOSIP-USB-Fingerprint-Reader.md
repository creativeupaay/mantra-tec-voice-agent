[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")/ [Products](https://www.mantratec.com/Products)/ [Fingerprint Sensors](https://www.mantratec.com/Products/Fingerprint-Sensors)/MELO31FAP30 \| FBI PIV \| IP65 \| WHQL \| MINEX

# MELO31 FAP30 Optical Fingerprint Scanner

Rugged FAP30 optical fingerprint scanner with a large 20.32\*25.40mm enrollment-grade platen, FBI PIV certified image quality, IP65 water and dust protection, latent finger detection, and MINEX compliance.

National EnrollmentWet EnvironmentsLaw EnforcementE-Governance

[Get a Quote](https://www.mantratec.com/Products-Inquiry-Form) [Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MELO31/MELO31-MOSIP-L1.pdf)

![Mantra MELO31 FAP30 Optical Fingerprint Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MELO31/MELO31.png)

**FAP30** Optical

**500 DPI** 400\*500px

**IP65** Rugged

Key Highlights

## Large-Platen Precision for Enrollment at Scale

MELO31's FAP30 optical sensor with a large 20.32\*25.40mm platen captures 400\*500 pixel fingerprint images at 500 DPI - built for the most demanding biometric enrollment programs.

FAP30 Optical \| 500 DPI

### High Resolution Capture

Large FAP30 scratch-free optical platen (20.32\*25.40mm) captures 400\*500 pixel grayscale images at 500 DPI  2% - ensuring reliable capture of aged, or manual-labor fingerprints.

FBI PIV Certified

### FBI PIV Image Quality

Certified image quality meeting the highest standards for biometric identification and verification. WHQL-certified driver, CE/FCC Part 15B Class A, RoHS, BIS IS13252, and EN/IEC 62368-1 compliance.

IP65 Protection

### Dust & Water Protected

IP65 protection makes MELO31 dust-tight and able to withstand water jets - ideal for enrollment centers, outdoor government programs, and field deployments.

Latent Detection

### Live Finger Detection

Advanced latent finger detection distinguishes live from residual prints to prevent false captures. MINEX-compliant embedded extractor with FRR below 0.1% and FAR below 0.001%.

USB 2.0 Interface

### Single-Cable Connectivity

USB 2.0 IF-compliant interface with single-cable power and data. Three LED indicators provide real-time status for power, scan state, and image quality.

OS Compatibility

### Windows, Android & Linux

Supports Windows x86/x64, Android, and Linux. Outputs data in ISO 19794-2:2011 and ISO 19794-4:2011, WSQ3.1, and JPEG2000 formats.

Advanced Technology

## Built for National-Scale Biometric Enrollment

Robust engineering meets large-scale deployment needs for reliable biometric authentication.

Sensor Class

FAP30

500 DPI \| 400\*500px \| 20.32\*25.40mm large enrollment-grade platen.

Resolution

500 DPI

8-bit grayscale \| RED LED \| near-double the FAP10 area.

Protection

IP65

Dust-tight \| water-jet resistant \| ESD  15kV Air /  8kV Contact protection.

Platen Size

25.4mm

20.32\*25.40mm platen for reliable capture of aged, worn fingerprints.

Capture Speed

<2 sec

Latent finger detection \| MINEX extractor \| auto quality check.

Strategic Applications

## Discover Our Solutions

MELO31 powers identity programs across government, law enforcement, and banking sectors requiring high-quality biometric enrollment.

[Government \| Citizen ID **Citizen Identification** \\
Standardized enrollment for large-scale citizen identity and Aadhaar programs with FAP30-level quality.](https://www.mantratec.com/Solutions/Citizen-Identification) [Critical Infrastructure **Airport Solution** \\
Fast and reliable fingerprint capture for passenger processing, border security, and immigration control.](https://www.mantratec.com/Solutions/Airport-Solution) [Platform \| R&D **Biometric Technologies** \\
Cutting-edge multimodal biometric platforms for high-accuracy fingerprint recognition deployments.](https://www.mantratec.com/Solutions/Biometric-Technologies)

Specifications

## Technical Details

Full technical specifications for system integrators and procurement teams.

Sensor DetailsHardware & ElectricalEnvironmentalStandards & ComplianceSecurity & EncryptionSystem Req.

Sensor Characteristics

Fingerprint Sensor Type

Scratch Free Optical Sensor

Pixel Resolution

500 DPI  2%

Platen Area

20.32 mm \* 25.40 mm

Image Size

400 \* 500 Pixels

Image Grayscale

256 (8-Bit Gray Level)

FRR & FAR

< 0.1% & < 0.001%

Max Acquisition Time

< 2 sec (Placement to Template)

Latent Finger Detection

Yes

Light Source

RED LED

Capture Mode

Auto Finger detection functionality & Auto capture with built-in quality check (incorporates NIST quality considerations) & Support 360 Degree Fingerprint Rotation

Hardware & Electrical

Interface

USB 2.0 High Speed Protocol

Operating Voltage

5VDC  5% (USB Powered Device)

Operating Current

Operating Current: ~190 mA & Standby Current: ~90 mA

ESD Protection

Contact Discharge:  8kV, Air Discharge:  15kV

Device Dimensions

89.0 x 64.0 x 25.60 mm

Device Weight

~150g

Module Dimensions

75.0 x 49.0 x 23.0 mm

Module Weight

~90g

Environmental Characteristics

Operating Temp.

0°C to +50°C

Storage Temp.

-10°C to +70°C

Humidity

< 90% RH, Non-condensing (Operating / Storage)

Standards & Compliance

Biometric Data Format

ISO 19794-4 : 2005 & 2011, WSQ3.1, JPEG2000

EMI / EMC

CE & FCC Part 15B Class A

Image Quality

FBI PIV Certification

Environmental / IP

RoHS, WEEE \| IP65 Rating

Safety

EN/IEC 62368-1, IS 13252 (Part 1)

Device Driver

WHQL Certified Driver

Security & Encryption

Crypto Operation

Hardware base AES, SHA-256, TRNG support

Crypto Hardware Module

RSA-2048 Signing & Verification

Boot Security

Secure boot support by the device using secure crypto Module

OTA Capability

Over the Air signed and encrypted firmware update support

System Requirements

Operating System

Windows 10 & 11, Android, Linux

Standard Software / SDK

MOSIP-L1 Compliant SBI Service\*

Quality Check

NIST NFIQ Compliant

Compression

NIST Compliant WSQ Module

Segmentation

Flat-to-Single Fingerprint Segmentation

\*Applied for certification

Default 1 year RD service subscription & 1 Year Warranty are included, Renewal will be chargeable. For verification of your subscription tenure and Official Renewal visit [servico.mantratecapp.com](https://servico.mantratecapp.com/)

Resources

## Everything You Need to Deploy

[**Product Brochure** \\
Full product brochure with technical specs and application overview for MELO31.\\
Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MELO31/MELO31.pdf) [**Technical Support** \\
Raise a support ticket or connect with our expert biometric engineers.\\
Get Support](https://www.mantratec.com/Products-Inquiry-Form)

## You Ask. We Answer.

Our biometric specialists help you find the right fingerprint solution for your identity program.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")