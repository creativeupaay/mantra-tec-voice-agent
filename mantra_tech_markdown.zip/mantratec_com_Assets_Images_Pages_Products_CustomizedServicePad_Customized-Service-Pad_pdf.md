# Customized Service Pad

**Safe, Convenient & Modern Design**

**[www.mantratec.com](http://www.mantratec.com/)**

* * *

Customized Service Pad
\[Image: Im34\]

Safe, Convenient & Modern Design
\[Image: Im34\]

Humanized
Design
\[Image: Im34\]

Aesthetically Rich &
Ergonomics Taken Care.
\[Image: Im34\]

Introduction
\[Image: Im34\]

Features
\[Image: Im34\]

Cutting-edge visitor verification Customized Service Pad device designed for various business security needs. With
a 10.1-inch TFT LCD display and touch screen functionality, it offers a seamless user experience. The 33 LED white
backlight ensures crystal-clear visibility, while the capacitive fingerprint sensor with gold coating provides secure
verification. It also comes equipped with 10 USB 3.0 ports, a microphone, VGA and HDMI interfaces, and is certified
by BIS and ROHS. The Customized Service Pad is designed for easy table mounting and is the perfect solution for
your visitor management needs.
\[Image: Im34\]

Multi-touch Point
PCAP Display
\[Image: Im34\]

Designed to
reduce RSI
(Repeated Stress Injury)
\[Image: Im34\]

Superior Screen
Cast through HDMI In
\[Image: Im34\]

* * *

Safe, Convenient & Modern Design
\[Image: Im110\]

FINGERPRINT SENSOR
\[Image: Im110\]

\[Image: Im110\]

: Capacitive, Gold Coating
\[Image: Im110\]

\[Image: Im110\]

ŸŸ Power
Fingerprint Image
\[Image: Im110\]

\[Image: Im110\]

\[Image: Im110\]

Ÿ Fingerprint Type
Ÿ Image Specs
\[Image: Im110\]

\[Image: Im110\]

Ÿ Image Specs
\[Image: Im110\]

\[Image: Im110\]

\[Image: Im110\]

: 5V USB
\[Image: Im110\]

Ÿ Certifications
\[Image: Im110\]

:30^{\\circ}C+00+70^{\\circ}C

Ÿ Humidity

Ÿ Operating temperature

\[Image: Im110\]

Ÿ Operating temperature

Ÿ Package Size
\[Image: Im110\]

\[Image: Im110\]

\[Image: Im110\]

Storage temperature 18.0(L) mm \*12.8(W) mm
DISPLAY & TOUCH
\[Image: Im110\]

: 10.1’’ TFT LCD , 1024(R+G+B) \*600
\[Image: Im110\]

Dots a-Si TFT, Positive,Transmissive

\[Image: Im110\]

: 508DPI, 8 Bit Grayscale
\[Image: Im110\]

Ÿ Display Mode
Ÿ Backlight

\[Image: Im110\]

: 508DPI, 8 Bit Grayscale
\[Image: Im110\]

Ÿ Display Mode
\[Image: Im110\]

Ÿ Directivity
\[Image: Im110\]

Ÿ Sensitivity
\[Image: Im110\]

Storage Temperature

ŸŸ Interface

Ÿ Operating Temperature

\[Image: Im110\]

: Normally Blue

\[Image: Im110\]

Ÿ Luminance

Storage Temperature

Interface

\[Image: Im110\]

Ÿ Viewing Direction

: FIPS 201 Compliant, IP65
Luminance

\[Image: Im110\]

\[Image: Im110\]

Ÿ Size
\[Image: Im110\]

SNR
ŸŸ Obstruction
Ÿ Frequency
\[Image: Im110\]

: 9.7mm\*6.7mm
\[Image: Im110\]

: 33 LED White Color

\[Image: Im110\]

\[Image: Im110\]

: -30 : DC 4.5V ℃ to +70℃
\[Image: Im110\]

MICROPHONE
Storage Humidity

\[Image: Im110\]

Ÿ VGA
\[Image: Im110\]

HDMI Splitter + Cable

\[Image: Im110\]

Ÿ HDMI
\[Image: Im110\]

Ÿ Power Supply : DC 5V 1A
\[Image: Im110\]

\[Image: Im110\]

Ÿ Input Ports
\[Image: Im110\]

\[Image: Im110\]

:0^{\\circ}C\\sim\\Delta0^{\\circ}C

Ÿ Input Ports
\[Image: Im110\]

Ÿ Output Ports
\[Image: Im110\]

Ÿ Output Ports
\[Image: Im110\]

: 4 x HDMI Female output ports
\[Image: Im110\]

Ÿ Frequency Bandwidth : 1 x HDMI Female input port
\[Image: Im110\]

\[Image: Im110\]

Ÿ Power Consumption
\[Image: Im110\]

Ÿ Display Resolution
\[Image: Im110\]

Operating Temperature
\[Image: Im110\]

Ÿ Display Resolution
\[Image: Im110\]

\[Image: Im110\]

Dimensions
ŸŸ Operating Temperature
\[Image: Im110\]

Material
Storage Temperature USB HUB
\[Image: Im110\]

Version : 12V/3A
ŸŸ Relative Humidity
\[Image: Im110\]

ŸŸ Relative Humidity
\[Image: Im110\]

\[Image: Im110\]

Ÿ HDMI Cable : 5W
Ÿ Power Supply
USB Cable : 5V/ 1.5A
\[Image: Im110\]

Ÿ Power Supply
Ÿ USB Cable : 5V/ 1.5A
\[Image: Im110\]

Ÿ USB Port Rating
\[Image: Im110\]

Ÿ Operating Humidity
\[Image: Im110\]

Ÿ Casing
Ÿ Power

\[Image: Im110\]

USB Port Rating
Operating Temperature
\[Image: Im110\]

: ABS Plastic
Operating Temperature
\[Image: Im110\]

Ÿ Material
: 10 x USB 3.0
GENERAL PARAMETER
\[Image: Im110\]

Operating Temperature
ŸŸŸ USB PORT Data Transfer Rate
\[Image: Im110\]

Ÿ Operating Temperature
Mounting type
\[Image: Im110\]

ŸŸ Storage Temperature Weight
Ÿ Material
\[Image: Im110\]

: 0℃~40℃
: Upto 5 Gbps
\[Image: Im110\]

* * *

Support : [servico@mantratec.com](mailto:servico@mantratec.com) Sales : [sales@mantratec.com](mailto:sales@mantratec.com)