[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home") Terms Of Use

# Terms Of Use

## Acceptance

These following terms and conditions that govern your use of the stocks images information, materials, documents and other underlying data, being made available to you without obligation at this website. By using the Materials, you expressly signify to have agreed to all the terms, conditions, and notices contained or referred herein (the "Terms of Use"). If you do not agree to these Terms of Use then you may not use this website or the Materials. We reserve the right, at our discretion and will, to update or revise these Terms of Use. You are advised to please check the Terms of Use time to time for such changes. Continued use of this website by you, following the posting of any change or updates to the Terms of Use will be deemed as constituted acceptance of the same by you.

* * *

## Electronic Mail Delivery Policy and Your Consent

By using the Materials, you consent to receive from website in all communications, including notices, agreements, legally required disclosures or other information in connection with the Materials electronically. website will provide such electronic Notices by posting them on this website. If you want to withdraw your consent to receive Notices electronically, you have to discontinue your use of this website and the Materials herein.

* * *

## Proprietary Rights

You agree and acknowledge that the Materials are protected by copyright, trademark, patent, trade secret, and other applicable proprietary rights and laws in force by the time of this agreement and in future. Third parties Materials appearing on this website have the copyright in the Materials original to them. The look, feel and overall impression of uniqueness of this website, including our colour combinations, button shapes, mark ups and other unique graphical elements, content on this site including the site structure, layout and juxtaposition of the site, text, graphics, logos, icons images are website's exclusive Trademarks or Copyright impressions and website assert moral and legal rights in continuity to be the rightful owner of the same.

* * *

## Procedure For Making Claims Of Copyright Infringement

We respect the idea of Intellectual property right. If you believe that your work has been copied in some way and is accessible on this website in a way that constitutes copyright infringement, you may notify website.

* * *

## No Warranties

This website and the materials are provided with all faults on an "as is" and "as available" basis. website, its licensors and other suppliers disclaim all such warranties, whether express or implied, including the warranties that the website and materials are free of defects, virus free, and able to operate on the uninterrupted basis, that they will meet your requirements specific or otherwise, or that such errors will be corrected, and the implied warranties that the website and materials are merchantable, of the satisfactory quality, accurate, fit for a particular purpose or need, or non-infringing, unless such implied warranties are legally incapable of exclusion from law provisions. No advice or information given by us, its affiliates or their respective employees or authorized agents will create, constitute a warranty or expand the scope of any warranty that cannot be disclaimed under applicable law or contained herein. Your use of this website and the materials is solely at your own risk.

Some laws and jurisdictions do not allow the exclusion of implied warranties, so the above exclusions may not apply to you.

However your use of the website and Materials is at your own risk and website is and will not be under no obligation to provide you with any support, error corrections, updates, upgrades, bug fixes and/or enhancements of the website and Materials unless there is a specific contract to such nature with you.

Please note that the Materials may include technical inaccuracies or typographical errors unique to the Materials, website has the right at any time to change, modify, reformat, add to or discontinue or retire any aspect or feature or considerable part of the Material or a theme of the website or Materials, including, but not limited to, the software, content, hours of availability, equipment needed for access or use, or the availability of the website or Materials on any particular device or communications service. website has no obligation to provide you with notice of any such changes.

* * *

## Limitation of Liability

Under no circumstances shall website, its parent, affiliates, directors, employees, distributors, suppliers, agents or resellers be liable for any indirect, special, incidental, direct, consequential, tortious, act of god or exemplary damages that result from the use of, misuse of, inability to use, or reliance upon this website or the materials, including, without limitation, damages for loss of use, data, business opportunities, or profits. This limitation applies whether the alleged liability is based on contract, tort, negligence, strict liability, or any other basis, even if the website has been advised of the possibility of such damage.

Some laws and jurisdictions do not allow the exclusion of implied warranties, so the above exclusions may not apply to you.

Additionally, under no circumstances shall the website be held responsible or liable, directly or indirectly, for any loss or damage caused or alleged to have been caused to you in connection with the use of or reliance on any content, goods or services available on or through any external sites linked from this website. Nor website will be responsible for any loss of data of any type stored at the device installed at your end while using this site. While producing the contents website ethically takes care of the quality of contents and do not mean to be offensive towards any particular individual or a religious group. However website assume no responsibility if you or some member of a religious group does not appreciate some or any part or whole content of a written Material or any sketched, cartographic, click-able visual image and find them offensive. website will not be liable to any kind of consequential damages arising out of such person's reaction or mental shock.

* * *

## Force Majeure

Without limiting the foregoing, under no circumstances shall the website be held liable for any delay or failure in performance that may be the result of direct or indirect acts of nature, forces, or deemed unexplained causes beyond its reasonable control, including, without limitation, the Internet failures, computer and other associated equipment failures, telecommunication equipment or service provider failures, electrical power failures, other equipment failures, strikes, labour disputes, riots, insurrections, insurgency, civil disturbances, shortages of labour or materials, fires, floods, storms, explosions, acts of God, war, governmental actions and policies, orders of domestic or foreign courts or tribunals, non-performance of third parties, or loss of or fluctuations in temperature, heat, light, or air conditioning.

* * *

## Indemnification

Receiving a written request by www.mantratec.com you agree to defend, indemnify, and hold harmless the www.mantratec.com from all liabilities, claims, and expenses, including attorney's fees, that may arise from your use or misuse of the Materials or this website. www.mantratec.com reserves the right, at it own expense, to assume and take up the exclusive defence and control of any matter otherwise subject to this indemnification by you, in which event you will cooperate with www.mantratec.com in asserting any available defences.

* * *

## Disclaimer of Endorsement

Reference herein or on the website to any products sold or made available by www.mantratec.com, or hypertext links to third parties advertisement or other information by trade name, trademark, manufacturers, suppliers or otherwise, does not constitute or imply its endorsement, sponsorship or recommendation by www.mantratec.com in respect of the charter, quality or contents of such goods. Product, service information and content quality are the sole responsibility of each individual vendor or supplier. There will be no extended warranty expressed or implied by www.mantratec.com for any such services or products sold by third party or hyper linked via this website.

* * *

## Choice Of Law And Forum

Contained herein the Terms of Use shall be governed by and construed to be in accordance with the laws of the Republic Of India. You expressly agree and consent that the exclusive jurisdiction for any claim or action arising out of or relating to these Terms of Use or your use of the Materials and this website shall be filed only in the courts located under the jurisdiction of Hon'ble High Court.

* * *

## Agreement Severability And Integration

The Terms of Use in here will constitute the entire agreement between you and www.mantratec.com with respect to the Materials and this website. If any part of these Terms of Use is held invalid or unenforceable then that portion will be read and construed in such a manner that will be consistent with applicable law to reflect, as nearly as possible, the original intentions of the parties to agreement, and the remaining portions shall remain in full force and effect as per this agreement and governing laws.

* * *

## Agreement Termination

Without prejudice www.mantratec.com. reserves the right, on its sole discretion, to terminate your access to the Materials or to all or part of this website, with or without notice.

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")