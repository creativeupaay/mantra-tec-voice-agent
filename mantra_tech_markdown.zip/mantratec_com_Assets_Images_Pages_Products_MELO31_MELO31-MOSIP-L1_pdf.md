# MELO31

## Optical Fingerprint Scanner

### Integrated with MOSIP\*

Mantra Softech is a Global Hi-Tech Manufacturer of Biometric Products and Solutions. We offer a Wide Range of Products in Biometric and RFID Industry.

Operating USB 2.0 IP65 Lower FBI PIV Wet Systems FAR & FRR Certified Fingerprints

* * *

# OPTICAL FINGERPRINT SCANNER

# Introduction

FBI PIV certificated, MELO31 is a versatile and field-proven optical FAP30 capture area fingerprint scanner. It comes with a large platen area (20.32mm x 25.40 mm) to capture biometric data with great precision, speed and convenience. An array of advanced features like latent detection, lower false acceptance rate (FAR) & false recognition rate (FRR) and MINEX compliance embedded extractor support make it suitable for extensive applications that require optimum security and high accuracy. Backed with rugged and scratch-free sensor, MELO31 serves a wide range of industries to ensure seamless identification, verification and authentication.

# Benefits

u Speedy scanning u Durable u High precision u USB 2.0 high speed interface u Easily integrates with compatible devices

# Features

Scratch Free Optical Sensor FBI PIV Certificated MINEX III certified high performing fingerprint algorithm Latent Fingerprint detection Support NIST compliance WSQ/JPEG Image compr ession standard Support ISO/IEC 19794-4:2005/2011 Biometric Data Interchange Format Capture high quality image with Dry, Moist, Wet or Rough fingerprints Lower FRR and FAR IP65 rating water and dust protection for outdoor application

* * *

At a Glance

| Sensor Characteristics | Fingerprint Sensor Type |
| --- | --- |
| Pixel Resolution |  |
| Platen size |  |
| Image Size |  |
| Image Grayscale |  |
| FRR&FAR |  |
| Maximum Acquisition time(Placement to Template) |  |
| Capture mode |  |
| Latent Finger Detection |  |
| Light Source |  |
| Security | Crypto Operation |
| Crypto Hardware Module |  |
| Boot |  |
| OTA Capability |  |
| Interface | Protocol |
| Electrical Characteristics | Operating Voltage |
| Operating Current |  |
| Environmental Characteristics | Operating Temperature |
| Storage Temperature |  |
| Humidity(Operating/Storage) |  |
| Compliant to Following Standard | Biometric Data Interchange Form |
| EMI/EMC Compliance |  |
| ESD protection |  |
| Environmental,Health and Safety |  |
| Safety |  |
| Image Quality |  |
| IP Rating |  |
| Device Driver |  |

|  | : Scratch Free Optical Sensor |
| --- | --- |
|  | : 500 DPI +/-2% |
|  | : 20.32 mm x 25.40 mm |
|  | : 400 x 500 |
|  | : 256 (8-Bit Gray Level) |
|  | : <0.1%&<0.001% |
|  | : <2Sec |
|  | : Auto Finger detection functionality&Auto capture with built-in quality check(incorporates NIST quality considerations)&Support 360 Degree Fingerprint Rotation |
|  | : Yes |
|  | : RED LED |
|  | : Hardware base AES,SHA-256,TRNG support |
|  | : RSA-2048 Siging&Verification |
|  | : Secure boot support by the device using secure crypto Module |
|  | : Over the Air sign and encrypted firmware update supports. |
|  | : USB 2.0 High Speed |
|  | : 5VDC±5%(USB Powered Device) |
|  | : Operating Current: ~~190mA&Standby Current:~~ 90mA |
|  | : 0℃ to+50℃ |
|  | : -10℃ to+70℃ |
|  | : <90%RH,Non-condensing |
| mat | :ISO 19794-4:2005&2011,WSQ3.1,JPEG2000 |
|  | :CE&FCC Part 15B class A |
|  | :Contact Discharge:+/-8kV,Air Discharge:+/-15kV |
| y | :RoHS,WEEE |
|  | :EN/IEC 62368-1,IS 13252(Part 1) |
|  | :FBI PIV Certification |
|  | :IP65 |
|  | :WHQL Certified Driver |

:0^{\\circ}C cot550^{\\circcirc}C

-10^{\\circ}C O+70^{\\circ}C

* * *

# OPTICAL FINGERPRINT SCANNER

# At a Glance

**Module (L x W x H)** : 75.0 x 49.0 x 23.0 mm

## Dimensions Module Weight approx:

: 90g **Device (L x W x H)** **Device Weight approx:** **Operating System** : Windows 10 & 11, Android, Linux **System** **Requirements** **Standard Software/SDK** : 89.0 x 64.0 x 25.60 mm : MOSIP-L1 Compliant SBI Service \* **Applied for certification**

# Certification Certification Certification Certification Certification

: 150g

Default 1 year RD service subscription & 1 Year Warranty are included, Renewal will be chargeable. For verification of your subscription tenure and Official Renewal visit [https://servico.mantratecapp.com](https://servico.mantratecapp.com/)

* * *

# Support : [servico@mantratec.com](mailto:servico@mantratec.com) Sales : [sales@mantratec.com](mailto:sales@mantratec.com)