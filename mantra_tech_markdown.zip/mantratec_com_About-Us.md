[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home") About Us

# About Us

![Mantra biometric technology solutions](https://www.mantratec.com/Assets/Images/Pages/AboutUs/Building-Trust-Through-Biometric-Innovation.jpg)

Our Beginning

## Building Trust Through Biometric Innovation.

Founded in 2006, Mantra Softech emerged from the vision of pioneering innovators committed to transforming digital security. As India's leading biometric and RFID manufacturer, we've built our reputation on delivering cutting-edge identity management solutions that millions trust daily across government, banking, healthcare, and enterprise sectors worldwide.

![HCL Technologies](https://www.mantratec.com/Assets/Images/Pages/AboutUs/about_mantra_comapny_logos/HCL-Technologies.jpg)![Wipro](https://www.mantratec.com/Assets/Images/Pages/AboutUs/about_mantra_comapny_logos/Wipro.jpg)![Larsen & Toubro](https://www.mantratec.com/Assets/Images/Pages/AboutUs/about_mantra_comapny_logos/Larsen-and-Toubro.jpg)![ICICI Bank](https://www.mantratec.com/Assets/Images/Pages/AboutUs/about_mantra_comapny_logos/ICICI-Bank.jpg)![HDFC Mutual Fund](https://www.mantratec.com/Assets/Images/Pages/AboutUs/about_mantra_comapny_logos/HDFC-Mutual-Fund.jpg)![Siemens](https://www.mantratec.com/Assets/Images/Pages/AboutUs/about_mantra_comapny_logos/Siemens.jpg)

Our Purpose

## Securing Tomorrow's Digital Identity Ecosystem Today.

Through relentless innovation in biometric technology, AI-powered facial recognition, and RFID solutions, we empower organizations to authenticate with confidence. Our commitment extends beyond manufacturing products as we deliver complete security ecosystems to improve operational efficiency while protecting your biometric identity.

![Mantra Innovation that counts](https://www.mantratec.com/Assets/Images/Pages/AboutUs/abstract-fingerprint-swirling-deep-blue-surface.jpg)

![Manufacturing facility icon](https://www.mantratec.com/Assets/Images/Pages/AboutUs/stat-icon-manufacturing-facility.png)

### 300,000+

sq. ft. Biometric Manufacturing Facility

![Professionals icon](https://www.mantratec.com/Assets/Images/Pages/AboutUs/stat-icon-dedicated-professionals.png)

### 1,400+

Dedicated Professionals

![Market share icon](https://www.mantratec.com/Assets/Images/Pages/AboutUs/stat-icon-market-share.png)

### 20%

Market Share Among India's Top 50 Corporate

![Revenue icon](https://www.mantratec.com/Assets/Images/Pages/AboutUs/stat-icon-annual-revenue.png)

### $70 Million

Annual Revenue

Our Evolution

## Pioneering Excellence from startup to global leader

Helping millions around the world manage their digital identity requirements.

2006

###### Company Incorporation

Mantra Softech India Private Limited officially incorporated, marking the beginning of India's biometric innovation journey.

2008

###### Market Validation

Briefly imported and sold biometric devices to understand market dynamics and develop customer-centric solutions.

2010

###### Indigenous Innovation

Successfully developed proprietary fingerprint sensor and algorithm with embedded software, achieving technological self-reliance in biometrics.

2012

###### STQC Certification

Received prestigious STQC Certificate from UIDAI for Aadhaar program, becoming trusted partner in national identity.

2014

###### FBI Recognition

Achieved FBI certification for fingerprint scanner, validating world-class quality standards and international compliance capabilities.

2016

###### IRIS Innovation

Developed advanced IRIS sensor for eye authentication and launched mobile fingerprint and IRIS systems.

2018

###### Brand Expansion

Launched RF Energie for RFID solutions alongside Servico, MINOP, and Mivanta, diversifying technology portfolio significantly.

2019

###### Strategic Brands

Introduced Merepos and Moreze brands, creating specialized market segments for POS terminals and enterprise security solutions.

2021

###### R&D Recognition

R&D unit officially recognized by Ministry of Science and Technology for groundbreaking contributions in biometric technology.

2022

###### Patent Achievement

Received Technology Patent Certification for innovative Optical Fingerprint Scanner, protecting proprietary intellectual property and innovation leadership.

2023

###### NIST Listing

Mantra Softech officially listed on NIST for both Face and Fingerprint recognition, achieving global benchmarking.

2025

###### World First

Achieved world's first Dual IRIS iBeta certificate, establishing new global standards in biometric liveness detection.

![Mantra technology innovation](https://www.mantratec.com/Assets/Images/Pages/AboutUs/startup-to-global-leader.jpg)

[**Clientele** \\
Showcasing partnerships with businesses from a wide range of industries, each from our tailored solutions, designed to meet the unique challenges with swift flexibility.\\
Read More _→_](https://www.mantratec.com/Clientele)

[**Solutions** \\
Enterprise security systems, smart city infrastructure, and national ID programs designed for seamless integration and scalability.\\
Read More _→_](https://www.mantratec.com/Solutions)

[**Partners** \\
Our network spans system integrators, technology partners, and resellers worldwide, creating a trusted ecosystem that amplifies our reach.\\
Read More _→_](https://www.mantratec.com/Partners)

[**Brands** \\
Mantra serves diverse market needs through its sister companies, delivering focused innovation across identity management, security with proven excellence.\\
Read More _→_](https://www.mantratec.com/Brands)

## Connect With Us

Our team of experts is ready to help you navigate your digital identity challenges.

[Contact Us](https://www.mantratec.com/Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")