[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Products](https://www.mantratec.com/Products) [Fingerprint Sensors](https://www.mantratec.com/Products/Fingerprint-Sensors) MFS110

FBI PIV \| STQC L1 \| Aadhaar

# MFS110 L1 Fingerprint Scanner

MFS110 is an elegant fingerprint device used for identification, verification and authentication processes of an individual. Offers secured biometrics data, error-free and reliable identification based on unique fingerprint biometric technology. It is fast, easy-to-use, and serves as an alternative or complement to passwords.

Aadhaar eKYCNational IDLaw EnforcementBanking KYCBorder Control

[Get a Quote](https://www.mantratec.com/Products-Inquiry-Form) [Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.pdf)

![Mantra MFS110 L1 Fingerprint Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.png)

**500 DPI** Optical

**FBI PIV** Certified

Key Highlights

## Hardware-Grade Security in an Elegant Scanner

MFS110 is a fast, compact, and easy-to-handle fingerprint device offering secured biometric data, error-free and reliable identification based on unique fingerprint technology.

UIDAI \| CE \| FCC \| IS13252

###### FBI PIV & STQC L1 Certified

Certified to FBI PIV-071006 and STQC L1 standards - the highest compliance levels for Aadhaar authentication and national identity programs. Also compliant with EN/IEC 62368-1, IS13252 Part 1, and ISO 19794-2/4.

RSA2048 \| AES-GCM-256 \| TEE

###### Hardware Cryptographic Security

Onboard RSA2048 key generation, AES-GCM-256 encryption, SHA-256 hashing, and TRNG. TEE (Trusted Execution Environment) support with secure memory and key-wrapping - plus secure boot to prevent firmware tampering.

276\*336px \| 8-Bit Grayscale \| <2 sec

###### 500 DPI Optical Sensor - Auto Capture

High-resolution optical sensor at 500 DPI 2% with 256 grayscale levels captures forensic-quality fingerprints in under 2 seconds. Auto-capture with NIST quality considerations ensures consistent results across all finger types.

5V \| <90mA \| WHQL Driver

###### USB 2.0 Bus-Powered - Plug & Play

USB-IF compliant, bus-powered at 5V (under 90mA) - works with any standard USB host without an external power adapter. WHQL-certified Windows driver for instant recognition on Windows, Android, and Linux platforms.

61\*91\*54mm \| 140g \| Red LED

###### IP54 Rated - Scratch-Free Platen

IP54-rated enclosure protects against dust and water splashing for reliable field operation. Scratch-free sensor surface and optical platen (16.0 mm x 19.0 mm) with Red LED illumination ensures long service life.

ISO 19794-2 \| ISO 19794-4

###### MINEX Compliant & Auto Detection

MINEX-compliant minutiae extractor for interoperable biometric templates. Auto finger detection with lowest FAR and FRR, supporting 180o rotation authentication. Outputs ISO 19794-2 minutiae and ISO 19794-4 image data in encrypted PID blocks.

More Details

## Built for the Highest-Security Identity Programs

![MFS110](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.png)

### MFS110

FBI PIV & STQC L1 Certified Scanner

Hardware Security

### RSA2048

AES-GCM-256 \| SHA-256 \| TRNG \| TEE \| Secure Boot onboard

Resolution

### 500 DPI

276\*336px \| 8-bit grayscale

Certification

### FBI PIV

STQC L1 \| UIDAI \| CE \| FCC

Protection

### IP54

Dust & Water resistant enclosure

Speed

### <2 sec

Auto-capture \| NIST quality

Accuracy

### FAR <0.001%

MINEX-compliant extractor \| ISO output

Applications

## Trusted for Every Identity Program

MFS110 powers Aadhaar authentication, national ID, law enforcement, and enterprise IT security across India and beyond.

[Aadhaar - e-Governance **Aadhaar eKYC & Public Distribution** \\
\\
STQC L1 certified capture enables direct Aadhaar verification for AePS, Public Distribution System (PDS), E-Governance, and welfare service delivery programs.](https://www.mantratec.com/Solutions/Citizen-Identification)

[Law Enforcement - AFIS **Forensic & Law Enforcement Identification** \\
\\
FBI-certified latent-quality images meet AFIS interchange standards for criminal database enrollment, border control, and forensic investigation.](https://www.mantratec.com/Solutions/Citizen-Identification)

[Enterprise & Corporates **PC Login & Network Security** \\
\\
Replace passwords with fingerprint-secured Windows login, VPN access, and privileged-user management across corporate, enterprise, and institutional environments.](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions)

[Banking & Payments **Banking KYC & Merchant Payments** \\
\\
Plug-and-play integration with CBS, payment systems, and KYC platforms enables fingerprint-verified account opening, merchant payments, and regulatory compliance.](https://www.mantratec.com/Solutions/Citizen-Identification)

Specifications

## Technical Details

Complete specifications for procurement, IT managers, and system integrators.

SensorSecurityElectricalEnvironmentalStandards & Compliance

Sensor

Fingerprint Sensor Type

Optical Sensor

Spatial Resolution

500 DPI 2%

Platen Area

16.0 mm X 19.0 mm

Image Size

276 X 336 Pixels

Image Grayscale

256 (8 - Bit Gray Level)

Light Source

Red LED

Maximum Acquisition time (Placement to Template)

< 2 Sec

Approx. Dimension (L x W x H)

91 x 61 x 54 mm

Approx. Weight

0.14 kg

Capture Mode

Auto capture with built-in quality check (incorporates NIST quality considerations)

Certifications

CE, RoHS, BIS, IP54

Security

Crypto Operation

Hardware base RSA2048 Key Generation, AES-GCM-256, SHA-256, TRNG support

Secure Memory

TEE support by the device. Secure memory support key wraping feature

Secure Boot

Secure boot support by the device

Electrical

Operating Voltage

5V  5% (USB Powered Device)

Operating Current

< 90 mA

Stand by Current

50 mA

Interface

USB 2.0

Environmental

Operating Temperature

0 to 50 oC


Storage Temperature

0 to 50 oC


Humidity (Operating / Storage)

<90% RH, Non-Condensing

Compliant to Following Standard

Biometric Data Interchange Format

ISO 19794-2 for minutiae & ISO 19794-4 for Image Template in Encrypted PID Data Block

Safety

EN/IEC 62368-1, IS 13252 (Part 1)

EMI / EMC Compliance

CE, FCC Part 15B

Environmental, Health and Safety

RoHS

Image Quality Compliance

FBI PIV, STQC

IP Rating

IP54

Device Driver

WHQL certified

Operating System

Windows 10 above, Linux, Android

Default 1 year RD service subscription & 1 Year Warranty are included, Renewal will be chargeable. For verification of your subscription tenure and Official Renewal visit
[servico.mantratecapp.com](https://servico.mantratecapp.com/)

Resources

## Everything You Need to Integrate

[**Product Brochure** \\
Full datasheet with sensor specs, certifications, dimensions, and application overview for MFS110.\\
Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.pdf)

[**Buy Online** \\
Purchase MFS110 directly from the Mantra online store with fast fulfilment.\\
Shop Now](https://servico.mantratecapp.com/Product/Product.aspx?i=MFS110)

## Expert Technical Support

Our biometric engineers can help you integrate MFS110 into your Aadhaar or identity application.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")