# PV2000

## INDUSTRIAL PALM VEIN ATTENDANCE TERMINAL

**PV2000** terminal built on industries best contact less biometric identification technology. This terminal is high end Industrial biometric

### identification terminal that recognizes person with the help of Palm Vein

patterns. This Terminal also can be used for various Industrial applications like Labor management, Contract worker management, Canteen management, Attendance and Worker’s access control etc. Palm Vein pattern is most secure and most perfect biometric signature for matching. It is best suited for Industries where other biometric does not work due to difficult conditions.

* * *

Features

PV2000

t Color 6.5'' LCD display

t Capture photo on recognition of palm Vein pattern

t Better hand guide to place Palm in efficient manner

t External reader connectivity (optional)

t Optional EM card / Mifare / HID Prox / HID Smart card reader

t Palm V ein sensor is certified by CE, FCC

t Industrial terminal enclosure

t V oice, audio and visual confirmation on successful and nonsuccessful matching

Highlights

t Live Palm Vein detection

t User define matching threshold

t Industrial metal Housing
Optional EM card / Mifare / HID Prox / HID Smart card reader

Specifications

t 100% enrollment rate

t Palm V ein control panel support

t 100000 users capacity

t 1000000 transactions log capacity

t False Acceptance Rate 0.00008%

t 1:1 and 1:G matching options

t 100 users group can be defined (0-99)
t Matching speed 2 seconds for 1:1 matching

t Matching speed 2 seconds for 1:1 matching
t 5 LED for user indication

t TCP/IP and USB pen drive connectivity

Mantra Softech India Pvt. Ltd.
Email: [sales@mantratec.com](mailto:sales@mantratec.com)

t Direct 230V AC power input

t Dimension 11 x 8 x 4 inch

t 6.5 inch color LCD

Mantra Softech India Pvt. Ltd.
Email: [sales@mantratec.com](mailto:sales@mantratec.com) [http://www.mantratec.com](http://www.mantratec.com/)

t Access control feature (optional)

t Built in voice / buzzer

t 18 keys keypad to operate terminal control panel

t 2MP in built camera (optional)

qSurat