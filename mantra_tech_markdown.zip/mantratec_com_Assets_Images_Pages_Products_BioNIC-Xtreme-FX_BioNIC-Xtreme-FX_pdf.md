## Elegant and Secure Facial Authentication Terminal

# BioN

BioNIC Xtreme marks a breakthrough in security technology, using deep learning and an advanced AI processor (NPU) for ultra-precise and fast facial recognition. Discover the future of security with BioNIC Xtreme.

C F

* * *

FACIAL AUTHENTICATION TERMINAL

Introduction

The BioNIC Xtreme devices epitomize the evolution of security technology, integrating a comprehensive suite of cutting-edge features
for unparalleled protection. This groundbreaking series includes Facial Recognition (FR) and a Contactless Card at 13.56 MHz, creating
a multifaceted approach to identity verification and access control. What sets the BioNIC Xtreme series apart is its seamless
connectivity through 4G LTE, enabling real-time monitoring and remote management. Whether securing critical facilities, ensuring
safety compliance, or enhancing workplace access, these advanced devices empower organizations to embrace a new standard of
security, making them the intelligent choice in today's security-conscious world

Certifications

Dual RGB and
Near Infrared Camera
2 Million WDR Pixel Resolution

Type A/B Cards,
MIFARE Classic / DESFire

5 Inch,

Vertical Screen
H1080 \* W1920
Resolution
Multi point capacitive touch screen
with tuffen glass

* * *

INTRODUCING
Superior AI Based Physical Access Management with Screen Cast Feature

| PRODUCT MODEL | PRODUCT NAME | PRODUCT CODE | DESCRIPTION |
| --- | --- | --- | --- |
| BioNIC Xtreme™ | BioNIC FX | BX051XX1X | 5"/Face/Android |
| BX051XX2X | 5"/Face/Linux |  |  |
| BX051X11X | 5"/Face/4G/Android |  |  |

Specification

Hardware & System

CPU : 2.2GHz Quad core ARM Cortex-A73 and 1.8GHz dual core Cortex-A53
GPU : ARM G52 MP4 GPU
: 2GB + 16GB
Memory (RAM + Storage)

Display : 5 Inch, 1080X1920 Resolution, Full view IPS TFT Display
Touch

| Network Module | :1xRJ45,10M/100M |
| --- | --- |
| Wi-Fi/BT | :Supported |
| Audio | :Supported |
| HDMI Out | :1XHDMI |
| RS232 | :1xRS232 |
| RS485 | :1xRS485 |
| Wiegand Interface | :1xOutput;1xInput |
| Relay Interface | :2xRelay(NC,NO,COM) |
| Power Jack | :DC5V/3A |
| Supervised Input(Configurable) | :1.EgressSwitch,2.FireAlarm,3.EmergencySwitch,4.LockDownSwitch |
| Supervised Output(Configurable) | :1.Alarm |
| RTC | :Supported |

Interface

Supervised Input (Configurable)
SmarSupervised Output (Configurt Card Reader

* * *

FACIAL AUTHENTICATION TERMINAL

Specification

Binocular Wide Dynamic Camera (RGB + IR)

Camera Type : Dual RGB and Near Infrared Camera
Pixel Resolution
Frame Rate

Minimum Illumination
: 2M (1920 x1080)
Dynamic Range
Focus Distance

White Balance Functions/Features

Face Detection : Support multiple people detection and tracking
Photo Flood Light

Face Database Capacity
Support 1:N Face Recognition
1:1 Face-matching
User & Log Capacity
: = 0.1 LUX
Stranger Detection
: 10000 / 50000

Face Recognition Accuracy
Liveness Detection
Recognition Speed

SoTransmission Rate ftware

: 1M
Casing / Linux y back cover for heat dissipation
: Supported : Light weighted oxidised aluminium allo
: Dust Pr opriate SDK for all accessories to be pr oof ovided
: Normal Light Condition > 99.9% : Appr
Protection Grade
: -10℃ ~~60℃
: -20℃~~ 60℃
Operating Temperature : Visible & IR dual Flood Light

: 10%-90% RH (Non-Condensing)
Storage Temperature
/ External Light Condition > 95%
Operating Humidity

Dimensions
Certifications
Weight

* * *

# FACIAL AUTHENTICATION TERMINAL

# Vertical Wide Angle Horizontal Wide Angle

## BioNIC FX

Solution Design/BioNIC\_FX/V1R1/2024-25

* * *

# Support : [servico@mantratec.com](mailto:servico@mantratec.com) Sales : [sales@mantratec.com](mailto:sales@mantratec.com)