[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Products](https://www.mantratec.com/Products) Datasheets

TECHNICAL RESOURCES

# Product Datasheets & Specifications

Download official technical datasheets for Mantra Softech's complete biometric product range — detailed specifications, connectivity options, and performance metrics.

**53+** Datasheets

**11** Categories

**PDF** Format

Category Filter

- All Products
- Aadhaar Biometric Attendance
- Biometric Enrollment Devices
- POS MicroATM Terminal
- Integrated Biometric Devices
- Fingerprint Sensors
- IRIS Sensor
- Face Recognition Device
- Biometric Tablet
- Physical Access Control
- Logical Access Solutions
- Aadhaar Products

## All Datasheets

### Aadhaar Biometric Attendance

UIDAI certified attendance systems datasheets

![L1 Fingerprint Scanner MFS110](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.png)

### L1 Fingerprint Scanner MFS110

UIDAI certified L1 fingerprint scanner with FAP10 optical sensor.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.pdf)

![MIS100 V2 Iris Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MIS100V2/MIS100V2.png)

### MIS100 V2 Iris Scanner

High-accuracy single iris scanner certified for Aadhaar enabled attendance.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MIS100V2/MIS100V2.pdf)

### Biometric Enrollment Devices

High-speed multimodal enrollment datasheets

![MORPHS Slap Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MORPHS/MORPHS.png)

### MORPHS Slap Scanner

Ten-print 4-4-2 slap scanner for civil ID and criminal records enrollment.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MORPHS/MORPHS.pdf)

![MATISX Dual Iris Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MATISX/MATISX.png)

### MATISX Dual Iris Scanner

High-speed dual iris capture for high-volume multimodal enrollment programs.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MATISX/MATISX.pdf)

![MOXA7E Enrollment Device](https://www.mantratec.com/Assets/Images/Pages/Products/MOXA7E/MOXA7E.png)

### MOXA7E Enrollment Device

All-in-one portable enrollment station with multi-biometric capture capabilities.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MOXA7E/MOXA7E.pdf)

### POS MicroATM Terminal

Financial-grade biometric POS datasheets

![Mvyom7 Intelligent Terminal](https://www.mantratec.com/Assets/Images/Pages/Products/Mvyom7/Mvyom7.png)

### Mvyom7 Intelligent Terminal

Rugged biometric POS for financial inclusion and payment authentication.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/Mvyom7/Mvyom7.pdf)

![MT100 Biometric Tablet](https://www.mantratec.com/Assets/Images/Pages/Products/MT100/MT100.png)

### MT100 Biometric Tablet

Industrial grade biometric tablet with integrated fingerprint sensor and connectivity.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MT100/MT100_V1.pdf)

![MS20 Dynamic QR Sound Box](https://www.mantratec.com/Assets/Images/Pages/Products/Payment-Soundbox-MS20/MS20.png)

### MS20 Dynamic QR Sound Box

Smart UPI payment sound box with dynamic QR display and audio confirmation.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/Payment-Soundbox-MS20/Payment-Soundbox-MS20.pdf)

![MS30 Advanced Sound Box](https://www.mantratec.com/Assets/Images/Pages/Products/MS30/MS30.png)

### MS30 Advanced Sound Box

Next-generation UPI payment sound box with advanced features and battery life.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MS30/MS30.pdf)

### Integrated Biometric Devices

All-in-one capture & verify datasheets

![MBAS50 Face Recognition Device](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/MBAS50.png)

### MBAS50 Face Recognition Device

Compact Aadhaar-compliant face recognition terminal for touchless verification.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/MBAS50.pdf)

![MBAS30 Fingerprint Device](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS30/MBAS30.png)

### MBAS30 Fingerprint Device

Integrated fingerprint biometric device for Aadhaar Enabled attendance.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS30/MBAS30.pdf)

![MBAS40 Multi-Modal Device](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS40/MBAS40.png)

### MBAS40 Multi-Modal Device

High-accuracy device combining fingerprint and face recognition modes.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS40/MBAS40.pdf)

### Fingerprint Sensors

OEM & standalone sensor modules datasheets

![MFS110 L1](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.png)

### MFS110 L1 Fingerprint Scanner

UIDAI certified L1 fingerprint scanner with FAP10 optical sensor for secure authentication.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.pdf)

![MARC10](https://www.mantratec.com/Assets/Images/Pages/Products/MARC10/MARC10.png)

### MARC10 Capacitive Reader

Ultra-slim capacitive fingerprint module for mobile and handheld integration.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MARC10/MARC10.pdf)

![MARC11 L1](https://www.mantratec.com/Assets/Images/Pages/Products/MARC11/MARC11.png)

### MARC11 L1 Scanner

L1 certified capacitive fingerprint scanner for secure digital identity.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MARC11/MARC11.pdf)

![MELO20 FAP20 Fingerprint Device](https://www.mantratec.com/Assets/Images/Pages/Products/MELO20/MELO20.png)

### MELO20 FAP20 Fingerprint Device

Rugged FAP20 optical fingerprint scanner featuring special scratch-proof glass and IP65 protection.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MELO20/MELO20.pdf)

![MELO30 Fingerprint Reader](https://www.mantratec.com/Assets/Images/Pages/Products/MELO30/MELO30.png)

### MELO30 Fingerprint Reader

High-performance optical fingerprint scanner with a large platen area and FBI PIV certification.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MELO30/MELO30.pdf)

![MELO31 MOSIP USB Fingerprint Reader](https://www.mantratec.com/Assets/Images/Pages/Products/MELO31/MELO31.png)

### MELO31 MOSIP USB Fingerprint Reader

Rugged FAP30 optical fingerprint scanner with FBI PIV certification and MOSIP-L1 compliance.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MELO31/MELO31-MOSIP-L1.pdf)

![MFS200](https://www.mantratec.com/Assets/Images/Pages/Products/MFS200/MFS200.png)

### MFS200 Optical Fingerprint Scanner

FAP20 certified optical sensor for industrial authentication.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MFS200/MFS200.pdf)

![MFS500](https://www.mantratec.com/Assets/Images/Pages/Products/MFS500/MFS500.png)

### MFS500 Fingerprint Scanner

NIST certified fingerprint scanner for high-accuracy identification.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MFS500/MFS500.pdf)

![MFS500 LX](https://www.mantratec.com/Assets/Images/Pages/Products/MFS500-LX/MFS500-LX.png)

### MFS500-LX Advanced Fingerprint Scanner

Premium liveness-protected fingerprint sensor for critical security infrastructure.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MFS500-LX/MFS500-LX.pdf)

![MFS500-MX FBI Certified Fingerprint Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MFS500-MX/MFS500-MX.png)

### MFS500-MX FBI Certified Fingerprint Scanner

High-durability FBI Certified optical fingerprint scanner featuring hardware cryptographic engine.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MFS500-MX/MFS500-MX.pdf)

### IRIS Sensor

High-accuracy iris recognition datasheets

![MATISX](https://www.mantratec.com/Assets/Images/Pages/Products/MATISX/MATISX.png)

### MATISX Dual Iris Scanner

High-speed dual iris capture for high-volume multimodal enrollment and verification.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MATISX/MATISX.pdf)

![MIS 100V2](https://www.mantratec.com/Assets/Images/Pages/Products/MIS100V2/MIS100V2.png)

### MIS 100V2 Single Iris Scanner

Compact and highly accurate single iris scanner for Aadhaar authentication.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MIS100V2/MIS100V2.pdf)

### Face Recognition Device

3D liveness + face match datasheets

![BioNIC Xtreme FX](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-FX/Bionic-Xtreme-FX.png)

### BioNIC Xtreme FX

Premium 3D liveness face recognition terminal for executive attendance and access control.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-FX/BioNIC-Xtreme-FX.pdf)

![BioNIC Xtreme XI](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XI/BioNIC-Xtreme-XI.png)

### BioNIC Xtreme XI

AI-powered face recognition terminal with ultra-fast matching for high-traffic access control.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XI/BioNIC-Xtreme-XI.pdf)

![BioNIC F6](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-F6/BioNIC-F6.png)

### BioNIC F6

Contactless face recognition attendance system designed for industrial and corporate environments.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-F6/BioNIC-F6.pdf)

![IPAS-AI](https://www.mantratec.com/Assets/Images/Pages/Products/IPAS-AI/IPAS-AI.png)

### IPAS-AI

Intelligent face recognition with integrated breath analyzer for safety-critical environments.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/IPAS-AI/IPAS-AI.pdf)

![BioNIC FP6](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-FP6/BioNIC-FP6.png)

### BioNIC FP6

Multi-modal biometric terminal combining facial detection and fingerprint verification.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-FP6/BioNIC-FP6.pdf)

![MBAS50](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/MBAS50.png)

### MBAS50

Compact Aadhaar-compliant face recognition terminal for secure authentication programs.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/MBAS50.pdf)

![MBAS40](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS40/MBAS40.png)

### MBAS40

Integrated multi-modal biometric device supporting facial and fingerprint scan.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS40/MBAS40.pdf)

![BioNIC Xtreme XII](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XII/BioNIC-Xtreme-XII.png)

### BioNIC Xtreme XII

Rugged multi-biometric terminal for outdoor and extreme environment access control.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XII/BioNIC-Xtreme-XII.pdf)

### Biometric Tablet

Portable enrollment station datasheets

![Customized Service Pad](https://www.mantratec.com/Assets/Images/Pages/Products/CustomizedServicePad/Customized-Service-Pad.png)

### Customized Service Pad

Specialized enterprise tablet with integrated biometric sensors for portable applications.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/CustomizedServicePad/Customized-Service-Pad.pdf)

![Portable Biometric Tablet](https://www.mantratec.com/Assets/Images/Pages/Products/MOXA73/MOXA73.png)

### Portable Biometric Tablet

High-performance handheld terminal for secure identity enrollment and field verification.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MOXA73/MOXA73.pdf)

![Rugged Biometric Terminal](https://www.mantratec.com/Assets/Images/Pages/Products/MOXA71/MOXA71.png)

### Rugged Biometric Terminal

IP65 certified industrial biometric terminal capable of operating in extreme conditions.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MOXA71/MOXA71.pdf)

### Physical Access Control Products

Door, gate & turnstile systems datasheets

![BioNIC Xtreme FX](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-FX/Bionic-Xtreme-FX.png)

### BioNIC Xtreme FX

Premium 3D liveness face recognition terminal for executive access control.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-FX/BioNIC-Xtreme-FX.pdf)

![BioNIC Xtreme XI](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XI/BioNIC-Xtreme-XI.png)

### BioNIC Xtreme XI

AI-powered face recognition terminal with ultra-fast matching for access control.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XI/BioNIC-Xtreme-XI.pdf)

![BioNIC F6](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-F6/BioNIC-F6.png)

### BioNIC F6

Contactless face recognition attendance system designed for industrial environments.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-F6/BioNIC-F6.pdf)

![IPAS-AI](https://www.mantratec.com/Assets/Images/Pages/Products/IPAS-AI/IPAS-AI.png)

### IPAS-AI

Intelligent face recognition with integrated breath analyzer for safety-critical environments.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/IPAS-AI/IPAS-AI.pdf)

![BioNIC FP6](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-FP6/BioNIC-FP6.png)

### BioNIC FP6

Multi-modal biometric terminal combining facial detection and fingerprint verification.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-FP6/BioNIC-FP6.pdf)

![Bio HHT](https://www.mantratec.com/Assets/Images/Pages/Products/Bio-HHT/Bio-HHT.png)

### Bio HHT

Biometric handheld device for secure identity verification on the move.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/Bio-HHT/Bio-HHT-Brochure-1.1.pdf)

![BioNIC Xtreme XII](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XII/BioNIC-Xtreme-XII.png)

### BioNIC Xtreme XII

Rugged multi-biometric terminal for outdoor and extreme environment access control.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-Xtreme-XII/BioNIC-Xtreme-XII.pdf)

![MBAS50](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/MBAS50.png)

### MBAS50

Aadhaar-enabled face recognition terminal for secure access and AEBAS.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/MBAS50.pdf)

![MBAS40](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS40/MBAS40.png)

### MBAS40

Multi-modal Aadhaar-enabled terminal with fingerprint and face scan.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS40/MBAS40.pdf)

![MBAS30](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS30/MBAS30.png)

### MBAS30

Aadhaar-enabled fingerprint device for identity verification.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS30/MBAS30.pdf)

### Logical Access Control Solutions

Network & PC security datasheets

![BioNIC V7](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-V7/BioNIC-V7.png)

### BioNIC V7

Secure logical access control reader for PC and network authentication.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/BioNIC-V7/BioNIC-V7.pdf)

![MSCR100](https://www.mantratec.com/Assets/Images/Pages/Products/MSCR100/MSCR100.png)

### MSCR100

Contactless smart card reader for identity systems and secure login applications.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MSCR100/MSCR100.pdf)

![MSCR200](https://www.mantratec.com/Assets/Images/Pages/Products/MSCR200/MSCR200.png)

### MSCR200

High-performance smart card reader with advanced security protocols.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MSCR200/MSCR200.pdf)

![MSKB100](https://www.mantratec.com/Assets/Images/Pages/Products/MSKB100/MSKB100.png)

### MSKB100

Ergonomic keyboard with integrated biometric fingerprint reader for secure desktops.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MSKB100/MSKB100.pdf)

### Aadhaar Products

Government-grade UIDAI solutions datasheets

![Aadhaar Kit](https://www.mantratec.com/Assets/Images/Pages/Products/aadhaar/Aadhaar-kit.png)

### Aadhaar Enrollment Kit

Complete UIDAI kit containing fingerprint scanner, iris scanner, and camera.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/Aadhaar-Kit-Box/Aadhaar-kit.pdf)

![MFS110 L1](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.png)

### L1 Fingerprint Scanner MFS110

UIDAI certified L1 fingerprint scanner with FAP10 optical sensor for secure authentication.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.pdf)

![MARC11](https://www.mantratec.com/Assets/Images/Pages/Products/MARC11/MARC11.png)

### MARC11 Capacitive Scanner

L1 certified capacitive fingerprint scanner for secure digital identity.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MARC11/MARC11.pdf)

![MBAS50](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/MBAS50.png)

### MBAS50 Face Recognition Device

Compact Aadhaar-compliant face recognition terminal for secure authentication programs.

[Download](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/MBAS50.pdf)

### No datasheets found

Try a different search term or select a different category from the sidebar.

## Need Technical Support?

Our expert support team is available to help you with product installation, configuration, and troubleshooting.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")