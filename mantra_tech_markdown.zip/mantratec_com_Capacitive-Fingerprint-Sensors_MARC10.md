[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Products](https://www.mantratec.com/Products) [Fingerprint Sensors](https://www.mantratec.com/Products/Fingerprint-Sensors) MARC10 Capacitive

FAP10 \| FBI PIV \| IP54 Device & IP67 Platen \| WHQL \| OEM Module MOPvC10

# MARC10 Capacitive Fingerprint Scanner

MARC10 is a secure and reliable fingerprint scanner (OEM Module / Sensor: MOPvC10) engineered for precise identification, verification, and authentication. Capturing high-resolution images with an advanced capacitive sensor, it supports MINEX-compliant embedded extraction and is perfect for tight-space installations.

Access ControlIdentity VerificationAuthenticationEmbedded OEM Module

[Get a Quote](https://www.mantratec.com/Products-Inquiry-Form) [Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MARC10/MARC10.pdf)

![Mantra MARC10 Capacitive Fingerprint Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MARC10/MARC10.png)

**500 DPI** Capacitive Sensor

**IP54 / IP67** Device & Platen Rating

Key Highlights

## Compact Precision Capacitive Technology

MARC10 delivers advanced capacitive fingerprint sensing in a slick 58.1\*33.3\*12mm footprint - combining scratch-resistant surface with FBI PIV image quality.

### Advanced FAP10 Sensor

500 DPI \| 256\*360px \| 12.8\*18mm

Exceptional ridge detail capture from a 12.8\*18mm platen area. Delivers high-quality images even from fingers with worn, aged, or dry skin conditions, ensuring reliable enrollment and verification.

### FBI PIV & Mobile ID

IP54 & IP67 \| ESD 15KV \| RoHS

Guaranteed image quality that meets federal identity standards. Features an IP54-rated device shell with an IP67 water and dust protected platen area for exceptional durability in various environments.

### Fast Acquisition

Auto Finger Detection \| < 2s

NIST-quality-aware auto capture completes the placement-to-template cycle in under 2 seconds. Built-in quality checking rejects poor images before they reach the backend.

### OEM Integration Ready

USB 2.0 \| SPI \| UART \| FPC Option

Ultra-slim MOPvC10 OEM module (35\*23\*5mm) fits inside thin terminals and kiosk panels. Supports multiple protocols (USB, SPI, UART) and wire-to-board/FPC connector interfaces.

### Multi-OS & SDK Support

Windows 7/10/11 \| Linux \| Android

WHQL-certified drivers for Windows 7, 10 & 11, plus full support for Linux and Android. Supports MORFIN\_AUTH 1:1 and MORFIN\_SEARCH 1:N matching SDKs.

### High Durability Surface

7H Hardness \| 5B Cross Cut

7H scratch-resistant capacitive surface maintains consistent image quality across 1 million scans. Engineered with 5B cross cut adhesion for extreme ruggedness.

Advanced Technology

## Built for Space-Constrained Secure Installations

![MARC10](https://www.mantratec.com/Assets/Images/Pages/Products/MARC10/MARC10.png)

MARC10

Compact FAP10 Scanner & MOPvC10 OEM Module

Image Quality

FBI PIV

Mobile ID FAP10 · 500 DPI · MINEX Compliant

Protection

IP54 / 67

IP54 Device Level · IP67 Platen Protection

Performance

< 2s

Auto Capture & NIST Quality Checking

Interfaces

USB/SPI/UART

Flexible Protocol & Connector Formats

Form Factor

Miniature

Device: 58.1×33.3×12mm · Module: 35×23×5mm

Standards & Compliance

WHQL

ESD 15KV · CE, FCC Part 15B Class A · RoHS · BIS

Discover Our Solutions

## Ideal for Every Authentication Use Case

MARC10's compact form and high precision make it ideal for space-constrained deployments.

[Access Control **Enterprise Security Solutions** \\
\\
Miniaturized capacitive sensor embeds directly into turnstiles and door locks for secure, spoof-resistant fingerprint entry.](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [Identity & KYC **Citizen Identification** \\
\\
Embedded in government kiosks for real-time Aadhaar UIDAI verification, eKYC, and citizen authentication.](https://www.mantratec.com/Solutions/Citizen-Identification) [HR & Operations **Biometric Attendance System** \\
\\
High-speed identification and low FAR makes MARC10 suitable for reliable employee attendance terminals.](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Specifications

## Technical Details

Full specifications for procurement, integrators, and IT managers.

Sensor DetailsInterfaceElectrical ParametersEnvironmentalStandards & ComplianceSystem Requirements

Sensor Characteristics

Fingerprint Sensor Type

FAP10 Capacitive Sensor

Pixel Resolution

500 DPI ± 2%

Platen Size

12.8 mm x 18 mm

Image Size

256 x 360 Pixels

Image Grayscale

256 Gray Level (8-Bit Image)

Max Acquisition Time

< 2 Sec (Placement to Template)

FRR & FAR

< 0.1% & < 0.001%

Device Dimension (L x W x H)

58.1 mm x 33.3 mm x 12 mm

Module Dimension (L x W x H)

35 mm x 23 mm x 5 mm

Approx. Weight

0.040 kg (40g)

Capture Mode

Auto Finger detection functionality & Auto capture with built-in quality check (Incorporates NIST quality considerations)

Latent Finger Detection

Supported

MTBF

50,000 Hours

Wear & Tear Cycle

1 Million scans

Cross Cut

5B

Surface Hardness

7H

SALT Spray Test

IEC 60068-2-11 / IS 9844 / ASTM G 85

Interface Details

Protocol

USB 2.0, SPI (Up to 24 Mbps)\*, UART (Baud Rate: Default 9600, Up to 115200)\*

Connector

Product: USB Type-A Male, Module: Wire to Board\*\*

Footnotes

\\* UART & SPI interface is available in sensor module only.

\\*\\* FPC Connector available for USB, UART & SPI interface.

Electrical Characteristics

Operating Voltage

+5.0V ± 5% (USB or UART Powered Device) / +3.3V ± 3% (Only for SPI Powered Device)

Operating Current

< 50 mA

Standby Current

< 30 mA

Environmental

Operating Temp.

-10°C to +70°C

Storage Temp.

-20°C to +85°C

Humidity (Operating/Storage)

< 90% RH, Non-Condensing

Standards & Compliance

Biometric Data Interchange Format

ISO 19794-2 : 2005 & 2011 and ANSI 378, ISO 19794-4 : 2005 & 2011, WSQ3.1

EMI / EMC Compliance

CE & FCC Part 15B class A

ESD Protection

Contact Discharge: ± 8kV, Air Discharge: ± 15kV

Safety

EN/IEC 62368-1, IS 13252 (Part 1)

Environmental Health & Safety

RoHS Compliant

Image Quality

FBI PIV Certification, Mobile-ID FAP10

IP Rating

IP54 (Device Level), IP67 (Platen Area)

Device Driver

WHQL certified driver

System Requirements

Operating System

Windows 7, 10 & 11, Android & Linux

Standard Software/SDK

1:1 Matching: MORFIN\_AUTH

1:N Matching: MORFIN\_SEARCH

\\* UART & SPI interface is available in sensor module only

\\*\\* FPC Connector available for USB, UART & SPI interface

Resources

## Everything You Need to Deploy

[**Product Brochure** \\
Full brochure with technical specs, certifications, and integration overview for MARC10.\\
Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MARC10/MARC10.pdf) [**Technical Support** \\
Connect with our biometric engineers for integration and deployment guidance.\\
Get Support](https://www.mantratec.com/Products-Inquiry-Form)

## Expert Integration Support

Our specialists will help you integrate MARC10 into your access control or identity system.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")