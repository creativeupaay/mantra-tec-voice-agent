Optical Fingerprint Scanner
Model : MFS500 LX \| Module : MOPv3.0

Benefits

High speed interface

Rapid capturing

Easy to use

\[Image: Im0\]

Easy to integrate

High accuracy rate

Features
\[Image: Im0\]

Device securely sign the
biometric data
\[Image: Im0\]

Lowest FAR and FRR
\[Image: Im0\]

High speed USB 2.0 interface
with plug and play
\[Image: Im0\]

500 DPI optical
fingerprint sensor
\[Image: Im0\]

extractor
\[Image: Im0\]

API specification V2.0
\[Image: Im0\]

* * *

Optical Fingerprint Scanner
Model : MFS500 LX \| Module : MOPv3.0

MFS500 LX is a fingerprint scanner with high durability that ensures robustness. MFS500 LX
is MINEX compliance embedded extractor. The device offers precise and rapid verification,
authentication and authorization processes. MFS500 LX is a safe and convenient device
that lets the fingerprint act as a password.

At a Glance

| Sensor Characteristics |  |
| --- | --- |
| Parameters |  |
| Fingerprint Sensor |  |
| Image Resolution |  |
| Platen Size |  |
| Active Platen Size |  |
| Image Size |  |
| Image Grayscale |  |
| Light Source |  |
| Approx Dimensions(L x W x H) |  |
| Approx Weight |  |

| Specification |
| --- |
| : Optical Scratch Free Sensor |
| : 500 DPI +/- 5% |
| : 16 mm x 18.2mm |
| : 16 mm x 18mm |
| : 316x354 Pixels |
| : 256(8-Bit Gray Level) |
| : RED LED |
| : 29x35x61mm |
| : 0.028Kg |

Electrical Characteristics
Parameters

| Parameters | Specification |
| --- | --- |
| Operating Voltage | :5V+/-5% (USB Powered Device) |
| Operating Current(max) | :81mA |
| Stand by Current(max) | :45mA |
| Interface | :USB2.0(Std/OTG Supported)&SerialTTL |

| Parameters |
| --- |
| Biometric Data Interchange Format |
| Environmental, Health and Safety |
| BIS |
| Safety |
| EMI/EMC Compliance |
| \*STQC Certification |
| IP Rating |
| Device Driver |
| OS Supports |

| Specification |
| --- |
| :ISO 19794-2 for minutiae&ISO 19794-4 for Image Template |
| :RoHS Certification |
| :IS 13252(Part1) |
| :IEC60950 |
| :CE&FCC ClassA |
| :Yes |
| :IP54 |
| :WHQL Certified with Unique Serial Number |
| :Win XP,Win7,Linux(32bit&64bit) |

| Parameters | Specification |
| --- | --- |
| Operating Temperature | :0 to 45 degC |
| Storage Temperature | :0 to 50 degC |
| Humidity(Operating/Storage) | :＜90%RH,Non |

Compliant to Following Standard
Parameters

\*Applied for certification
\[Image: Im0\]