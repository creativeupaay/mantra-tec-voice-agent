[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Products](https://www.mantratec.com/Products) [Fingerprint Sensors](https://www.mantratec.com/Products/Fingerprint-Sensors) MARC11 Slick Capacitive

Model: MARC11 \| OEM Module / Sensor: MOPvC11 \| UIDAI L1 Ready

# MARC11 Slick Capacitive Fingerprint Scanner

Mantra MARC11 is a secure and reliable L1 fingerprint scanner for precise identification, verification and authentication. Engineered with a rugged and advanced FAP10 capacitive sensor and hardware-grade security including RSA2048, AES-GCM-256, and TEE for high-assurance identity programs.

UIDAI AadhaarSTQC L1Secure OEMHigh Assurance

[Get a Quote](https://www.mantratec.com/Products-Inquiry-Form) [Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MARC11/MARC11.pdf)

![Mantra MARC11 Secure Capacitive Fingerprint Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MARC11/MARC11.png)

**500 DPI** FAP10 Sensor

**UIDAI L1** RD Service Ready

Key Highlights

## Hardware-Grade Security Meets Precision Capture

MARC11 combines hardware cryptography and TEE-based secure memory with STQC L1 certification for definitive Aadhaar-linked biometric authentication.

### STQC L1 Certified

500 DPI \| 256\*360px \| FAP10

Premium capacitive sensing captures high-quality images from a 12.8\*18mm platen. Features latent finger detection and NIST quality checks to ensure only valid impressions are processed in under 2 seconds.

### Hardware Encryption

RSA2048 \| AES-GCM-256 \| SHA-256

Dedicated crypto engine handles key generation and data encryption. TEE secure memory with key wrapping and Secure Boot prevent firmware tampering and root-level attacks on biometric data.

### UIDAI L1 RD Service

ISO 19794-2/4 \| WSQ3.1 \| FBI PIV

Fully compliant with UIDAI L1 Registered Device standards for Aadhaar-enabled applications including AEPS and eKYC. Supports biometric data formats for all major middleware and ABIS platforms.

### Rugged Protection

IP54 Device \| IP67 Platen \| 7H Surface

IP54 device-level protection with an IP67-rated platen for immersion resistance. Features a 7H surface hardness and 5B cross-cut rating to survive rigorous daily use in field conditions.

### Industrial Durability

1M Wear Cycles \| 50K MTBF

Engineered for longevity with a 1-million cycle wear rating on the sensor surface. Operates reliably from -20
oC to +70oC for deployment in extreme environmental conditions.


### Embedded OEM Ready

USB 2.0 \| 35\*23\*5mm Module

Ultra-compact core module designed for deep integration into OEM devices. Standard USB 2.0 Type-A connectivity with low operating current (❮50mA) eliminates external power needs.


Advanced Technology

## Built for High-Assurance Aadhaar Authentication

![MARC11](https://www.mantratec.com/Assets/Images/Pages/Products/MARC11/MARC11.png)

MARC11

OEM Module / Sensor: MOPvC11

Security Engine

AES-256

RSA2048 \| TEE \| Secure Boot \| SHA-256

Identity

L1

UIDAI L1 RD Service RD Level 1

Durability

1M

Wear & Tear Cycle of Sensor: 1 Million

Ingress

IP67

IP67 Platen Area \| IP54 Device Level Ingress Protection

Operating

-20oC

Operating Temp: -20oC to +70oC

MTBF

50K Hrs

MTBF: 50,000 Hours Reliability

Discover Our Solutions

## Designed for Aadhaar and High-Security Programs

MARC11's UIDAI L1 compliance makes it the standard for government biometric programs.

[Aadhaar \| AEPS **Aadhaar AEPS & eKYC Authentication** \\
\\
STQC L1 certified capacitive scanner for banking correspondents and eKYC applications requiring UIDAI L1 compliance.](https://www.mantratec.com/Solutions/Citizen-Identification) [Access Control **Secure Physical & Logical Access** \\
\\
Liveness detection and anti-spoofing ensure only genuine fingerprints unlock systems in defense and enterprise environments.](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [Attendance \| AEBAS **Biometric Attendance & AEBAS** \\
\\
Seamless USB connectivity for AEBAS terminals, corporate HR systems, and industrial factory attendance devices.](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Specifications

## Technical Details

Full specifications for technical integration and procurement.

Sensor CharacteristicsSecurity EngineInterface & ElectricalEnvironmentalStandards & Compliance

Sensor Characteristics

Sensor Type

FAP10 Capacitive Sensor

Spatial Resolution

500 DPI  2%

Platen Area

12.8 mm x 18.0 mm

Image Size

256 x 360 Pixels

Image Grayscale

256 (8-Bit Gray Level)

Light Source

Red LED

Device Dimension (L x W x H)

58.1 x 33.3 x 11 mm

Module Dimension (L x W x H)

35 x 23 x 5 mm

Approx. Weight

0.040 kg

Latent Finger Detection

Supported

Acquisition Time

< 2 Sec

Wear & Tear Cycle

1 Million

MTBF

50,000 Hours

Surface Hardness

7H

Cross Cut

5B

SALT Spray Test

IEC 60068-2-11 / IS 9844 / ASTM G 85

Certifications

CE, RoHS, BIS, IP54

Capture Mode

Auto capture with built-in quality check (incorporates NIST quality considerations)

Security Engine

Crypto Operation

Hardware base RSA2048 Key Generation, AES-GCM-256, SHA-256, TRNG support

Secure Memory

TEE support by the device. Secure memory support key wrapping feature

Secure Boot

Secure boot support by the device

Interface & Electrical

Interface

USB 2.0

Connector

USB Type-A Male

Operating Voltage

5V  5% (USB Powered Device)

Operating Current

< 50 mA

Standby Current

< 30 mA

Environmental

Operating Temperature

-20oC to +70oC

Storage Temperature

-20oC to +85oC

Humidity (Operating / Storage)

< 90% RH, Non-condensing

ESD Contact

8kV

ESD Air

15kV

Salt Spray

Tested to IEC 60068-2-11 / IS 9844 / ASTM G 85

Standards & Compliance

Biometric Data Interchange Format

ISO 19794-2 : 2005 & 2011, ISO 19794-4 : 2005 & 2011, WSQ3.1

Safety

EN/IEC 62368-1, IS 13252 (Part 1)

EMI / EMC Compliance

CE, FCC Part 15B class A

Environmental, Health and Safety

RoHS

Image Quality Compliance

FBI PIV Certification, Mobile-ID FAP10, STQC

IP Rating

IP54 (Device Level), IP67 (Platen Area)

Operating System

Windows 10 above, Linux, Android

Standard Software/SDK

UIDAI L1 RD Service

Default 1 year RD service subscription & 1 Year Warranty are included, Renewal will be chargeable. For verification of your subscription tenure and Official Renewal visit
[servico.mantratecapp.com](https://servico.mantratecapp.com/)

Resources

## Everything You Need to Deploy

[**Product Brochure** \\
Full brochure with technical specs, certifications, and integration overview for MARC11.\\
Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MARC11/MARC11.pdf) [**Technical Support** \\
Connect with our biometric engineers for UIDAI L1 integration and deployment guidance.\\
Get Support](https://www.mantratec.com/Products-Inquiry-Form)

## Expert L1 Support

Our specialists will help you deploy MARC11 for UIDAI-compliant biometric authentication at scale.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")