# Contactless Smart Card Reader

## Model : MSCR200

Mantra Softech is a Global Hi-Tech Manufacturer of Biometric Products and Solutions. We offer a Wide Range of Products in Biometric and RFID Industry.

* * *

# CONTACTLESS SMART CARD READER MSCR200

MSCR200

Our devices are versatile and can be installed as a tabletop or wall mount. With its plug-and-play feature, setting up is quick and easy. This allows for flexibility in how you want to use the device, making it a convenient addition to your workspace.

# Introduction

MSCR200 Smart Card Reader with new and modern technology. This compact smart card reader brings together sophisticated technology and modern design to meet the rigorous requirements of smart card-based applications. The MSCR200 Contactless Reader based on 13.56 MHz technology for fast and easy integration into embedded systems. It is a plug-and-play device that does not require any driver installation. It also features a USB Full Speed interface and a smart card read/write speed of up to 848 Kbps and has a card reading distance of up to 50 mm. It is fully compliant with PC/SC and CCID compliant and supports various operating systems such as Windows, Linux, BOSS OS and Mac. MSCR200 supports All types of card supporting ISO 14443. With its sleek, stylish design and powerful core, the MSCR200 is the ideal peripheral for your smart card applications.

# Features

u USB 2.0 Full Speed Interface u Card detection alert for user u USB Bus Powered Device u Supports PC/SC u CCID Compliance u User-controllable bi-color LED u Table top form factor u User-controllable buzzer

# Smart Card Reader:

u Read/write speed up to 848 kbps u Built-in antenna for contactless tag access, with card reading distance of up to 50 mm (depending on tag type) u Supports all types of ISO 14443 Compliant Contactless Card u Built-in anti-collision feature (only 1 tag is accessed at any time)

* * *

CONTACTLESS SMART CARD READER MSCR200

At a Glance

| Sensor Characteristics | Reader Form Factor |
| --- | --- |
| Wireless Operating Frequency |  |
| Protocol supported |  |
| Operating Distance |  |
| Card Alignment |  |
| Status Indicator |  |
| Buzzer |  |
| Host Interface |  |
| Smart Card Interface Support |  |
| PC-Linked Mode |  |
| Electrical Characteristics | Power Supply |
| Operating Voltage |  |
| Operating Current |  |
| Stand by Current |  |
| Interface |  |
| Environmental Characteristics | Operating Temperature |
| Storage Temperature |  |
| Humidity(Operating/Storage) |  |
| Compliant to Following Standard | Environmental,Health and Safety |
| CE Marking |  |
| Operating System |  |
| Mechanical Details | Dimension |
| Weight |  |

|  | : Reads the card in any alignment when it is placed on the reader |
| --- | --- |
|  | : 13.56MHz |
|  | : ISO 14443 A/B |
|  | : Up to 50 mm (Depends on type of the Card) |
|  | : Horizontal while interacting with Card |
|  | : Bi-Color LED |
|  | : Indication for card detection |
|  | : USB 2.0 Full Speed |
|  | : ISO 14443 A/B |
|  | : PC/SC |
|  | : Bus Powered |
|  | : 5V +/- 5% Vdc |
|  | : 140mA-200mA (Maximum Rated Value; Subject to Type of Card) |
|  | : 60mA-100mA (Intermittent RF Transmission) |
|  | : PC/SC |
|  | : 0 to 50℃ |
|  | : -20℃ to 70℃ |
|  | : 10%-90%(Non condensing) |
|  | : RoHS |
|  | : YES |
|  | : Windows x86 & x64, BOSS OS, Linux |
|  | : 106mm(L)x70mm(W)x14.5mm(H) |
|  | : Approx 90gm |

:20^{\\circ}C+070^{\\circ}C

* * *

# Support : [servico@mantratec.com](mailto:servico@mantratec.com) Sales : [sales@mantratec.com](mailto:sales@mantratec.com)