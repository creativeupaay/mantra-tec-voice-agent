[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Media](https://www.mantratec.com/Media "Home") Events

🌎 Global Presence

# Mantra Events Worldwide

Stay updated with Mantra Softech's latest exhibitions, trade shows, conferences, and industry events happening across the globe - from India to Europe, the Middle East and beyond.

40+Events Attended

9Years of Showcasing

15+Countries Reached

4Events in 2025

###### Milipol India 2025

April 23-25 · Yashobhoomi, New Delhi

###### Intersec Saudi Arabia 2025

Sep 29-Oct 1 · Riyadh Convention Centre

###### Defence Partnership Day 2025

December 1-2 · Manekshaw Centre, Delhi

Our Events

## Our Events

Stay up to date with the upcoming biometric industry events from around the world.

202520242023202220212020201920182017

December 2025![Defence Partnership Day 2025](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2025/Defence-Partnership-Day-2025.jpg)

#### Mantra Softech at Defence Partnership Day 2025

Mantra Softech participated in Defence Partnership Day, engaging with India's defence innovators, system integrators, and mission-critical stakeholders.

We demonstrated how secure identity, rugged biometric systems, and field-ready hardware strengthen trusted operations across command centres, borders, bases, and frontline deployments. Our solutions are engineered to perform in demanding environments, supporting real-time authentication, secure access, and situational awareness for defence and homeland security missions.

Start Event

December 1, 2025

End Event

December 2, 2025

Where We Are

Manekshaw Centre, New Delhi, India

September 2025![Intersec Saudi Arabia 2025](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2025/Intersec-Saudi-Arabia-2025.jpg)

#### Intersec Saudi Arabia 2025

Exhibition Focused on Security, Safety, and AI Innovation

Showcased AI-powered biometric identity, access control, and surveillance solutions, strengthening enterprise and government security ecosystems. Focused on next-gen liveness detection and future-ready security technologies.

Start Event

September 29, 2025

End Event

October 01, 2025

Where We Are

Riyadh International Convention & Exhibition Center, Saudi Arabia

April 2025![Milipol India 2025](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2025/Milipol-India-2025.jpg)

#### Milipol India 2025

Exhibition Focused On Internal Security, Safety, And Surveillance

Showcased **IPAS** and **Bio-Logon**; featured in media with Col. Amit Ranjan Verma (Retd.). Focus on AI-driven biometric access and defense-grade readiness.

Start Event

April 23, 2025

End Event

April 25, 2025

Where We Are

Yashobhoomi Convention Centre, New Delhi.

February 2025![IBEX India 2025](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2025/Ibex-India-2025.jpg)

#### IBEX India 2025

Biometric Security Solutions

Displayed cutting-edge biometric security solutions tailored for the BFSI sector. Emphasis on enterprise-grade identity verification for financial institutions.

Start Event

February 13, 2025

End Event

February 14, 2025

Where We Are

Mumbai (Booth SC11).

December 2024![MEP Conclave 2024](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2024/MEP-Conclave-2024.jpg)

#### MEP Conclave 24

Infrastructure Innovations

Focuses on MEP (Mechanical, Electrical, Plumbing) advancements, driving discussions on sustainable infrastructure solutions.

Start Event

December 12, 2024

End Event

December 13, 2024

Where We Are

Bangalore

November 2024![Defence Day Partnership 2024](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2024/Defence-Day-Partnership-2024.jpg)

#### Defence Day Partnership

Strategic Defence Expo

Highlights innovations in defense technology, strategic partnerships, and security systems for national and global defense.

Start Event

November 28, 2024

End Event

November 29, 2024

Where We Are

New Delhi

May 2024![ID4 Africa 2024](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2024/ID4-Africa-2024.jpg)

#### ID4Africa 2024

Digital Identity Solutions

A global platform focusing on identity systems, biometrics, and digital transformation for secure and inclusive development.

Start Event

May 21, 2024

End Event

May 24, 2024

Where We Are

Kenya, Nairobi

March 2024![MOSIP Connect 2024](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2024/MOSIP-Connect-2024.jpg)

#### MOSIP Connect

MOSIP Innovations

Showcases the Modular Open Source Identity Platform for creating scalable, secure, and interoperable ID systems globally.

Start Event

March 5, 2024

End Event

March 7, 2024

Where We Are

Ethiopia

November 2023![Trustech 2023](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2023/Trustech--2023.jpg)

#### Trustech

Fintech Security Showcase

A global fintech and digital security event showcasing payment systems, smart cards, and biometric authentication solutions.

Start Event

November 28, 2023

End Event

November 30, 2023

Where We Are

Paris, France

November 2023![FCBA-Goa-2023](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2023/FCBA-Goa-2023.jpg)

#### FCBA Goa

Fintech Compliance Summit

A financial conference exploring advancements in fintech, compliance, and banking operations to drive secure financial systems.

Start Event

November 16, 2023

End Event

November 18, 2023

Where We Are

Goa, India

November 2023![India-SEM--Navy-Expo-Ficci-2023](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2023/India-SEM--Navy-Expo-Ficci-2023.jpg)

#### India SEM 2023 - Navy Expo

Navy Tech Innovation

A specialized event showcasing advancements in naval technologies, defense strategies, and maritime security innovations.

Start Event

November 09, 2023

End Event

November 10, 2023

Where We Are

New Delhi, India

November 2023![Identity-Week-Malaysia-2023](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2023/Identity-Week-Malaysia-2023.jpg)

#### ID Week 2023-Asia

Asian ID Tech Conference

Asia's leading identity event focusing on biometrics, authentication, and digital ID solutions to enhance security systems.

Start Event

November 07, 2023

End Event

November 08, 2023

Where We Are

Singapore

November 2023![GST-Seva-Kendra-Gujarat-Inugration-2023](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2023/GST-Seva-Kendra-Gujarat-Inugration-2023.jpg)

#### GST Seva Kendra Inauguration

Taxation Service Center

Launch of a new service center providing support for GST filing, compliance, and efficient taxation solutions for businesses.

Start Event

November 07, 2023

End Event

November 07, 2023

Where We Are

Gujarat, India

September 2023![Philippines-Identity-Summit-2023](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2023/Philippines-Identity-Summit-2023.jpg)

#### Philippines Identity Summit

Secure ID Summit

Focuses on secure identity solutions, biometrics, and scalable frameworks for digital transformation in the Philippines.

Start Event

September 26, 2023

End Event

September 28, 2023

Where We Are

Manila, Philippines

September 2023![Identity Week America](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2023/Identity-Week-America.jpg)

#### Identity Week America

Digital ID America

An American identity conference exploring biometrics, secure authentication, and innovative identity management systems.

Start Event

September 19, 2023

End Event

September 21, 2023

Where We Are

USA

September 2023![Global-Fintech-Festival-2023](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2023/Global-Fintech-Festival-2023.jpg)

#### Global Fintech Festival

Global Fintech Meet

Connects global leaders, startups, and policymakers to explore fintech opportunities for financial inclusion and digital growth.

Start Event

September 4, 2023

End Event

September 6, 2023

Where We Are

Mumbai, India

July 2023![Ibex-2023](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2023/Ibex-2023.jpg)

#### Ibex 2023

Banking Automation Expo

A key financial automation event showcasing innovations and trends transforming the banking ecosystem globally.

Start Event

July 14, 2023

End Event

July 16, 2023

Where We Are

Dubai, UAE

May 2023![ID4-Africa-2023](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2023/ID4-Africa-2023.jpg)

#### ID4AFRICA 2023

identity solutions.

Highlights Africa's digital identity needs, showcasing biometric ID systems for secure and inclusive identity solutions.

Start Event

May 23, 2023

End Event

May 25, 2023

Where We Are

Cape Town, South Africa

May 2023![CIAL-Airport-Inugaration-2023](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2023/CIAL-Airport-Inugaration-2023.jpg)

#### CIAL Airport Inauguration

Airport Infrastructure Launch

Celebrating the launch of an advanced airport infrastructure with smart technologies to enhance passenger experience.

Start Event

May 09, 2023

End Event

May 09, 2023

Where We Are

Cochin, India

October 2022![Identity-Week--Singapore-2022](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2022/Identity-Week--Singapore-2022.jpg)

#### ID Week Singapore

Digital ID Conference

Singapore's top event on digital identity verification, biometrics, and secure authentication solutions for enterprises.

Start Event

October 11, 2022

End Event

October 13, 2022

Where We Are

Singapore

July 2022![Identity-Week-India-2022](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2022/Identity-Week-India-2022.jpg)

#### Identity Event India

Secure ID Innovations

A conference exploring India's advancements in secure identity systems, eKYC solutions, and authentication technologies.

Start Event

July 07, 2022

End Event

July 08, 2022

Where We Are

India

July 2022![Digital-India-Week-2022](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2022/Digital-India-Week-2022.jpg)

#### Digital India Week 2022

Technology Week

Celebrates India's digital transformation with innovations in technology-driven governance, digital inclusion, and smart solutions.

Start Event

July 04, 2022

End Event

July 09, 2022

Where We Are

Gandhinagar, India

June 2022![ID-week-london-2022](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2022/ID-week-london-2022.jpg)

#### ID Week London

Digital ID Tech Event

A global identity conference featuring trends in biometrics, identity verification, and digital authentication solutions.

Start Event

June 28, 2022

End Event

June 29, 2022

Where We Are

London, UK

June 2022![ID4-Africa-2022](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2022/ID4-Africa-2022.jpg)

#### ID4AFRICA 2022

Biometric ID Showcase

Mantra Softech showcases innovative biometric identity solutions, enhancing secure identification frameworks across Africa.

Start Event

June 07, 2022

End Event

June 09, 2022

Where We Are

Africa

April 2022![Smart-Home-Expo-2022](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2022/Smart-Home-Expo-2022.jpg)

#### Smart Home Expo

Smart Living Tech

Showcases smart living solutions, IoT technologies, and energy-efficient systems for connected homes and sustainable lifestyles.

Start Event

April 20, 2022

End Event

April 21, 2022

Where We Are

Bengaluru, India

September 2021![Global-FinTech-Fest-2021](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2021/Global-FinTech-Fest-2021.jpg)

#### Global FinTech Fest 2021

Fintech Future Forum

A global fintech event uniting startups, policymakers, and leaders to explore trends in digital payments and banking.

Start Event

September 28, 2021

End Event

September 30, 2021

Where We Are

Virtual

April 2021![IFSEC-2021](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2021/IFSEC-2021.jpg)

#### IFSEC

Security Solutions Forum

Leading event on integrated security systems, access control, and surveillance technologies for diverse industries.

Start Event

April 12, 2021

End Event

April 14, 2021

Where We Are

London, UK

March 2020![Police Expo 2020](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2020/Police-Expo-2020.jpg)

#### Police Expo 2020 - An Unique B2G Forum

Mantra showcased a variety of Biometric security products and solutions in the Police and Defence sector in the exposition held in Gurugram during 5th and 6th of March 2020.

Start Event

March 05, 2020

End Event

March 06, 2020

Where We Are

Apparel House, Sector 44 in Gurugram, Harayana, India.

March 2020![National Education CSR Conclave](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2020/National-Education-CSR-Conclave.jpg)

#### National Education CSR Conclave

Mantra mainly featured Aadhaar Enabled Biometric Attendance System (AEBAS) products and Canteen management system products at the National Education CSR conclave held at Lucknow during 4th and 5th March 2020.

Start Event

March 04, 2020

End Event

March 05, 2020

Where We Are

Dr BR Auditorium of Dr RML National Law Institute in Lucknow, Uttar Pradesh, India.

February 2020![ibex mumbai 2020](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2020/ibex-mumbai-2020.jpg)

#### Mantra at Ibex India 2020

Mantra had featured a variety of security products in the 8th edition of IBEX India, which was held in Mumbai from 13 - 15 February 2020.

Start Event

February 13, 2020

End Event

February 15, 2020

Where We Are

MMRDA Grounds, Bandra-Kurla Complex, Mumbai, india.

December 2019![Artech-2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/Artech-2019.jpg)

#### ARTECH 2019

Innovation Expo

Showcases advancements in technology, innovation, and research for the defense and industrial sectors.

Start Event

December 6, 2019

End Event

December 8, 2019

Where We Are

India

November 2019![Trustech-Expo-2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/Trustech-Expo-2019.jpg)

#### Trustech Expo

Digital Payment Expo

Leading fintech event highlighting advancements in smart cards, digital payments, and biometric authentication technologies for secure transactions.

Start Event

November 26, 2019

End Event

November 28, 2019

Where We Are

Paris, France

September 2019![Shapth-Shakti-Wartech-2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/Shapth-Shakti-Wartech-2019.jpg)

#### Shapath Shakti Wartech 2019

Defense Innovation Expo

A defense technology event showcasing innovations in war technology, smart systems, and modern defense infrastructure solutions.

Start Event

September, 2019

End Event

September, 2019

Where We Are

India

September 2019![Elclina-Awards-2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/Elclina-Awards-2019.jpg)

#### Elclina Awards 2019

Industrial Security Forum

Focused on industrial security systems, fire safety innovations, and surveillance technologies to ensure robust safety standards.

Start Event

September 25, 2019

End Event

October 11, 2019

Where We Are

India

September 2019![Mantra at Seamless 2019 Identity Expo](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/Seamless-Philippines-25-29-2019.jpg)

#### Mantra At Seamless 2019 Identity Expo

Mantra is going to participate in the Seamless Identity 2019 Expo to be held in the Philippines on 25th & 26th September 2019 and showcase a range of advanced citizen identity products & solutions. We will be pleased to see your presence at the exhibition at Booth J08.

Start Event

September 25, 2019

End Event

September 26, 2019

Where We Are

SMX Convention Center, Manila Mall of Asia Complex, Pasay City, Philippines.

June 2019![Mantra at the ID4Africa Event 2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/ID4Africa-2019.jpg)

#### Mantra At ID4Africa Event 2019

ID4Africa is the premier event for identity in developing countries, and one of the top events globally to develop robust and responsible ID ecosystems around digital identity in the service of development, humanitarian action, security and facilitation. ID4Africa served a great platform to Mantra for showcasing a wide array of advanced biometric identity products. We're overwhelmed with the great response received from visitors.

Start Event

June 18, 2019

End Event

June 20, 2019

Where We Are

Emperors Palace Convention Centre in Johannesburg, South Africa.

June 2019![Intercon-Award-2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/Intercon-Award-2019.jpg)

#### Intercon Award 2019

Technology Awards Forum

Celebrates technological and security innovations with awards recognizing excellence in safety and surveillance systems.

Start Event

June 18, 2019

End Event

June 20, 2019

Where We Are

UAE

June 2019![IFSEC-2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/IFSEC-2019.jpg)

#### IFSEC 2019

Integrated Security Expo

A leading event on integrated security systems, surveillance solutions, and access control technologies for businesses and governments.

Start Event

June 18, 2019

End Event

June 20, 2019

Where We Are

India

June 2019![Hyderabad-Jun-2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/Hyderabad-Jun-2019.jpg)

#### Security and fire expo Hyderabad 2019

Tech Development Forum

A focused event exploring advancements in technology, smart systems, and infrastructure innovations in Hyderabad.

Start Event

June 27, 2019

End Event

June 29, 2019

Where We Are

Hyderabad, India

May 2019![Northern-Command-2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/Northern-Command-2019.jpg)

#### Northern Command-2019

Defense Strategy Summit

A defense-focused event highlighting strategic advancements, command systems, and innovations in national security technologies.

Start Event

May 13, 2019

End Event

May 24, 2019

Where We Are

India

April 2019![Mantra-to-showcase-the-Next-Generation-Biometric-Security-Products-and-Solutions-at-Secutech-India-2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/Biometric-Security-Products-and-Solutions-at-Secutech-India-2019.jpg)

#### Secutech Mumbai 2019

Mantra has successfully participated in India's leading security trade fair - Secutech India 2019 and showcased the best-in-class biometric security products ranging from Biometric Fingerprint Sensors, Integrated Fingerprint Devices to POS/Financial Terminals. Mantra also unveiled its new product MOXA7 - The next generation portable biometric integrated device at the Expo. Mantra had also showcased a new range of biometric security solutions under the name ‘Morzel' for Industry 4.0.

Start Event

April 25, 2019

End Event

April 27, 2019

Where We Are

Bombay Convention & Exhibition Centre (BEC), Mumbai, India.

January 2019![Ibex-Mumbai-2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/Ibex-Mumbai-2019.jpg)

#### IBEX Mumbai 2019

Our specialists have showcased a variety of biometric security products at the event. The devices can essentially be employed for the purpose of eKYC verification and customer identification in the banking and financial industries.

Start Event

January 23, 2019

End Event

January 25, 2019

Where We Are

Bandra-Kurla Complex in Mumbai, India.

January 2019![Intersec-Dubai-2019](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2019/Intersec-Dubai-2019.jpg)

#### Intersec Dubai 2019

Global Security Expo

One of the world's largest trade fairs for security, safety, and fire protection, showcasing global security innovations.

Start Event

January 20, 2019

End Event

January 22, 2019

Where We Are

Dubai, UAE

December 2018![IFSEC-Delhi-2018](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2018/IFSEC-Delhi-2018.jpg)

#### IFSEC Delhi 2018

Security Tech Show

Showcases cutting-edge security products, surveillance systems, and access control solutions tailored for Indian and global markets.

Start Event

December 05, 2018

End Event

December 07, 2018

Where We Are

Greater Noida, India

November 2018![TrusTech-Cannes-2018](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2018/TrusTech-Cannes-2018.jpg)

#### TrusTech Cannes 2018

Digital Trust Event

A global event dedicated to trust-based technologies, including secure payments, identification, and digital security solutions.

Start Event

November 27, 2018

End Event

November 29, 2018

Where We Are

Cannes, France

June 2018![Security-and-Fire-Expo-Chennai-2018](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2018/Security-and-Fire-Expo-2018.jpg)

#### Security and Fire Expo 2018

Fire Safety Expo

Focuses on fire protection, safety equipment, and disaster management solutions for industrial and commercial sectors.

Start Event

June 08, 2018

End Event

June 09, 2018

Where We Are

Chennai, India

April 2018![Secutech-2018](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2018/Secutech-2018.jpg)

#### Secutech-2018

Safety & Security Fair

Highlights the latest in electronic security, home automation, and fire safety products from global manufacturers.

Start Event

April 05, 2018

End Event

April 07, 2018

Where We Are

Mumbai, India

January 2018![Intersec Dubai 2018](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2018/Intersect-2018.jpg)

#### Intersec 2018

Security Systems Expo

Mantra Softech (India) Pvt Ltd participated in Intersec 2018 which is the world's leading trade fair for Security, Safety & Fire Protection held in Dubai, UAE.

Start Event

January 21, 2018

End Event

January 23, 2018

Where We Are

Dubai, UAE

April 2018![Nigeria Expo](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2018/Nigeria-Expo-2018.jpg)

#### Nigeria Expo

Economic Growth Expo

Mantra Softech (India) Pvt Ltd participated in ID4Africa 2018 which is the world's leading trade fair for government identity solutions held in Abuja, Nigeria.

Start Event

April 24, 2018

End Event

April 26, 2018

Where We Are

Abuja, Nigeria

January 2018![Vibrant Gujarat](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2018/Vibrant-Gujarat-2018.jpg)

#### Vibrant Gujarat

Global Trade Summit

A global summit promoting trade, investment, and economic growth in Gujarat, connecting global leaders, investors, and innovators.

Start Event

January 09, 2018

End Event

January 13, 2018

Where We Are

Gandhinagar, India.

December 2017![IFSEC 2017](https://www.mantratec.com/Assets/Images/Pages/Media/Events/2017/Iffsec-2017.jpg)

#### IFSEC 2017

Security Tech Forum

An international event on integrated security solutions, surveillance systems, and access control technologies.

Start Event

December 06, 2017

End Event

December 08, 2017

Where We Are

New Delhi, India

## Let's Get in Touch

Follow our journey of innovation, recognition, and global impact across biometric and identity management industries.

[Contact Us](https://www.mantratec.com/Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")