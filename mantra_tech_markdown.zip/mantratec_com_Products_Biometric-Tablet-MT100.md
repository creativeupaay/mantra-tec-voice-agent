[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")/ [Products](https://www.mantratec.com/Products)/MT100STQC \| CE \| RoHS \| IP54 \| Android 13

# MT100 Biometric Tablet

Rugged 7-inch biometric tablet running Android 13 with STQC fingerprint, optional IRIS scanner, barcode/QR reader, integrated thermal printer, 8940mAh swappable battery, and 4G LTE - the ultimate field terminal for mobile government and enterprise operations.

Field OperationsMobile AEPSHealthcareCensusGovernment

[Get a Quote](https://www.mantratec.com/Products-Inquiry-Form) [Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MT100/MT100_V1.pdf)

![Mantra MT100 Biometric Tablet](https://www.mantratec.com/Assets/Images/Pages/Products/MT100/MT100.png)

**7"** IPS Touch

**Android 13** Powered

**8940mAh** Swappable

Key Highlights

## The Complete Biometric Field Terminal

MT100 combines a 7" rugged tablet with STQC biometric sensors, thermal receipt printer, and full cellular connectivity - making it the definitive all-in-one device for mobile government, healthcare, and enterprise identity operations.

FAP10 \| 500DPI \| FBI PIV \| UIDAI

### STQC Fingerprint + IRIS (Optional)

Integrated scratch-free optical FAP10 fingerprint sensor (276x336px, 500DPI, 8-bit) certified to STQC L1, FBI PIV, CE, FCC, and UIDAI standards. Optional STQC IRIS scanner for dual-modal biometric workflows requiring higher assurance.

ARM Cortex A53 2.0GHz \| 2GB RAM \| 32GB

### 7" IPS LCD \| Android 13 \| Quad-Core

7-inch IPS LCD (1024x600, 16M colors) with scratch-resistant 6H toughened glass. Powered by ARM Cortex A53 @ 2.0GHz Quad-Core, 2GB RAM, 32GB eMMC storage, and 3-Axis accelerometer with ambient light sensor for auto-brightness.

8MP AF \| High-Brightness Flash LED

### Barcode + QR Scanner

8MP auto-focus camera with high-brightness flash LED doubles as a high-speed barcode and QR code scanner - eliminating the need for a separate handheld scanner and streamlining data collection workflows in the field.

70mm/sec \| 48mm Print Width

### Integrated 2" Thermal Printer

Built-in 2-inch thermal printer prints at 70mm/second with 48mm effective print width in black-and-white - generating receipts, transaction records, and field reports on the spot without any external peripheral device.

Hot-Swap \| DC Jack \| AC 90–275V

### 8940mAh Swappable Battery

Industry-leading 8940mAh swappable Li-Ion battery powers full-day intensive field operation. Hot-swap capability enables zero-downtime continuous use across long shifts. Adaptor input 90–275V AC with surge protection, 5V/3A DC output.

2x Micro SIM \| microSD 256GB \| BIS \| IP54

### 4G LTE \| Wi-Fi ac \| BT 5.1 \| GPS

Full connectivity stack: 2G/3G/4G LTE, dual-band Wi-Fi 802.11 ac, Bluetooth 5.1 (16dB TX), 16-channel GPS/AGPS, 2x Micro SIM, and microSD up to 256GB. CE, RoHS, BIS, FCC, and IP54 certified for field and outdoor deployments.

Advanced Technology

## Built for Mobile Government & Enterprise Field Operations

Robust engineering meets portable design for reliable biometric authentication in any environment.

Display

7" IPS LCD

1024x600 \| 16M colors \| 6H scratch-resistant glass \| Android 13

Battery

8940mAh

Hot-swap swappable \| zero-downtime field operation.

Platform

Android 13

ARM Cortex A53 2.0GHz \| 2GB RAM \| 32GB eMMC.

Connectivity

4G LTE

GPS \| Wi-Fi \| BT - always-on field sync.

Printer

2" Thermal

70mm/sec \| 48mm print width \| instant field receipts.

Strategic Applications

## Discover Our Solutions

MT100 powers identity programs across government, healthcare, law enforcement, and enterprise sectors.

[Government \| AEPS **Citizen Identification** \\
Standardized enrollment for large-scale citizen identity and Aadhaar programs with multi-biometric capture.](https://www.mantratec.com/Solutions/Citizen-Identification) [Workforce Management **Biometric Attendance** \\
Mobile attendance tracking for field workers and distributed workforces with real-time central sync.](https://www.mantratec.com/Solutions/Biometrics-Attendance-System) [Healthcare \| Financial **Enterprise Security** \\
Secure patient registration, banking KYC, and financial transaction authentication at point-of-care.](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions)

Specifications

## Technical Details

Full technical specifications for system integrators and procurement teams.

HardwareBiometricPrinter & SensorsInterfacesElectrical

Hardware & Display

CPU

ARM Cortex A53 @ 2.0GHz Quad-Core

Memory

2GB RAM + 32GB eMMC

OS

Android 13

Display

7" IPS LCD, 1024x600, 16M Colors

Touch

Scratch-Resistant Multi-Point Capacitive, 6H Toughened Glass

Dimensions

237 x 236 x 87 mm

QR & Barcode

8MP AF Camera with High-Brightness Flash LED

Audio

1W Speaker

Certifications

CE, RoHS, BIS, FCC, IP54

Biometric Sensors

Fingerprint Type

Scratch-Free Optical FAP10

FP Image Size

276 x 336 Pixels (14x17 mm)

FP Resolution

500 DPI, 8-Bit Grayscale

FP Certifications

CE, FCC, RoHS, STQC L1, FBI PIV, EN/IEC 62368-1, IS13252 Part I

IRIS Spatial Res.

\> 50% @ 1.0 LP/mm

IRIS Pixel Res.

\> 10 Pixels/mm

IRIS Wavelength

700–900 nm

IRIS Certifications

CE, FCC, RoHS, BIS, IP54, STQC L0, IEC 62471

Thermal Printer & Sensors

Printer Type

Integrated 2" Thermal

Print Speed

70mm/sec

Print Width

48mm

Print Style

Black & White

Accelerometer

3-Axis

Light Sensor

Ambient Light

Interfaces & Connectivity

2G GSM/GPRS

850/900/1800/1900 MHz

3G WCDMA

B1/B2/B5/B8

4G FDD LTE

B1/B3/B5/B7/B8/B38/B40/B41

Wi-Fi

IEEE 802.11 a/b/g/n/ac (2.4&5GHz)

Bluetooth

BT & BLE 5.1, 16dB TX

GPS

16-Channel NMEA, AGPS

SD Card

microSD up to 256GB

SIM Slots

2x Micro SIM

Ethernet

10/100 Mbps (Optional)

USB

USB-A, USB-C, USB OTG

Electrical

Adapter Input

90–275V AC, 50Hz (Surge Protected)

Adapter Output

5V, 3A DC

Battery

Swappable & Rechargeable 8940mAh Li-Ion

Charging

DC Jack

Resources

## Everything You Need to Deploy

[**Product Brochure** \\
Full product brochure with technical specs and application overview for MT100 Biometric Tablet.\\
Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MT100/MT100_V1.pdf) [**Technical Support** \\
Raise a support ticket or connect with our expert biometric engineers for field deployment.\\
Get Support](https://www.mantratec.com/Products-Inquiry-Form)

## You Ask. We Answer.

Our specialists will help configure the right biometric tablet solution for your field deployment.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")