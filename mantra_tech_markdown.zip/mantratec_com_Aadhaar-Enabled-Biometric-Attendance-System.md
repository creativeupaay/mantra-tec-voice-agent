[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Products](https://www.mantratec.com/Products) [Aadhaar Products](https://www.mantratec.com/Products/Aadhaar-Products) AEBAS

Government Attendance

# Aadhaar Enabled Biometric Attendance System (AEBAS)

The Aadhaar Enabled Biometric Attendance System (AEBAS) is a Government of India initiative that records employee attendance through Aadhaar biometric authentication. Mantra's UIDAI-approved fingerprint and iris scanners are deployed across government offices, PSUs and autonomous bodies for tamper-proof, real-time attendance management.

[Get In Touch](https://www.mantratec.com/Products-Inquiry-Form)

UIDAI Approved


NIC/MeitY Compliant


attendance.gov.in Ready


ABOUT AEBAS

## Tamper-proof Government Attendance with Aadhaar Biometric Authentication

The Aadhaar Enabled Biometric Attendance System (AEBAS) is a Central Government initiative mandated by the Department of Personnel and Training (DoPT) under the Ministry of Personnel. It records the attendance of all Central Government employees through Aadhaar-based biometric authentication - instantly uploading attendance data to the attendance.gov.in portal managed by NIC.

Mantra's UIDAI L1 certified biometric devices - fingerprint scanners and iris scanners - are deployed at government office entry points where employees place their fingerprint or iris for authentication. The system eliminates manual attendance registers, proxy marking and buddy punching - providing government departments with real-time, accurate attendance records and analytics.

Eliminates proxy attendance marking

Real-time sync to attendance.gov.in

Centralised monitoring by DoPT

Fingerprint & iris authentication

Works across all Central Govt offices

UIDAI L1 encrypted data security

HOW IT WORKS

## AEBAS Attendance Process Flow

1

###### Employee Authentication

The employee places their finger on the Mantra biometric device installed at the office entrance. The device captures the fingerprint and authenticates via UIDAI's encrypted L1 RD Service in under 2 seconds.

2

###### Instant Attendance Record

On successful Aadhaar authentication, the attendance timestamp - date, time and employee identity - is logged and instantly transmitted to the attendance.gov.in portal for real-time viewing.

3

###### Centralised Monitoring

Department heads, ministry officials and DoPT view attendance dashboards, punctuality reports and absence analytics on attendance.gov.in - enabling data-driven HR management across government.

KEY BENEFITS

## Why Mantra for AEBAS Attendance?

###### UIDAI L1 Certified

Mantra's biometric devices are UIDAI L1 certified - the highest security level for Aadhaar authentication - ensuring compliance with all government mandates for AEBAS.

###### Tamper-proof Records

Aadhaar biometric authentication cannot be forged - every attendance record is cryptographically tied to the employee's Aadhaar identity, eliminating proxy marking completely.

###### Real-time Data Sync

Attendance data is uploaded to attendance.gov.in in real time - department heads see live attendance status for all employees at any moment of the day.

###### Analytics & Reports

Automated punctuality reports, late arrival trends, absence patterns and monthly attendance summaries - actionable insights for government HR administrators.

###### Simple Installation

USB plug-and-play setup with no complex networking required. The AEBAS application is pre-installed on attendance.gov.in - device just needs to be connected and registered.

###### Iris Fallback Mode

MIS100V2 iris scanner provides Aadhaar authentication for employees with fingerprint challenges - ensuring 100% staff coverage for attendance compliance.

RECOMMENDED DEVICES

## Mantra Devices for AEBAS

Discover our range of STQC certified, Aadhaar-compliant devices designed for accuracy, speed, and reliability in government attendance systems.

![MFS110 for AEBAS](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.png)

WIDELY DEPLOYED

### L1 Fingerprint Scanner MFS110

The most widely deployed AEBAS fingerprint scanner at Central Government offices. UIDAI L1 certified with plug-and-play USB connectivity and full compatibility with attendance.gov.in.

Scratch-freeSensor surface

High-speedUSB 2.0 Interface

Auto-captureNIST Quality Check

WHQL CertifiedDevice Driver

[Explore Product](https://www.mantratec.com/Products/Fingerprint-Sensors/L1-Fingerprint-Scanner-MFS110) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.pdf)

### MIS100 V2 Iris Scanner

For government employees with fingerprint challenges, the MIS100V2 iris scanner provides seamless Aadhaar authentication for AEBAS attendance, ensuring 100% compliance.

Lowest FAR & FRRHigh Security

STQC CertifiedGovernment Approved

Multi-PlatformWindows, Linux, Android

Auto-CaptureIris Processing

[Explore Product](https://www.mantratec.com/Products/IRIS-Sensor/MIS100V2-IRIS-Scanner) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MIS100V2/MIS100V2.pdf)

![MIS100V2 for AEBAS](https://www.mantratec.com/Assets/Images/Pages/Products/MIS100V2/MIS100V2.png)

![MBAS50 Face Recognition Device](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/MBAS50.png)

ODMNEW

### MBAS50 Face Recognition Device

Compact Aadhaar-compliant face recognition device for AEBAS and identity-based attendance systems. Contactless authentication with Android 15 and 6.5" IPS display.

64GB + 4GB RAMMemory

Android 15Operating System

6.5" IPS LCDDisplay

Dual SIMConnectivity

[Explore Product](https://www.mantratec.com/Face-Recognition-Biometric-Device-MBAS50) [Download Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS50/MBAS50.pdf)

### MBAS30 Fingerprint AEBAS

Compact fingerprint-based biometric device for Aadhaar Enabled Biometric Attendance System. IP54 certified with 7" TFT display and FAP10 optical sensor.

32GB + 2GB RAMMemory

7" TFT 1024x600Display

CE, RoHS, IP54Certification

FAP10 OpticalSensor

[Explore Product](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System-MBAS30) [Download Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS30/MBAS30.pdf)

![MBAS30 Fingerprint AEBAS](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS30/MBAS30.png)

![MBAS40 Multi-Modal Device](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS40/MBAS40.png)

MULTI-MODAL

### MBAS40 Multi-Modal Device

Combines fingerprint and face recognition in one Aadhaar-compliant device. Rugged, portable solution for high-accuracy biometric attendance in diverse environments.

FingerprintRecognition

Face IDContactless

UIDAI L1 RDAadhaar Ready

Rugged & PortableHigh Endurance

[Explore Product](https://www.mantratec.com/Multi-Modal-Biometric-Device-for-AEBAS-MBAS40) [Download Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MBAS40/MBAS40.pdf)

FAQ

## Questions on AEBAS Attendance

Common questions about implementing the Aadhaar Enabled Biometric Attendance System with Mantra biometric devices.

Product Inquiry [079-49068001](tel:+917949068001)

###### What is AEBAS and how does it work?

AEBAS (Aadhaar Enabled Biometric Attendance System) is a Central Government initiative where employees mark their attendance using Aadhaar biometric authentication - placing their fingerprint or iris on a UIDAI-approved device at their office. Attendance is instantly recorded and synced to attendance.gov.in for centralised monitoring by DoPT and ministry officials.

###### Is AEBAS mandatory for all Central Government employees?

Yes. The DoPT has mandated Aadhaar-enabled biometric attendance for all Central Government employees under the Government of India's Digital India initiative. All Central Government ministries, departments and attached offices are required to implement AEBAS for employee attendance management.

###### Is Mantra MFS110 compatible with attendance.gov.in?

Yes. Mantra MFS110 supports UIDAI L1 RD Service and is fully compatible with the attendance.gov.in AEBAS web application. The device installs via USB plug-and-play on Windows systems - no complex configuration required. IT administrators simply register the device on the portal and employees can begin marking attendance immediately.

###### Can state governments also implement AEBAS?

Yes. While AEBAS was initially mandated for Central Government, many state governments have implemented their own Aadhaar-based biometric attendance systems. Mantra MFS110 and MIS100V2 are deployed across state government offices in multiple states - compatible with both the NIC attendance.gov.in system and state-level HR management applications.

###### What is the difference between AEBAS and GPS Biometric Attendance?

AEBAS uses fixed biometric devices installed at office entry points - employees must be physically present at the office to mark attendance. The GPS Biometric Attendance System adds location tagging via smartphone GPS - used for field officers who work outside the office. Both systems use Aadhaar authentication; the difference is in deployment mode and location verification.

## Deploy AEBAS at Your Government Office

Mantra supplies UIDAI-approved biometric devices for AEBAS deployment at Central Government ministries, state departments, PSUs and autonomous bodies across India.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")