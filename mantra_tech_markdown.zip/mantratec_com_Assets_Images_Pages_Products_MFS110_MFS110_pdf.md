# MFS110

## Optical Fingerprint Scanner

Operating USB 2.0 IP54 Lower STQC / Aadhaar Systems FAR & FRR Certified MFS110 is an elegant fingerprint device used for identification, verification and authentication processes of an individual. MFS110 offers secured biometrics data, error-free and reliable identification based on unique fingerprint biometric technology. It is fast & easy-to- use. It can be used as an alternative or a complement to those hard-to-remember passwords.

[www.mantratec.com](http://www.mantratec.com/)

* * *

Main Features

Technical Specification

Scratch Free
Sensor Surface

High speed USB 2.0
Interface Plug & Play

MINEX Compliance
Extractor

Support 180° Rotation
Authentication

Auto Finger
Detection

Ip54 Water and
Dust Protection

Application

Lowest
FAR and FRR

p Banking

Support Windows,
Android, Linux

p Compact device

p Easy-to-handle

p Simple to operate

p Corporates

p Payment

p Institution

Platen Area
16.0 mm x 19.0 mm

Sensor

Fingerprint Sensor Type
Optical Sensor

Spatial Resolution
500 DPI +/- 2%

Image size
276 x 336 Pixels

Approx. Weight
0.14 kg

Maximum Acquisition time
(Placement to Template)
< 2 Sec

Capture mode
Auto capture with built-in quality check
(incorporates NIST quality considerations)

Certifications
CE, RoHS, BIS, IP54

Security

Crypto operation
Hardware base RSA2048 Key Generation,

Secure Boot
Secure boot support by
the device

Hardware base RSA2048 Key Generation,
AES-GCM-256, SHA-256, TRNG support

Secure Memory
TEE support by the device.

Secure Memory
TEE support by the device.
Secure memory support
key wraping feature

Electrical

Operating Voltage
5V +/- 5% (USB Powered Device)

Stand by Current
50 mA

Operating Current
<90 mA

Humidity (Operating / Storage)
< 90% RH, Non-condensing

Environmental

Operating Temperature
0 to 50 °C

EMI / EMC Compliance
CE, FCC Part 15B

Compliant to Following Standard

Environmental, Health and Safety
RoHS

Biometric Data Interchange Format
ISO 19794-2 for minutiae &
ISO 19794-4 for Image Template
in Encrypted PID Data Block

Operating System
Windows 10 above, Linux, Android

Image Quality Complaince IP Rating
FBI PIV, STQC IP54

Device Driver
WHQL certified