![Loading...](https://www.mantratec.com/Download/User/assets/images/loader.gif)

Loading...

- [About Us](https://www.mantratec.com/About-Us)








##### About Us



Mantra Softech is a global leader in biometric and identity management solutions. With a focus on innovation, we provide advanced technology for various industries, including security, access control, and workforce management. Our commitment to excellence drives us to deliver reliable, scalable, and cost-effective biometric solutions worldwide.

[Explore more](https://www.mantratec.com/About-Us)









[Company\\
\\
Profile](https://www.mantratec.com/Company-Profile)



[Company\\
\\
Philosophy](https://www.mantratec.com/Company-Philosophy)



[Our\\
\\
Clientele](https://www.mantratec.com/Clientele)



[Insights\\
\\
Hub](https://www.mantratec.com/Insights)

- [R&D Lab](https://www.mantratec.com/Research-and-Development)








##### Research & Development



Mantra Softech’s state-of-the-art Research & Development Lab is dedicated to pioneering new biometric technologies. Our team of experts continuously innovates to create next-gen solutions for enhanced security, accuracy, and efficiency. We aim to stay ahead in the biometric industry by developing cutting-edge products that meet evolving market demands.

[Explore more](https://www.mantratec.com/Research-and-Development)









[Innovation &\\
\\
Knowledge](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)



[Product\\
\\
Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering)



[Embedded Hardware\\
\\
Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering)



[Embedded Software\\
\\
Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering)



[Optics & Imaging\\
\\
Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering)

- [OEM Modules](https://www.mantratec.com/products/OEM-Modules)








##### OEM Modules



We specialize in offering customizable OEM biometric modules designed for seamless integration into your hardware and systems. Our OEM solutions cater to various industries, providing flexibility, precision, and scalability. From fingerprint to facial recognition modules, Mantra Softech ensures high-quality performance tailored to your specific operational needs.

[Explore more](https://www.mantratec.com/products/OEM-Modules)









[Fingerprint\\
\\
Sensor](https://www.mantratec.com/products/OEM-Modules/Fingerprint-Scanner-Modules)



[IRIS\\
\\
Sensor](https://www.mantratec.com/products/OEM-Modules/IRIS-Scanner-Modules)

- [Media](https://www.mantratec.com/Media)








##### Media



Mantra Softech’s innovations and achievements are frequently highlighted in major global media outlets. Our breakthroughs in biometric and identity solutions continue to attract attention for their impact on industries worldwide. Stay informed about our latest products, technologies, and success stories through our regularly updated media section.

[Explore more](https://www.mantratec.com/Media)









[Events](https://www.mantratec.com/Media/Events)



[Press Releases](https://www.mantratec.com/Media/Press-Releases)



[Media Coverage](https://www.mantratec.com/Media/Coverage)



[Awards](https://www.mantratec.com/Media/Awards)



[Certificates](https://www.mantratec.com/Media/Certificates)

- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)








##### Contact



Connect with Mantra Softech to learn more about our biometric solutions and services. Whether you need product information, technical support, or business inquiries, our team is ready to assist.

[Explore more](https://www.mantratec.com/Contact-Details)









[Contact Details](https://www.mantratec.com/Contact-Details)



[Careers](https://www.mantratec.com/Careers)


[![Mantratec](https://www.mantratec.com/Download/assets/Images/logo.svg)](https://www.mantratec.com/)

- [Solutions](https://www.mantratec.com/Solutions)








##### Solutions



We pay careful attention to your needs at every point of interaction as we are passionate about delivering security solutions on time. We have a very prompt customer service team which always tries to resolve all the call request on the same day.

Mantra has the technology, people and infrastructure to deliver exceptional security and surveillance solutions to your business.

[Explore more](https://www.mantratec.com/Solutions)









[Business Security\\
\\
Systems](https://www.mantratec.com/Solutions/Business-Security-Systems)



[Enterprise Security\\
\\
Solutions](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions)



[RFID Security\\
\\
Solution](https://www.mantratec.com/Solutions/RFID-Security-Solution)



[Face Recognition\\
\\
Attendance System](https://www.mantratec.com/Face-Recognition)



[Access Control\\
\\
System](https://www.mantratec.com/Solutions/Access-Control-System)



[Biometrics Attendance\\
\\
System](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)



[Citizen\\
\\
Identification](https://www.mantratec.com/Solutions/Citizen-Identification)



[Biometric\\
\\
Technologies](https://www.mantratec.com/Solutions/Biometric-Technologies)



[Smart City\\
\\
Solution](https://www.mantratec.com/Solutions/Smart-City-Solution)



[Airport\\
\\
Solution](https://www.mantratec.com/Solutions/Airport-Solution)

- [Software](https://www.mantratec.com/Security-Solutions)












##### Security  Solutions



Mantra's comprehensive software suite offers efficient solutions for access control, visitor management, and canteen operations, integrating cutting-edge biometric technology for enhanced security and seamless operations.

[Explore more](https://www.mantratec.com/Security-Solutions)









[Pravesh Lite \\
\\
Attendance & Access Control System](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite)



[Monuk\\
\\
Visitor Management System](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk)



[Mensa\\
\\
Canteen Management System](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)



















##### Product  Solutions



Mantra's product software delivers secure and user-friendly solutions for authentication and access, utilizing advanced biometric and mobile technologies to meet diverse business security needs.

[Explore more](https://www.mantratec.com/Products-Solution)









[Multi Mabis](https://www.mantratec.com/Products-Solution/Multi-MABIS)



[Bio Logon](https://www.mantratec.com/Products-Solution/Bio-Logon)



[M-Authentication](https://www.mantratec.com/products-solution/m-Authentication)

- [Products](https://www.mantratec.com/products)








##### OEM & ODM Products



Mantra offers a cutting edge range of industrial and commercial security products that will help to safeguard your business and facilities. Most of the times the companies get confused in deciding whether to invest in a branded or local security system, but we are here to help you in making things easier.

[Explore more](https://www.mantratec.com/products)









[Aadhaar Biometric\\
\\
Attendance System](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System)



[Biometric Enrollment\\
\\
Devices](https://www.mantratec.com/products/Biometric-Enrollment-Devices)



[POS MicroATM\\
\\
Financial Terminal](https://www.mantratec.com/products/POS-MicroATM-Financial-Terminal)



[Integrated Biometric\\
\\
Devices](https://www.mantratec.com/products/Integrated-Biometric-Devices)



[Fingerprint\\
\\
Sensors](https://www.mantratec.com/products/Fingerprint-Sensors)



[Biometric\\
\\
Tablet](https://www.mantratec.com/products/Biometric-Tablet)



[Aadhaar\\
\\
Products](https://www.mantratec.com/products/Aadhaar-Products)



[IRIS\\
\\
Sensor](https://www.mantratec.com/products/IRIS-Sensor)



[Face Recognition\\
\\
Device](https://www.mantratec.com/Face-Recognition)



[Access\\
\\
Control](https://www.mantratec.com/products/Access-Control)

- [Technology](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology)








##### Technologies



Our cutting-edge technologies encompass biometric solutions, AI, machine learning, computer vision, IoT, and advanced encryption. These innovations empower businesses to enhance security, automate processes, and gain actionable insights, driving efficiency and growth in various industries.

[Explore more](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology)









[Computer Vision](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology)



[Behavioral Biometrics](https://www.mantratec.com/Behavioral-Biometrics-Technology)



[AI & ML](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology)



[Internet of things](https://www.mantratec.com/IoT-in-Biometric-Technology)



[Encryption](https://www.mantratec.com/Encryption-in-Biometric-Technology)

- [Brands](https://www.mantratec.com/Brands)








##### Our Brands



We create brands and product platforms for our customers to make things more possible. Take a look at our brand and product portfolio.











[![Servico](https://www.mantratec.com/Download/Assets/Images/Pages/Brandslogo/Servico.png)\\
Biometric Fingerprint Attendance Machine Maintenance Services.](https://www.mantratec.com/Servico)



[![RfEnergie](https://www.mantratec.com/Download/Assets/Images/Pages/Brandslogo/RFEnergie.png)\\
Solution for Inventory management, Asset tracking.](https://www.mantratec.com/RfEnergie)



[![Moreze](https://www.mantratec.com/Download/Assets/Images/Pages/Brandslogo/Moreze.png)\\
Leading kiosk manufacturer known for bespoke kiosks.](https://www.mantratec.com/Moreze)















##### Our Products



We create brands and product platforms for our customers to make things more possible. Take a look at our brand and product portfolio.











[![Alternate Text](https://www.mantratec.com/Download/Assets/Images/Pages/Brandslogo/Minopcloud.png)\\
cloud-based time-attendance system.](https://www.mantratec.com/Minopcloud)



[![Alternate Text](https://www.mantratec.com/Download/Assets/Images/Pages/Brandslogo/MXFace.png)\\
API platform that powers face recognition.](https://www.mantratec.com/Mxface)



[![Alternate Text](https://www.mantratec.com/Download/Assets/Images/Pages/Brandslogo/Mikshi.png)\\
A cutting-edge Video Analytics software designed.](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

- [Partners](https://www.mantratec.com/Partners)








##### Partners



Our cutting-edge technologies encompass biometric solutions, AI, machine learning, computer vision, IoT, and advanced encryption. These innovations empower businesses to enhance security, automate processes, and gain actionable insights, driving efficiency and growth in various industries.

[Explore more](https://www.mantratec.com/Partners)









[Solution\\
\\
Partner](https://www.mantratec.com/Partners/Solution)



[Distribution\\
\\
Partner](https://www.mantratec.com/Partners/Distribution)



[Technology\\
\\
Partner](https://www.mantratec.com/Partners/Technology)



[Consulting\\
\\
Partner](https://www.mantratec.com/Partners/Consulting)

- [Support](https://www.mantratec.com/Support)








##### Support Contact



You can download and use the fingerprint scanner driver and SDK for developing your application.



**Email:-** [servico@mantratec.com](mailto:servico@mantratec.com)



**Phone:-** [079-49068000](tel:07949068000)











[Warranty & RMA\\
\\
Process](https://www.mantratec.com/Warranty-and-RMA-Process)



[Support\\
\\
Ticket](https://www.mantratec.com/Ticket-Creation)



[Download\\
\\
Technical Resources](https://www.mantratec.com/Download/User)


# Technical Resources

- [Home](https://www.mantratec.com/)
- /
- [Support](https://www.mantratec.com/Support)
- /
- **Technical Resources**

Mantra's focus is to provide innovative products and solutions with a set of innovation. Mantra emphasizes to promote intellectual qualities in an individual and amongst the team to provide.

Product Inquiry

### Resource Finder

[**Login**](https://www.mantratec.com/Download/Admin)

#### Products Category

Authentication Devices - AadhaarEnrollment Devices - AadhaarAuthentication DevicesEnrollment DevicesWindows Logon

### Products

![Loading...](https://www.mantratec.com/Download/User/assets/images/Loader1.gif)

- ![](https://www.mantratec.com/Download/Uploads/ModelImg/MIS100V2.png)
MIS100 V2

- ![](https://www.mantratec.com/Download/Uploads/ModelImg/MFS110.png)
MFS110 (L1)

- ![](https://www.mantratec.com/Download/Uploads/ModelImg/MARC11.png)
MARC11 (L1)


![Loading...](https://www.mantratec.com/Download/User/assets/images/Loader1.gif)

Please wait for a momunt

### Resource Finder

Select Product OS

Select OS BitSelect OS Bit

Select Programming LanguageSelect Programming Language

* * *

![Loading...](https://www.mantratec.com/Download/User/assets/images/Loader1.gif)

##### User Details

Country \*Select Country

First Name \*

Last Name \*

Email Id \*

Mobile No. \*

* * *

I have read and agree to Mantra softech’s User
[Terms & Agreement](https://www.mantratec.com/Terms-of-Use) & [Privacy Policy](https://www.mantratec.com/privacy-policy).

Generate OTP

##### Download

reCAPTCHA

Recaptcha requires verification.

I'm not a robot

reCAPTCHA

Submit

##### Enter OTP

Please Enter OTP\*

Time remaining:

Submit

##### Setup Inquiry

![Loading...](https://www.mantratec.com/Download/User/assets/images/loader.gif)

Proccessing, Just a Moment...

Company Name\*

Country\*

State\*

City\*

First Name\*

Last Name\*

Country Code \*

Mobile No.\*

Email Id\*

* * *

Your Profession\*

Other Profession\*

Application Requirement For\*

Other Application Requirement\*

Describe your entire Project or Application\*

Sales/Partner Code

* * *

reCAPTCHA

Recaptcha requires verification.

I'm not a robot

reCAPTCHA

I have read and agree to Mantra softech’s User
[Terms & Agreement](https://www.mantratec.com/Terms-of-Use) & [Privacy Policy](https://www.mantratec.com/privacy-policy).

* * *

Submit

Is Account already exist?

##### Enter OTP

Please Enter OTP\*

Time remaining:

Submit

### You Done IT!

Continue

### Oh NO!

Continue

#### **About Our** Company

Mantra is a leading STQC certified manufacturer of the key Biometric product for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### **Our** Contact

- B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

- **Sales:** [sales@mantratec.com](mailto:sales@mantratec.com)
- **Support:** [servico@mantratec.com](mailto:Servico@mantratec.com)

#### **Our** Policies

- [Return Policy](https://www.mantratec.com/return-policy)
- [Privacy Policy](https://www.mantratec.com/privacy-policy)
- [Terms of Use](https://www.mantratec.com/Terms-of-Use)
- [![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=50a436b8-3969-48be-8d25-f9c817689dba "DMCA.com Protection Status")
- [![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/)

#### **Useful** Link

- [Inquiry Form](https://www.mantratec.com/Inquiry-Form)
- [Sitemap](https://www.mantratec.com/Sitemap)
- [Blogs](https://blog.mantratec.com/)
- [![CMMI L3 Certificate](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")

Copyrights © 2025 [Mantra Softech (India) Pvt. Ltd.](https://www.mantratec.com/) All Rights Reserved.

**Cookies**

We use essential and functional cookies on our website to provide you a more customized digital experience. To learn more about how we use cookies and how you can change your cookie settings, kindly refer to our [Privacy Statement](https://www.mantratec.com/privacy-policy). If you are fine to resume in light of the above, please click on 'I Accept'.

Accept Cookies

reCAPTCHA

reCAPTCHA