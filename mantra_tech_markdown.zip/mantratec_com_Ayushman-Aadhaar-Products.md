[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Products](https://www.mantratec.com/Products) [Aadhaar Products](https://www.mantratec.com/Products/Aadhaar-Products) Ayushman Bharat

Ayushman Bharat

# Aadhaar Biometric Devices for Ayushman Bharat Program

India's largest health protection scheme - PM-JAY - relies on UIDAI-compliant biometric authentication to verify patients at hospitals, dispensaries and wellness centres across the nation. Mantra is an authorised partner trusted by Ayushman Bharat Yojana.

[Get In Touch](https://www.mantratec.com/Products-Inquiry-Form) [All Aadhaar Products](https://www.mantratec.com/Products/Aadhaar-Products)

UIDAI Approved


STQC Certified


PM-JAY Recommended


![Ayushman Bharat Biometric Device](https://www.mantratec.com/Assets/Images/Pages/Products/Aadhaar-Products-all-logo/Ayushman-Aadhaar-Products.jpg)

ABOUT THE SCHEME

## Aadhaar-Enabled Healthcare Verification

The Government of India launched Ayushman Bharat Yojana - the Pradhan Mantri Jan Aarogya Yojana (AB-PMJAY) - in September 2018 to provide health insurance to 10 crore poor families. Incorporating Aadhaar biometric authentication ensures efficient, fraud-free verification of patients at the point of service.

Our Aadhaar-based biometric devices support fingerprint and iris scan methodologies for patient identification. The devices streamline the claim procedure, eliminate long queuing systems and provide seamless records management for Hospitals, Dispensaries and Wellness Centres.

- Eliminates prolonged queuing systems
- Easy patient info access via Aadhaar
- Seamless patient verification procedure

- Reduces complexity of claim procedure
- Easy management of patient records
- Simple to operate in any setting

GOVERNMENT SCHEME

### Beneficiary Identification System (BIS) Process Flow

**Source:** Pradhan Mantri Jan Aarogya Yojana (AB-PMJAY)

![BIS Process Flow](https://www.mantratec.com/Assets/Images/Pages/Products/Aadhaar-Enabled-Biometric-Attendance-System/Beneficiary-Identification-System-Process-Flow.jpg)

The Beneficiary Identification System (BIS) adopted in hospitals aids in streamlining the identification process of patients and their families. Aadhaar biometric authentication ensures accurate, real-time verification.

KEY BENEFITS

## Why Biometrics for Ayushman Bharat?

Our devices are tested and recommended by AB-PMJAY systems for flawless integration with the national health protection mission.

#### Accurate Patient Identity

Fingerprint and iris biometrics ensure only genuine beneficiaries can access the scheme, eliminating fraudulent claims.

#### Faster OPD & IPD Processing

Instant Aadhaar-based authentication drastically reduces patient check-in and verification time at hospitals.

#### Real-time Data Sync

Live connectivity to the AB-PMJAY central server ensures claim data is always current and traceable.

#### UIDAI Compliance

All Mantra devices carry L1 RD Service certification, meeting UIDAI's stringent security and accuracy standards.

#### Multi-setting Deployment

Compatible with hospitals, dispensaries, and wellness centres - urban and rural - across all Indian states.

#### Plug & Play Setup

Easy USB-based installation with no complex configuration - operational within minutes of unboxing.

RECOMMENDED DEVICES

## Mantra Biometric Devices for Ayushman Bharat

Discover our range of STQC certified, Aadhaar-compliant devices designed for accuracy, speed, and reliability in healthcare environments.

![MFS110 L1 Fingerprint Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.png)

OEM AVAILABLE

### L1 Fingerprint Scanner MFS110

Mantra MFS110 is a highly secured optical USB 2.0 FAP10 fingerprint scanner suitable for biometric verification in healthcare environments. Easy to install and compatible with the widest range of fingerprint conditions.

Scratch-freeSensor surface

High-speedUSB 2.0 Interface

Auto-captureNIST Quality Check

WHQL CertifiedDevice Driver

[Explore Product](https://www.mantratec.com/Products/Fingerprint-Sensors/L1-Fingerprint-Scanner-MFS110) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.pdf)

### MIS100 V2 Iris Scanner

Mantra MIS100V2 is a high-quality USB IRIS Scanner providing superior security through high-level image matching and iris assessment. Ultra-compact and capable of auto-capturing iris images with precision.

Lowest FAR & FRRHigh Security

STQC CertifiedGovernment Approved

Multi-PlatformWindows, Linux, Android

Auto-CaptureIris Processing

[Explore Product](https://www.mantratec.com/Products/IRIS-Sensor/MIS100V2-IRIS-Scanner) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MIS100V2/MIS100V2.pdf)

![MIS100V2 Iris Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MIS100V2/MIS100V2.png)

FAQ

## Questions on Ayushman Bharat Biometrics

Everything you need to know about Mantra's biometric devices and their role in the Ayushman Bharat health scheme.

Product Inquiry [079-49068001](tel:+917949068001)

###### What is Ayushman Bharat Yojana (AB-PMJAY)?

Ayushman Bharat Pradhan Mantri Jan Aarogya Yojana (AB-PMJAY), launched in September 2018, is India's largest government-sponsored health insurance scheme. It provides health coverage of up to ₹5 lakh per family per year for secondary and tertiary care hospitalisation to approximately 10 crore poor and vulnerable families.

###### Why are biometric devices required for Ayushman Bharat?

Biometric authentication is essential to verify the genuine identity of beneficiaries at empanelled hospitals using Aadhaar-linked fingerprint or iris data. This eliminates fraud, duplicate claims, and ensures that healthcare benefits reach only genuine patients.

###### Is Mantra a recommended partner for Ayushman Bharat?

Yes. Mantra Softech is a trusted partner recommended by Ayushman Bharat Yojana for implementing biometric solutions. Our devices are UIDAI approved and have been tested with the AB-PMJAY National Health Protection Mission systems.

###### Which Mantra device is best for hospital patient verification?

The MFS110 L1 Fingerprint Scanner is widely deployed for patient verification under Ayushman Bharat as it handles diverse fingerprint conditions including elderly and manual-labour workers. The MIS100V2 Iris Scanner is recommended for patients where fingerprint capture is challenging.

###### Are the devices compatible with existing hospital IT infrastructure?

Yes. Mantra devices support Windows (x86/x64), Linux and Android operating systems and connect via standard USB 2.0, making them compatible with virtually all existing hospital management and Ayushman Bharat BIS terminal systems without additional hardware investment.

###### How does Aadhaar biometric authentication protect patient privacy?

All authentication is performed through UIDAI's secure L1 RD Service channel. Biometric data is encrypted end-to-end and only a Yes/No authentication response is returned - no raw biometric data is stored at the hospital. This fully complies with Aadhaar Act and data protection norms.

## Deploy Ayushman Bharat Biometrics at Your Facility

Mantra's UIDAI-approved biometric devices are ready for immediate deployment at hospitals, dispensaries and wellness centres participating in AB-PMJAY.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")