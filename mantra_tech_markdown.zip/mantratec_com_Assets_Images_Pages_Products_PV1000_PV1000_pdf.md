# PV1000

### SOPHISTICATED PALM VEIN RECOGNIZATION TERMINAL

A

#### PV1000 Terminal is high end attendance terminal that recognize users

#### with the help of Palm Vein biometric signature pattern. Study shows

#### that Palm Vein biometric is most secure and most perfect biometric for

#### matching. It is best suited for highly secured areas where security is the

#### topmost concern and proxy is to be eliminated. It can also identify

workers, old age persons where other biometric fails. This technology produces the most accurate verification of the person.

* * *

SOPHISTICATED PALM VEIN
RECOGNIZATION TERMINAL

Features

PV1000

t Color 6.5'' LCD display with touch screen

t Capture photo on recognition of Palm Vein pattern

t Built in web interface

t Contact less biometric technology

t External reader connectivity (optional)

t Optional EM card / Mifare / HID Prox / HID Smart card reader

t Palm Vein sensor is certified by CE, FCC

t Live Palm Vein detection

t Sophisticated terminal enclosure

Highlights

t Sophisticated fiber housing

t Voice, audio and visual confirmation on successful and non
successful matching

t User define matching threshold

t Web based Palm Vein control
panel support

t 100% enrollment rate

Specifications

t 20000 users capacity
(Expandable up to 50000 users)

t 100000 transactions log capacity
(Expandable up to 1000000 logs)

t False Acceptance Rate 0.00008%

t 1:N, 1:1 and 1:G matching options

t False Rejection Rate 0.01%

t Highest security for 1:N matching (200 users)

t Matching speed 2 seconds for 1:1 matching

t Medium security for 1:G matching
Lowest security for 1:1 matching

t 5 LED for user indication

t TCP/IP and USB pen drive connectivity

t 100 users group can be defined (0-99)
\[Image: X1\]

t Lowest security for 1:1 matching

Mantra Softech India Pvt. Ltd.
Email: [sales@mantratec.com](mailto:sales@mantratec.com)

t DC 12V 5 Amp power input

AC ADAPTER
\[Image: X1\]

t 6.5 inch color touch screen LCD panel

t Built in voice / buzzer

t Access control feature (optional)

\[Image: X0\]

t 2MP in built camera (optional)

q Surat