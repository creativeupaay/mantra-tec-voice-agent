[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Products](https://www.mantratec.com/Products) [Aadhaar Products](https://www.mantratec.com/Products/Aadhaar-Products) Biometric Device Jeevan Pramaan

Jeevan Pramaan

# Biometric Device for Jeevan Pramaan

Launched by the Government of India in November 2014, Jeevan Pramaan digitises the entire process of acquiring Digital Life Certificates for crores of pensioners through Aadhaar-based biometric authentication - fingerprint or iris - eliminating the need to visit pension disbursing offices.

[Get a Quote](https://www.mantratec.com/Products-Inquiry-Form) [All Aadhaar Products](https://www.mantratec.com/Products/Aadhaar-Products)

UIDAI Approved


STQC Certified


Pensioner Friendly


![Jeevan Pramaan Biometric Device](https://www.mantratec.com/Assets/Images/Pages/Products/Aadhaar-Products-all-logo/Biometric-Device-Jeevan-Pramaan.jpg)

ABOUT JEEVAN PRAMAAN

## Digitalising Pension Verification for Crores of Pensioners

Jeevan Pramaan is an Aadhaar-based digital life certificate initiative for pensioners of Central Government, State Government and other Government organisations. The programme utilises the Aadhaar platform for biometric authentication of a pensioner through their fingerprint or iris, enabling the creation of a Digital Life Certificate that can be accessed by the pensioner and disbursing agencies anytime, anywhere.

Our Aadhaar-enabled biometric devices prove to be the best fit for a hassle-free, rapid authentication of pensioners. We offer high-quality fingerprint scanners and iris scanners that streamline the pension certificate process - rendering pensioners the ease of securing their certificate through advanced biometric methodologies without physical visits to government offices.

Presently, our Aadhaar fingerprint and iris scanners also serve various social welfare schemes including Ayushman Bharat Yojana, Rashtriya Bima Yojana, Janani Suraksha Yojana, Smart Cities Mission, Pradhan Mantri Gramin Awaas Yojana and many more.

WHY MANTRA

## Benefits of Mantra Devices for Jeevan Pramaan

###### Doorstep Verification

Lightweight, portable USB devices enable pensioners to complete Jeevan Pramaan authentication at home via a laptop or mobile - no office visit required.

###### High Capture Accuracy

Advanced optical sensor accommodates dry, aged or worn fingerprints common among senior citizens, ensuring successful capture on first attempt.

###### Iris Fallback Mode

MIS100V2 iris scanner provides an alternative for pensioners whose fingerprint cannot be captured - guaranteeing 100% service coverage.

###### L1 RD Service Certified

Full UIDAI L1 compliance with encrypted RD Service SDK ensures end-to-end secure biometric transmission for authentic certificate generation.

###### Android & Desktop Ready

Compatible with both Android smartphones/tablets and Windows desktops - enabling Jeevan Pramaan through Aadhaar Face RD or USB biometric devices.

###### Wide Social Scheme Coverage

The same devices serve Ayushman Bharat, PMKVY, AEBAS and other flagship schemes - maximum ROI from a single biometric investment.

RECOMMENDED DEVICES

## Mantra Devices for Jeevan Pramaan

Discover our range of STQC certified, Aadhaar-compliant devices designed for accuracy, speed, and reliability for pensioner verification.

![MFS110 L1 Fingerprint Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.png)

OEM AVAILABLE

### L1 Fingerprint Scanner MFS110

Mantra MFS110 is a highly secured optical USB 2.0 FAP10 fingerprint scanner - the primary device for Jeevan Pramaan authentication. Easy to use by pensioners at home with plug-and-play USB connection.

Scratch-freeSensor surface

High-speedUSB 2.0 Interface

Auto-captureNIST Quality Check

WHQL CertifiedDevice Driver

[Explore Product](https://www.mantratec.com/Products/Fingerprint-Sensors/L1-Fingerprint-Scanner-MFS110) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MFS110/MFS110.pdf)

### MIS100 V2 Iris Scanner

For pensioners with worn or dry fingerprints, the MIS100V2 provides seamless Jeevan Pramaan iris authentication. Ultra-compact USB device with auto-capture and high accuracy.

Lowest FAR & FRRHigh Security

STQC CertifiedGovernment Approved

Multi-PlatformWindows, Linux, Android

Auto-CaptureIris Processing

[Explore Product](https://www.mantratec.com/Products/IRIS-Sensor/MIS100V2-IRIS-Scanner) [Brochure](https://www.mantratec.com/Assets/Images/Pages/Products/MIS100V2/MIS100V2.pdf)

![MIS100V2 Iris Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MIS100V2/MIS100V2.png)

FAQ

## Questions on Jeevan Pramaan

Answers to common queries about Jeevan Pramaan digital life certificates and the biometric devices that power them.

Product Inquiry [079-49068001](tel:+917949068001)

###### What is Jeevan Pramaan?

Jeevan Pramaan is a biometric-based digital life certificate programme launched by the Government of India in November 2014. It provides pensioners of Central Government, State Government and other organisations with a digital life certificate through Aadhaar authentication, eliminating the need for annual physical visits to pension offices.

###### How does a pensioner generate a Jeevan Pramaan certificate?

A pensioner connects a Mantra MFS110 fingerprint scanner or MIS100V2 iris scanner to a computer or Android device, opens the Jeevan Pramaan application, enters their Aadhaar number and pension details, then authenticates with a fingerprint or iris scan. On successful UIDAI authentication, a unique Pramaan ID (life certificate) is generated and shared with the disbursing agency.

###### Can the Jeevan Pramaan process be done from home?

Yes. With a Mantra USB biometric device, a laptop/desktop and an internet connection, pensioners can complete the entire Jeevan Pramaan process from home. Common Service Centres (CSCs), banks and post offices also offer assisted Jeevan Pramaan services using Mantra devices.

###### Which Mantra device works best for elderly pensioners?

The MFS110 fingerprint scanner handles dry, aged or worn fingerprints commonly found in elderly users. For pensioners whose fingerprints cannot be captured due to medical conditions, the MIS100V2 iris scanner provides a reliable alternative, ensuring no pensioner is excluded from the digital certificate process.

###### Is the Mantra MFS110 officially approved for Jeevan Pramaan?

Yes. The Mantra MFS110 and MIS100V2 carry UIDAI L1 RD Service certification and are STQC certified, making them fully compliant and approved for Jeevan Pramaan biometric authentication across all government and private disbursing agencies in India.

###### What other government schemes can Mantra devices serve?

Mantra biometric devices serve a wide range of flagship programmes including Ayushman Bharat Yojana, AEBAS (Attendance System), PMKVY, DigiLocker, BHIM, AePS (Micro ATM), CSC e-Services, NDLM, VTP, Yuva Swabhiman Yojana, Rashtriya Bima Yojana, and Janani Suraksha Yojana - making them a versatile investment for any government body.

## Enable Jeevan Pramaan at Your Organisation

Contact Mantra for bulk procurement of UIDAI-approved biometric devices for pension verification across banks, post offices, CSCs and government offices.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")