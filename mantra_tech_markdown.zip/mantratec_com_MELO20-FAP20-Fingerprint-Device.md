[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")[Products](https://www.mantratec.com/Products) [Fingerprint Sensors](https://www.mantratec.com/Products/Fingerprint-Sensors) MELO20

FAP20 \| FBI PIV \| IP65 \| WBF Certified

# MELO20 Optical Fingerprint

Features a rock-solid design with special scratch-proof glass that captures perfect fingerprints every time and works flawlessly even in the toughest conditions.

Citizen IdentificationEnrollment & eKYCAccess ControlIdentity Verification

[Get a Quote](https://www.mantratec.com/Products-Inquiry-Form) [Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MELO20/MELO20.pdf)

![Mantra MELO20 Optical FAP20 Fingerprint Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MELO20/MELO20.png)

**500 DPI** Optical Sensor

**IP65** Sensor Protection

Key Highlights

## Highly Accurate, Rugged Optical Technology

Perfect for busy security checkpoints, it handles endless daily scans without breaking down. Its rugged design shrugs off dust, drops, and vibrations.

### Advanced FAP20 Sensor

500 DPI \| 300\*400px \| 15.24\*20.32mm

Exceptional ridge detail capture from a large 15.24 x 20.32mm platen area. Adaptable to all kinds of fingerprints, ensuring reliable biometric enrollment and verification.

### FBI PIV Certified

CE \| FCC Part 15B class A \| RoHS

Guaranteed high image quality meeting federal standards for identity verification. Built with scratch-proof glass to maintain optical clarity across millions of scans.

### Latent Finger Detection

Anti-Spoofing \| High Security

Features smart hardware latent finger detection that actively prevents spoofing by rejecting prints left behind on the platen surface.

### Fast & Smart Capture

Auto Capture \| < 2s

Auto Finger Detection functionality and Auto Capture with built-in quality check (incorporating NIST quality considerations) for rapid scanning under 2 seconds.

### Multi-Interface Ready

USB 2.0 \| UART\* \| SPI\*

Standard USB 2.0 interface for desktop deployments, with SPI (Up to 24 Mbps)\* and UART (Baud Rate 115200)\* communication available on the module for seamless OEM integration.

### Comprehensive OS Support

Windows \| Android \| Linux

WBF-certified drivers for Windows, plus full compatibility with Android and Linux to support custom identity verification applications across environments.

Advanced Technology

## Engineered for Harsh, Busy Environments

![MELO20](https://www.mantratec.com/Assets/Images/Pages/Products/MELO20/MELO20.png)

MELO20

Advanced FAP20 Optical Fingerprint Sensor

Image Quality

FBI PIV

Mobile ID FAP20 \| 500 DPI \| ISO/IEC Compliance

Protection

IP65

Water & Dust Protected Optical Sensor

Performance

< 2s

Rapid Auto Capture & NIST Quality Check

Interface

USB 2.0

Plug & Play \| Plus SPI & UART Modules

Security

Latent

Hardware-based Latent Finger Detection

Compliance

WBF

CE \| FCC Part 15B class A \| RoHS \| IS 13252

Discover Our Solutions

## Ideal for Large-Scale Authentication Use Cases

With its rugged build and FAP20 size, MELO20 is highly trusted in demanding, high-traffic deployments.

[Identity & KYC **Citizen Identification** \\
\\
Perfectly suited for public distribution networks, UIDAI eKYC, and citizen databases under tough environment conditions.](https://www.mantratec.com/Solutions/Citizen-Identification) [Security & Entry **Access Control System** \\
\\
FAP20 sensors provide robust and spoof-resistant authentication for high-security physical and digital access checkpoints.](https://www.mantratec.com/Solutions/Access-Control-System) [HR & Operations **Biometric Attendance System** \\
\\
High-speed identification and lower FAR make it ideal for secure and seamless employee attendance systems.](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Specifications

## Technical Details

Full specifications for procurement, integrators, and system architects.

Sensor DetailsElectrical ParametersStandards & ComplianceEnvironmental & Dimensions

Sensor Characteristics

Fingerprint Sensor Type

Scratch Free Optical Sensor

OEM Module / Sensor

MOPvO20

Pixel Resolution

500 DPI 2%

Platen Size

15.24mm x 20.32mm (FAP20)

Image Size

300 x 400 Pixels

Image Grayscale

256 (8-Bit Gray Level)

FRR & FAR

< 0.1% & < 0.001%

Acquisition Time

< 2 Sec (Placement to Template)

Capture Mode

Auto Finger Detection Functionality & Auto Capture With Built-in Quality Check (incorporates NIST Quality Considerations)

Latent Finger Detection

Supported (Does not accept prints left behind)

Light Source

RED LEDs

Electrical Characteristics

Operating Voltage

5V 5% (USB Powered Device)

Operating Current

150 mA

Standby Current

110 mA

Communication Protocol

USB 2.0, SPI (Up to 24 Mbps)\*, UART (Baud Rate - Default 115200)\*

Connector

Product: USB Type-A Male \| Module: Wire to Board\*\*

Standards & Compliance

Biometric Data Interchange

ISO/IEC 19794-2:2005 & 2011, ISO/IEC 19794-4:2005 & 2011, ANSI INCITS 378-2004, WSQ3.1, JPEG2000

EMI / EMC Compliance

CE & FCC Part 15B class A

ESD Protection

Contact: 8kV \| Air: 15kV

Health and Safety

RoHS, WEEE

Safety Standard

EN/IEC62368-1, IS 13252 (Part 1)

Image Quality Certification

FBI PIV Certified

IP Rating

IP65

Device Driver

WBF Certified

Environmental & Dimensions

Operating Temperature

-10oC to +70oC

Storage Temperature

-20oC to +85oC

Humidity

< 90% RH, Non-condensing

Device Dimensions

82.54 x 63.45 x 22.86 mm

Device Weight

Approx 0.120 kg

Module Dimensions

65.8 x 48.6 x 18.5 mm

Module Weight

Approx 0.045 kg

Operating System

Windows, Android, Linux

Standard Software/SDK

1:1 Matching: MORFIN\_AUTH \| 1:N Matching: MORFIN\_SEARCH

\\* UART & SPI interface is available in sensor module only

\\*\\* FPC Connector available for USB, UART & SPI interface in sensor module only

Resources

## Everything You Need to Deploy

[**Product Brochure** \\
Full brochure with technical specs, certifications, and integration overview for MELO20.\\
Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MELO20/MELO20.pdf) [**Technical Support** \\
Connect with our biometric engineers for integration and deployment guidance.\\
Get Support](https://www.mantratec.com/Products-Inquiry-Form)

## Expert Integration Support

Our specialists will help you integrate MELO20 into your access control or citizen identity system.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")