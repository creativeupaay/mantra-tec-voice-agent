Optical Fingerprint Scanner
Model : MFS500 \| OEM Module / Sensor : MOPv2.0

Benefits

Easy to integrate

Offers high accuracy

Easier and faster to use

USB 2.0 interface

Supports Window , Android
& Linux System
\[Image: Im0\]

Features
\[Image: Im0\]

Scratch free sensor surface
\[Image: Im0\]

Lowest FAR and FRR
\[Image: Im0\]

MINEX Compliance extractor
\[Image: Im0\]

* * *

Optical Fingerprint Scanner
Model : MFS500 \| OEM Module / Sensor : MOPv2.0

MFS500 is a high-quality fingerprint scanner for accurate fingerprint authentication process.
MFS500 is devised with an optical scratch free sensor for efficient recognition of poor
quality fingerprint. MFS500 can be used for the process of identification, verification and
authentication that captures the fingerprint images in a faster and reliable manner.

At a Glance

| Parameters |
| --- |
| Fingerprint Sensor Type |
| Spatial Resolution |
| Platen size |
| Sensing Area |
| Image Size |
| Image Grayscale |
| Light Source |
| Approx Dimensions(L x W x H) |
| Approx Weight. |
| Maximum Acquisition Time(Placement to Template) |
| Capture mode |

| Specification |
| --- |
| : Optical Scratch-Free Sensor |
| : 500 DPI+/-2% |
| : 16.4mmx20.0mm |
| : 15mmx18mm |
| : 296x354 Pixels |
| : 256(8-Bit Gray Level) |
| : RED LED |
| : 85x51x54mm(Module:61x23x28.5mm) |
| : 0.123Kg(Module:0.025Kg) |
| : <2Sec |
| : Auto Finger detection functionality&Auto capture with built-in quality check(incorporates NIST quality considerations) |

Electrical Characteristics
Parameters

| Parameters | Specification |
| --- | --- |
| Operating Voltage | :5V+/-5% (USB Powered Device) |
| Operating Current(max) | :<=85mA |
| Stand by Current(max) | :<=40mA |
| Interface | :USB2.0 |

| Parameters | Specification |
| --- | --- |
| Biometric Data Interchange Format | :ISO 19794-2,ISO 19794-4,ANSI 378,WSQ3.1,JPEG2000 |
| Environmental,Health and Safety | :RoHS |
| BIS | :IS 13252(Part1) |
| Safety | :EN/IEC60950 |
| EMI/EMC Compliance | :CE&FCC Part15 B classA |
| Image Quality | :FBIPIV Certification,Mobile-ID FAP10 |
| IP Rating | :IP54 |
| Device Driver | :WHQL Certified with Unique Serial Number |
| Operating System | :Windowsx86&x64,Linux,Android |