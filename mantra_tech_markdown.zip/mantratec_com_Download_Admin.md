[![Logo](https://www.mantratec.com/Download/Admin/assets/media/logos/logo-ellipse.svg)](https://www.mantratec.com/)

# Welcome to Mantra

Text...


# Sign In to Mantra

Email ID

Password

Copyrights © 2025 Mantra Softech (India) Pvt. Ltd. All Rights Reserved.

![](https://www.mantratec.com/Download/Admin/assets/media/logos/BGLogin.svg)

# Login

##### Log in securely and access your account

* * *

Email

PasswordForgot Password?

![](https://www.mantratec.com/Download/Admin/GetCaptchaImage)

Remember me

Login
Please wait...

Please wait...


# Two Step Verification

##### Enter the verification code we sent to -

* * *

Type your 6 digit security code

Time remaining:

Didn’t get the code ?Resend

Processing, Please Wait ...

Verify
Please wait...

Please wait...
Cancel
Please wait...


# Set New Password

##### Quickly reset your password and recover access to your account.      OTP will be sent on your Email.

Time remaining:

Didn’t get the code ?Resend

Processing, Please Wait ...

* * *

Enter OTP

New Password

Re-Type Password

Save
Please wait...

Please wait...
Cancel
Please wait...


# Set New Password

##### Quickly reset your password

* * *

New Password

Re-Type Password

Save
Please wait...

Please wait...
Cancel
Please wait...


Copyrights © 2025 Mantra Softech (India) Pvt. Ltd. All Rights Reserved.


## Set New Password

Enter OTP

Time remaining:

Didn’t get the code ?Resend

Processing, Please Wait ...

New Password

Re-Type Password

Save
Please wait...

Please wait...


#### Please Select a User to Login

ContinueClose