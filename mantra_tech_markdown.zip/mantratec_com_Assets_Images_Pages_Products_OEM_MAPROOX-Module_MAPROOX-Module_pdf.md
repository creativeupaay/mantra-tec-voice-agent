Slick Fingerprint Scanner
Model : MAPRO OX \| OEM Module / Sensor : MOPv7.0

Benefits

Scratch Resistant

High accuracy

Features
\[Image: Im0\]

Easy to use

Faster operation

Compact and light weight

Lower FAR and FRR
\[Image: Im0\]

fingerprint sensor
\[Image: Im0\]

500 DPI optical
fingerprint sensor
\[Image: Im0\]

Support Aadhaar auth
API specification V2.0
\[Image: Im0\]

MINEX compliance extractor
\[Image: Im0\]

FBI PIV Certified
\[Image: Im0\]

* * *

Slick Fingerprint Scanner
Model : MAPRO OX \| OEM Module / Sensor : MOPv7.0

Mapro OX is a faster, accurate and reliable fingerprint scanner used for the authentication
and verification purposes. Mapro OX is a portable device that is easy to carry anywhere at
any time for identification of an individual. The device is scratch resistant hence it will have
longer life. Mapro OX is MINEX compliance extractor.

At a Glance

| Sensor Characteristics |  |
| --- | --- |
| Parameters |  |
| Fingerprint Sensor |  |
| Spatial Resolution |  |
| Sensing Area |  |
| Image Size |  |
| Image Grayscale |  |
| Sensing Area Hardness |  |
| Maximum Acquisition Time(Placement to Template) |  |
| Approx Dimensions(L x W x H) |  |
| Approx Weight |  |

| Specification |
| --- |
| : Optical Sensor |
| : 500 DPI +/-2% |
| : 12.8mmx18mm |
| : 256x360 Pixels |
| : 256(8-Bit Gray Level) |
| : 8H |
| : <2sec |
| : 42x27.5x6.5mm |
| : 0.008Kg |

| Parameters | Specification |
| --- | --- |
| Operating Voltage | :5V+/-5% (USB Powered Device) |
| Operating Current(max) | :110mA |
| Stand by Current(max) | :66mA |
| Interface | :USB2.0/SerialTTL |

Environmental Characteristics
Parameters

| Parameters |  |
| --- | --- |
| Biometric Data Interchange Format |  |
| Environmental, Health and Safety |  |
| BIS |  |
| Safety |  |
| EMI/EMC Compliance |  |
| \*FBI PIV Certification |  |
| \*STQC Certification |  |
| IP Rating |  |
| Device Driver |  |
| OS Supports |  |
| \*Applied for certification |  |

| Specification |
| --- |
| :ISO 19794-2 for minutiae&ISO 19794-4 for Image Template |
| :RoHS Certification |
| :IS 13252(Part1) |
| :IEC60950 |
| :CE&FCC ClassA |
| :Compliance |
| :Yes |
| :IP67(Platen Area) |
| :WHQL Certified |
| :Window x86&x64,Linux,Android |

Compliant to Following Standard
Parameters