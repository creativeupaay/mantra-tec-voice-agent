# Ms30

## INTELLIGENT CLOUD READER WITH DYNAMIC QR CODE

2G/4G WIFI QR Code LED Display

**Strong Scalability \| Easy to Use \| Ultra-fast Recognition \| HD Speaker Audio \| Fast Payment**

#### [www.mantratec.com](http://www.mantratec.com/)

### MAKE IN INDIA

* * *

With the Payment Sound Box, customers are immediately notified when their payment is accepted or declined, which can help reduce the
time spent waiting in lines and increase overall customer satisfaction by bringing transparency.

Features

Smart Applications

Integrated user friendly design

Restaurant

Instant Sound Notification for payment transaction,
Battery, Device and Network.

Scenic Spot
Entrance

Loud 85db sound output for clear communication

Convenience
Store

Toll
station

LED indication for Network and Battery

Parking
lot

Supermarket

7-Segment display feature to show received
amount (Optional)

Dynamic QR code

Time Sync from NTP.

* * *

Specification

CPU
ARM® Dual-core Cortex-A5, 500MHz

SIM Card Slot
1x Micro Sim Card

Communication
2G ( EGSM900/DCS1800)
4G (LTE-FDD:B1/B3/B5/B8 & LTE-TDD:B34/B38
/B39/B40/B41)
Wi-Fi 2.4GHz (Optional)

Button

1x Power key, 1x Reset key, 2x Volume Up &
Down key, 1x Function Key

Power Supply
DC 5V / 1A

Battery Capacity
2000mAh Li-ion Rechargeable Battery

Electrical Safety: BIS
EMI / EMC Compliance : CE, WPC
ESD protection Contact Discharge : +/- 8kV,
Air Discharge: +/- 15kV Environmental, Health and Safety: RoHS

Compliant to Following Standard
Electrical Safety: BIS

Memory
RAM: 16MB & FLASH: 8MB

Display
7 Segment LED Display (6 - Digit)
Customer Screen: 2.4", TFT Color Screen, 320\*240 Pixels.

LED Indication
1x Battery status, 1x Network Connectivity

Firmware
Upgrade Over The Air

Speaker
4Ohm 3W (Adjustable Volume)

Perip Ports
1x Powered USB TYPE-C

+50^{\\circ}\\mathbb{C}

+70^{\\circ}C

0^{\\circ}C

10^{\\circ}C

Operating Temperature: 0°C to +50°C

Storage Temperature:-10°C to +70°C

Humidity (Operating / Storage) : 5% - 95%
RH, Non-condensing

Environmental

* * *

# [www.mantratec.com](http://www.mantratec.com/)