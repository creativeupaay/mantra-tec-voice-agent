# Smart Authentication Keyboard

## Model : MSKB100

Mantra Softech is a Global Hi-Tech Manufacturer of Biometric Products and Solutions. We offer a Wide Range of Products in Biometric and RFID Industry.

* * *

SMART AUTHENTICATION KEYBOARD MSKB100

Introduction

This Smart Card Authentication Keyboard provides durable typing solution, stylish keyboard access secured PCs or
networks directly from your keyboard. The Mantra’s Smart Keyboard Authentication Keyboard MSKB100 has an
integrated smart card reader and built-in biometric finger print module for easy authentication at your fingertips.

PC/SC compliant wired USB connectivity helps provide secure, fast data transfers while eliminating the need for batteries.

MSKB100 offers users the convenience to gain access to confidential files with the swipe of a finger. The state of the art
biometric solution for authentication gives you the convenience of simple fingerprint authentication only, or configure for
one of the most secure log-in processes.

Features

u USB Bus Powered Device; Interated USB HUB to
drive all three entities Keyboard, SCR & Finger Print
Module

u Number of Keys 104 = International with Windows
Vista ™ Keys

u CCID Compliance

u FBI PIV & STQC Certififed fingerprint module

Smart Card Reader:

u Read/write speed up to 848 kbps

u Built-in antenna for contactless tag access, with card
reading distance of up to 50 mm (depending on tag
type)

u Supports all types of ISO 14443 Compliant
Contactless Card

u Built-in anti-collision feature (only 1 tag is accessed
at any time)

* * *

SMART AUTHENTICATION KEYBOARD MSKB100

At a Glance

| Device Details | Standard Keyboard |
| --- | --- |
| Smart Card Reader |  |
| Wireless Operating Frequency |  |
| Protocol / Smart Card Interface supported |  |
| Operating Distance |  |
| Status Indicator |  |
| PC-Linked Mode |  |
| Host Interface |  |
|  |  |
| Fingerprint Sensor(Optional) | Fingerprint Sensor Type |
| Pixel Resolution |  |
| Image Capture Speed |  |
| Biometrics Standard |  |
| Certification |  |
| Electrical Characteristics | Operating Voltage |
| Operating Current |  |
| Stand by Current |  |
| Interface |  |
| Environmental Characteristics | Operating Temperature |
| Storage Temperature |  |
| Humidity(Operating/Storage) |  |
| Compliant to Following Standard | Environmental,Health and Safety |
| CE Marking |  |
| Operating System |  |
| Mechanical Details | Dimension |
| Weight |  |

|  | :Number of Keys 104 = International with Windows Vista Keys |
| --- | --- |
|  | :Contactless |
|  | :13.56MHz |
|  | :ISO 14443 A/B |
|  | :Close Proximity of Card Holder Provided with Keyboard |
|  | :Bi-Color LED |
|  | :PC/SC |
|  | :Through a common USB2.0 interface cable |
|  | :Optical Scratch free sensor |
|  | :500 DPI +/-2% |
|  | :less than 1 sec |
|  | :ISO 19794-2 for minutiae & ISO 19794-4 for Image Temp |
|  | :IEC60950, RoHS, CE,FCC,FBI PIV,STQC |
|  | :5V+/-5% Vdc(USB Powered Device) |
|  | :140mA-200mA(Maximum Rated Value;Subject to Type of Card) |
|  | :60mA-100mA(Intermittent RF Transmission) |
|  | :PC/SC |
|  | :0 to 50℃ |
|  | ：(-20) to 70℃ |
|  | ：10%-90%(Non condensing) |
|  | :RoHS |
|  | :YES |
|  | :Windows x86&x64,BOSS OS,Linux |
|  | :450.50mm(L)x196.42mm(W)x54.57mm(H) |
|  | :Approx1110gm |

* * *

# Support : [servico@mantratec.com](mailto:servico@mantratec.com) Sales : [sales@mantratec.com](mailto:sales@mantratec.com)