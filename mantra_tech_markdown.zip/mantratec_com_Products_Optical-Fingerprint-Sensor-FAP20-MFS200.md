[About Us](https://www.mantratec.com/About-Us) [R&D Lab](https://www.mantratec.com/Research-and-Development) [Insights Hub](https://www.mantratec.com/Insights) [Media](https://www.mantratec.com/Media) [Blog](https://blog.mantratec.com/) [Contact](https://www.mantratec.com/Contact-Details)

[![Mantratec - Innovation that counts](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

- Business

- Solutions

- Products

- Technology

- Partners

- Support


Search `Ctrl K`

Security & Surveillance

[Enterprise Security Solutions\\
\\
End-to-end enterprise protection](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [RFID Security Solution\\
\\
Smart card access & tracking](https://www.mantratec.com/Solutions/RFID-Security-Solution) [Face Recognition Attendance\\
\\
AI-powered contactless check-in](https://www.mantratec.com/Face-Recognition) [Access Control System\\
\\
Multi-factor door & gate control](https://www.mantratec.com/Solutions/Access-Control-System) [Biometrics Attendance\\
\\
Fingerprint & iris time tracking](https://www.mantratec.com/Solutions/Biometrics-Attendance-System)

Citizen & Smart City

[Citizen Identification\\
\\
National ID & enrollment](https://www.mantratec.com/Solutions/Citizen-Identification) [Biometric Technologies\\
\\
Multi-modal biometric platform](https://www.mantratec.com/Solutions/Biometric-Technologies) [Smart City Solution\\
\\
Integrated urban intelligence](https://www.mantratec.com/Solutions/Smart-City-Solution) [Airport Solution\\
\\
Passenger flow & security](https://www.mantratec.com/Solutions/Airport-Solution)

Software

[Pravesh Lite\\
\\
Attendance & Access](https://www.mantratec.com/Security-Solutions/Attendance-System-Pravesh-Lite) [Monuk\\
\\
Visitor Management](https://www.mantratec.com/Security-Solutions/Visitor-Management-System-Monuk) [Mensa\\
\\
Canteen Management](https://www.mantratec.com/Security-Solutions/Canteen-Management-System-Mensa)

Security & Surveillance

[Enterprise Security & Surveillance](https://www.mantratec.com/Solutions/Enterprise-Security-and-Surveillance) [Defence Security & Surveillance](https://www.mantratec.com/Solutions/Defence-Security-and-Surveillance) [Port & Marine Security & Surveillance](https://www.mantratec.com/Solutions/Port-Marine-Security-and-Surveillance)

Enterprise Platform

Megh PI

Workforce management - attendance, visitor & canteen in one cloud platform.

[Explore Products](https://www.mantratec.com/Security-Solutions/Megh-PI)

Unified Access Control

MACS

7-module access control system - IOG, ACS, VMS, canteen, T&A & more.

[Explore Products](https://www.mantratec.com/Security-Solutions/MACS)

Request Demo

Certifications

Case Studies [View All Solutions](https://www.mantratec.com/Solutions)

Biometric Devices

[Aadhaar Biometric Attendance\\
\\
UIDAI certified attendance systems](https://www.mantratec.com/Aadhaar-Enabled-Biometric-Attendance-System) [Biometric Enrollment Devices\\
\\
High-speed multimodal enrollment](https://www.mantratec.com/Products/Biometric-Enrollment-Devices) [POS MicroATM Terminal\\
\\
Financial-grade biometric POS](https://www.mantratec.com/Products/POS-MicroATM-Financial-Terminal) [Integrated Biometric Devices\\
\\
All-in-one capture & verify](https://www.mantratec.com/Products/Integrated-Biometric-Devices)

Sensors & Hardware

[Fingerprint Sensors\\
\\
OEM & standalone modules](https://www.mantratec.com/Products/Fingerprint-Sensors) [IRIS Sensor\\
\\
High-accuracy iris recognition](https://www.mantratec.com/Products/IRIS-Sensor) [Face Recognition Device\\
\\
3D liveness + face match](https://www.mantratec.com/Face-Recognition) [Biometric Tablet\\
\\
Portable enrollment station](https://www.mantratec.com/Products/Biometric-Tablet)

Access & Aadhaar

[Access Control\\
\\
Door, gate & turnstile systems](https://www.mantratec.com/Products/Access-Control) [Aadhaar Products\\
\\
Government-grade UIDAI solutions](https://www.mantratec.com/Products/Aadhaar-Products)

Product Solutions

[Multi MABIS\\
\\
Multi application biometric integration](https://www.mantratec.com/Products-Solution/Multi-MABIS) [Bio Logon\\
\\
Biometric PC authentication](https://www.mantratec.com/Products-Solution/Bio-Logon) [M-Authentication\\
\\
Mobile biometric verification](https://www.mantratec.com/Products-Solution/m-Authentication)

OEM Modules

[Fingerprint Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/Fingerprint-Scanner-Modules) [IRIS Sensor Modules](https://www.mantratec.com/Products/OEM-Modules/IRIS-Scanner-Modules)

Best Seller

MXFace SDK

Enterprise face recognition SDK - 99.8% accuracy across 50M+ faces.

[Download SDK](https://www.mantratec.com/Mxface)

99.8%

Match

Accuracy

50M+

Enrolled

Records

200ms

Response

Time

25+

Years

Expertise

Product Catalog

Compare Products [All Products](https://www.mantratec.com/Products)

Core Technologies

[Computer Vision\\
\\
Real-time object & face detection](https://www.mantratec.com/Computer-Vision-in-Biometric-Technology) [Behavioral Biometrics\\
\\
Pattern analysis & anomaly detection](https://www.mantratec.com/Behavioral-Biometrics-Technology) [AI & Machine Learning\\
\\
Deep learning biometric models](https://www.mantratec.com/AI-and-ML-in-Biometric-Technology) [Internet of Things (IoT)\\
\\
Connected device ecosystems](https://www.mantratec.com/IoT-in-Biometric-Technology) [Encryption\\
\\
Military-grade data security](https://www.mantratec.com/Encryption-in-Biometric-Technology)

Engineering

[Product Engineering](https://www.mantratec.com/Research-and-Development/Product-Engineering) [Embedded Hardware Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Hardware-Engineering) [Embedded Software Engineering](https://www.mantratec.com/Research-and-Development/Embedded-Software-Engineering) [Optics & Imaging Engineering](https://www.mantratec.com/Research-and-Development/Optics-and-Imaging-Engineering) [Advanced Algorithms](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge) [Quality Assurance](https://www.mantratec.com/Research-and-Development/Innovation-and-Knowledge)

Research Platform

Mikshi AI Engine

Proprietary AI inference engine powering next-gen biometric deployments at scale.

[Read Whitepaper](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

99.8%

Accuracy rate

50M+

Enrolled records

Technical Docs [Explore Technology](https://www.mantratec.com/Research-and-Development)

Trusted Identity &

Credentials

[Cognitive Intelligence\\
\\
AI-driven biometric recognition and identity intelligence systems](https://www.mantratec.com/Business/Cognitive-Intelligence) [Identity Sensor\\
\\
High-precision fingerprint and iris biometric sensing technologies](https://www.mantratec.com/Business/Identity-Sensors) [Identity Solutions\\
\\
End-to-end digital identity, authentication and verification platforms](https://www.mantratec.com/Business/Identity-Solutions) [Identity Device Systems\\
\\
Secure, scalable hardware integrated identity capture and processing](https://www.mantratec.com/Business/Identity-Device-System)

Critical Infrastructure &

National Systems

[AeroTech\\
\\
Integrated airport security systems ensuring safe passenger operations](https://www.mantratec.com/Business/AeroTech) [Maritime Systems\\
\\
Advanced maritime surveillance and port security management systems](https://www.mantratec.com/Business/Maritime-Systems) [Defence Tech\\
\\
Mission-critical defense security systems for national protection](https://www.mantratec.com/Business/Defence-Tech)

Enterprise Access &

Homeland Security

[Enterprise & Homeland Security\\
\\
Advanced surveillance and protection for critical enterprise environments](https://www.mantratec.com/Business/Enterprise-Homeland-Security) [MTRAX Identity\\
\\
RFID-based tracking, identification and secure access management systems](https://www.mantratec.com/Business/Mtrax-RFID) [Vision Tech\\
\\
Intelligent video surveillance with real-time monitoring and analytics](https://www.mantratec.com/Business/Vision-Tech)

Connected Spaces &

AI Vision

[Mikshi\\
\\
AI-powered video analytics for real-time insights and monitoring](https://www.mantratec.com/Business/Mikshi) [Smart Space\\
\\
Integrated smart access and automation for modern infrastructures](https://www.mantratec.com/Business/Smart-Space) [Mangoe\\
\\
Intelligent home automation for security, comfort and control](https://www.mantratec.com/Business/Mangoe-Home-Automation)

4 Business Groups

15+ Business Units

1B+ Identities Secured [Explore All Business Groups](https://www.mantratec.com/Business)

Brand Ecosystem

### Explore Mantra Brands

AI, biometrics, RFID, and identity technologies organized for faster discovery.

[Compare Solutions](https://www.mantratec.com/Solutions) [Talk to Expert](https://www.mantratec.com/Contact-Details)

[![MyRFID](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MyRFID.png)Access Tech\\
\\
RFID readers, smart tags & IoT gateways for real-time asset tracking and access control across Indian industry.\\
\\
Asset TrackingAccess ControlIoT Gateway\\
\\
Explore brand](https://www.mantratec.com/MyRFID) [![Moreze](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Moreze.png)Hardware\\
\\
India's leading kiosk manufacturer - self-service eKYC, Aadhaar authentication and citizen services without staff.\\
\\
eKYC KiosksAadhaar AuthSelf-Service\\
\\
Explore brand](https://www.mantratec.com/Moreze) [![MXFace](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/MXFace.png)AI Engine\\
\\
99.5%+ accuracy face recognition API - real-time 1:N identification, liveness check & spoof detection at scale.\\
\\
1:N MatchingLiveness CheckREST API\\
\\
Explore brand](https://www.mantratec.com/Mxface) [![Mikshi AI](https://www.mantratec.com/Assets/Images/Pages/Brandslogo/Mikshi.png)Vision AI\\
\\
AI-powered VSaaS that turns existing camera footage into actionable business insights - live in 48 hours.\\
\\
Smart CCTVCrowd AnalyticsVSaaS\\
\\
Explore brand](https://www.mantratec.com/AI-Video-Analytics-VSaaS-MIkshi)

Brand assets and media kit available on request. [All Brands](https://www.mantratec.com/Brands)

Partner Types

[Solution Partner\\
\\
Co-create and resell complete solutions](https://www.mantratec.com/Partners/Solution) [Distribution Partner\\
\\
Authorized product distributors](https://www.mantratec.com/Partners/Distribution) [Technology Partner\\
\\
API & platform integrations](https://www.mantratec.com/Partners/Technology) [Consulting Partner\\
\\
Advisory & implementation services](https://www.mantratec.com/Partners/Consulting)

Join Our Network

Become a Partner

Join 200+ partners across India and SEA. Earn up to 30% margin with our tiered program.

[Apply Now](https://www.mantratec.com/Partners)

[Partner Program Overview](https://www.mantratec.com/Partners)

Support Services

[Warranty & RMA Process\\
\\
Return & repair authorizations](https://www.mantratec.com/Warranty-and-RMA-Process) [Support Ticket\\
\\
Raise & track service requests](https://www.mantratec.com/Ticket-Creation) [Download Technical Resources\\
\\
Drivers, manuals & firmware](https://www.mantratec.com/Download/User)

Downloads

[Brochures](https://www.mantratec.com/Products/Brochures)

24 / 7 Support

079-49068000


servico@mantratec.com


Critical issues resolved within 4 hrs SLA


[Open Ticket](https://www.mantratec.com/Support)

SLA: Critical issues resolved within 4 hours [Support Portal](https://www.mantratec.com/Support)

- [Business](https://www.mantratec.com/Business)
- [Solutions](https://www.mantratec.com/Solutions)
- [Products](https://www.mantratec.com/Products)
- [Technology](https://www.mantratec.com/Research-and-Development)
- [Business](https://www.mantratec.com/Business)
- [Partners](https://www.mantratec.com/Partners)
- [Support](https://www.mantratec.com/Support)
- [About Us](https://www.mantratec.com/About-Us)
- [R&D Lab](https://www.mantratec.com/Research-and-Development)
- [Media](https://www.mantratec.com/Media)
- [Blog](https://blog.mantratec.com/)
- [Contact](https://www.mantratec.com/Contact-Details)
- [Careers](https://www.mantratec.com/Careers)

Esc

[Home](https://www.mantratec.com/ "Home")/ [Products](https://www.mantratec.com/Products)/ [Fingerprint Sensors](https://www.mantratec.com/Products/Fingerprint-Sensors)/MFS200FAP20 \| FBI PIV \| IP65 \| WBF \| USB-IF \| Linux

# MFS200 FAP20 Optical Fingerprint Scanner

The Mantra MFS200 is an FBI PIV certified optical fingerprint scanner boasting the highest standards in image quality, reliability, and compatibility. It is fully compliant with ANSI 378 and ISO 19794-2 standards, supports WSQ format, and features Latent Finger Detection for secure authentication across Windows, Android, and Linux.

Financial ServicesE-GovernancePublic SecurityPC Security

[Get a Quote](https://www.mantratec.com/Products-Inquiry-Form) [Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MFS200/MFS200.pdf)

![Mantra MFS200 FAP20 Optical Fingerprint Scanner](https://www.mantratec.com/Assets/Images/Pages/Products/MFS200/MFS200.png)

**FAP20** Optical

**IP65** Protected

**FBI PIV** Certified

Key Highlights

## FAP20 Precision for Financial & Government

MFS200 bridges FAP10 and FAP30 with a certified 15.24 x 20.32 mm sensing area - delivering high-performance capture in a compact desktop form factor.

FAP20 Optical \| 500 DPI

### High Resolution Sensing

Scratch-free optical sensor captures 300 x 400 pixel grayscale images from a 15.24 x 20.32 mm (0.6 x 0.8 Inch) sensing area using a RED LED light source for consistent image quality.

FBI PIV \| WBF \| USB-IF

### Global Certifications

FBI PIV certified image quality ensures compliance with federal ID standards. Fully compliant with ANSI 378, ISO 19794-2, CE, FCC, RoHS, and EN/IEC 62368-1. WBF driver enables seamless Windows integration.

Latent Detection \| Low FAR

### Industry-Leading Accuracy

Latent finger detection prevents spoofing. Combined with a MINEX-certified high-performing fingerprint algorithm, it offers an exceptional FRR < 0.1% and FAR < 0.001% for secure transactions.

ESD Protection \| Rugged

### Extreme Durability

Superior ESD protection (Contact Discharge: 8kV, Air Discharge: 15kV) and IP65 rating. Operates reliably from -10oC to +70oC in demanding environments.

1:1 & 1:N Morfin SDK

### Comprehensive Software

Bundled with Morfin Authentication (1:1 verify) and Search (1:N identify) SDKs. Supports all biometric use cases from simple login to large-scale database identification on Windows, Android, and Linux.

OEM Module: MOPvO200

### Versatile Integration

Compact 68 x 56.5 x 31.5 mm device footprint. Also available as an ultra-compact OEM sensor module MOPvO200 (35g) for seamless embedding into ATMs, POS terminals, and kiosks.

Advanced Technology

## Built for Financial-Grade FAP20 Authentication

The trusted choice for identity verification across banking, e-governance, and public delivery systems.

Sensor Grade

FAP20

500 DPI \| 300 x 400px \| 15.24 x 20.32 mm (0.6 x 0.8 Inch) platen coverage for high-quality fingerprints.

Protection

IP65

Dust-tight \| Water-jet protected \| ESD Contact 8kV / Air 15kV.

Certification

FBI PIV

WBF driver \| USB-IF \| CE \| FCC \| RoHS \| EN/IEC 62368-1 & IS 13252 (Part 1) compliant.

Accuracy

FRR < 0.1%

FAR < 0.001% \| MINEX-certified fingerprint algorithm \| Latent finger detection.

SDK Support

Morfin

1:1 & 1:N matching \| Windows, Android 7+, & Linux support \| WBF integration.

Sector Solutions

## Discover Our Solutions

MFS200's FBI PIV certified scanner and Morfin SDK make it the global benchmark for secure identity verification.

[Government \| UIDAI **Citizen Identification** \\
FAP20 capture powers Aadhaar eKYC, AEPS transactions, and e-governance beneficiary authentication programs.](https://www.mantratec.com/Solutions/Citizen-Identification) [Banking \| Payment **Enterprise Security Solutions** \\
FBI PIV certified precision for account opening, KYC verification, and retail biometric checkout in financial institutions.](https://www.mantratec.com/Solutions/Enterprise-Security-Solutions) [Platform \| Desktop **Biometric Technologies** \\
Windows Hello compliant desktop authentication for secure enterprise login, VPN access, and privileged identity management.](https://www.mantratec.com/Solutions/Biometric-Technologies)

Specifications

## Technical Details

Full technical breakdown for procurement, integrators, and IT managers.

SensorElectricalEnvironmentalStandardsDimensionsSystem Req.

Sensor Characteristics

Sensor Type

Scratch Free Optical Sensor

Pixel Resolution

500 DPI  2%

Sensing Area

15.24mm x 20.32mm (0.6 x 0.8 Inch)

Image Size

300 x 400 Pixels

Image Grayscale

256 (8 - Bit Gray Level)

FRR & FAR

< 0.1% & < 0.001%

Max Acquisition Time

< 2 Sec ( Placement to Template )

Illumination

RED LED

Capture Mode

Auto Finger detection functionality & Auto capture with built-in quality check (Incorporates NIST quality considerations)

Electrical Characteristics

Protocol

USB 2.0

Operating Voltage

5V  5% (USB Powered Device)

Operating Current

Operating Current: < 100 mA & Standby Current : < 50 mA

Environmental Characteristics

Operating Temp.

-10oC to +70oC

Storage Temp.

-20oC to +85oC

Humidity

< 90% RH, Non-condensing (Operating / Storage)

Standards & Compliance

Biometric Format

RAW/WSQ/JPEG/ISO19794-2/4:2005 and 2011, ANSI378 for minutiae Image Template

EMI / EMC

CE & FCC Part 15B class A

ESD protection

Contact Discharge:  8kV, Air Discharge:  15kV

Health & Safety

RoHS

Safety

EN / IEC 62368-1, IS 13252 (Part 1)

Image Quality

FBI PIV Certification

IP Rating

IP65

Device Driver

WBF Driver

USB-IF

Yes

Dimensions & Weight

Device Dimensions

68 x 56.5 x 31.5 mm

Device Weight

105 grams

Module Dimensions

44.10 x 38 x 28.7 mm

Module Weight

35 grams

System Requirements

Operating System

Windows - x86 & x64, Android - 7 & Above

Standard Software/SDK

1:1 Morfin Authentication, 1:N Morfin Search

Resources

## Everything You Need to Deploy

[**Product Brochure** \\
Full brochure with technical specs and application overview for MFS200 FAP20 scanner.\\
Download PDF](https://www.mantratec.com/Assets/Images/Pages/Products/MFS200/MFS200.pdf) [**Technical Support** \\
Connect with our expert biometric engineers for Morfin SDK integration and support.\\
Get Support](https://www.mantratec.com/Products-Inquiry-Form)

## You Ask. We Answer.

Our biometric specialists will help you integrate MFS200 for financial-grade authentication in your platform.

[Contact Us](https://www.mantratec.com/Inquiry-Form) [Schedule Appointment](https://www.mantratec.com/Products-Inquiry-Form)

[![Mantra Softech](https://www.mantratec.com/Assets/Images/logo.svg)](https://www.mantratec.com/)

Mantra is a leading STQC certified manufacturer of key biometric products for Aadhaar project in India. We provide Fingerprint scanner & Iris scanner for Aadhaar enrollment center.

#### Contact

###### Address :

B203, Shapath Hexa, Opp. Gujarat High Court, S.G. Highway, Sola, Ahmedabad - 380060, Gujarat.

###### Sales :

[sales@mantratec.com](mailto:sales@mantratec.com)

###### Support :

[servico@mantratec.com](mailto:Servico@mantratec.com)

#### Support

- [Download Resources](https://www.mantratec.com/Download/User)
- [Support Ticket](https://www.mantratec.com/Ticket-Creation)
- [Warranty & RMA](https://www.mantratec.com/Warranty-and-RMA-Process)

#### About

- [Who We Are](https://www.mantratec.com/About-Us)
- [Careers](https://www.mantratec.com/Careers)
- [Partners](https://www.mantratec.com/Partners)
- [Media](https://www.mantratec.com/Media)
- [Investors](https://www.mantratec.com/Investors)
- [Contact Us](https://www.mantratec.com/Contact-Details)

#### Insights Hub

- [Blog](https://blog.mantratec.com/)
- [Media](https://www.mantratec.com/Media)
- [Our Brands](https://www.mantratec.com/Brands)

GET IN TOUCH

[Book Discovery Call](https://www.mantratec.com/Inquiry-Form)

[Investors](https://www.mantratec.com/Investors) [Return Policy](https://www.mantratec.com/Return-Policy) [Privacy Policy](https://www.mantratec.com/Privacy-Policy) [Terms Of Use](https://www.mantratec.com/Terms-of-Use) [Sitemap](https://www.mantratec.com/Sitemap)

© 2026 All Rights Reserved By **Mantra Softech (India) Pvt. LTD.**

[![DMCA.com Protection Status](https://www.mantratec.com/Assets/Images/dmca_protected.png)](https://www.dmca.com/Protection/Status.aspx?ID=c9c090e6-6cab-468e-9e5a-52aaac5aa6b3 "DMCA.com Protection Status")[![Protected by Copyscape](https://www.mantratec.com/Assets/Images/copyscape.png)](http://www.copyscape.com/ "Protected by Copyscape")[![CMMI Appraised](https://www.mantratec.com/Assets/Images/CMMI.png)](https://pars.cmmiinstitute.com/appraisals/74124 "CMMI L3 Certificate")