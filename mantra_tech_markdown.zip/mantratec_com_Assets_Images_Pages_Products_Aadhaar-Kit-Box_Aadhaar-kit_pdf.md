# Biometric Technology For Aadhaar Scheme

* * *

Optical Fingerprint Sensor MFS100

Support Aadhaar Auth API
Specification V2.0

Device Securely Sign
the Biometric Data

UIDAI Certified RD Service
& PID block Encrypted
within RD Service

u Mantra MFS100 biometric ngerprint scanner is high quality USB
ngerprint biometric device for ngerprint authentication.
MFS100 is based on optical sensing technology which efficiently
recognizes poor quality ngerprints easily.

Single IRIS Sensor MIS100V2

Lowest FAR and FRR

Supports Windows, Linux and
Android Operating Systems

Mantra - a leader in Biometric provides futuristic solution through Biometric Devices for verication of an individual.

Mantra has the capability to provide Aadhaar based Biometric products. Currently our products are used in many Government
lead programs like Jeevan Pramaan , Atal Pension Yojana, Pradhaan Mantri Gramin Awaas Yojana, Pradhan Mantri Jeevan Jyoti
Bima Yojana and many more. We also provide service and maintenance support.

To acquire more information, kindly visit or Contact us
[http://www.mantratec.com](http://www.mantratec.com/) / [sales@mantratec.com](mailto:sales@mantratec.com) / Call - 079-4906 8000 (Ext:2 for sales)

Plug and play USB 2.0 high
speed interface

STQC Certified Product

u MIS100V2 is a high-quality USB IRIS Sensor that is used for Identity
authentication of an individual through IRIS. Currently, MIS100V2 is
used extensively in Aadhaar Yojana. Mantra MIS100V2 IRIS Scanner is
fast, powerful and rugged iris scanner that is implemented in various
projects and known for its accuracy and precision.