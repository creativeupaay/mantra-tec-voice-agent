# Attendance and Access Control Device

## BioNIC8

Mantra Softech is a Global Hi-Tech Manufacturer of Biometric Products and Solutions. We offer a Wide Range of Products in Biometric and RFID Industry.

* * *

# ATTENDANCE AND ACCESS CONTROL DEVICE BioNIC8

# Introduction

Mantra Bionic8 is the most advanced fingerprint and smart card reader terminal featuring next-generation biometric technology and security platform. Bionic8 provides class-leading performance through the world’s best matching performance, uncompromised security, and accuracy along with top-notch usability.

It is a wall-mounted biometric tablet with BOSS ( Bharat operating system), featuring biometric fingerprint identification, smart card reader to provide multiple functions for various customer applications. It can be deployed in a wide variety of environmental conditions. It is specifically designed for mounting on surfaces used in indoor or outdoor places. It also has an inbuilt battery that can handle long hours of intense usage along with it has IP65 water & dustproof capability and has met the IEC sealing standards.

# Features

u Rugged design; IP65 Sealing. u User Friendly design offers Intuitive User Experience; Ultrafast User Identification. u Ultrafast User Access and Higher Security u Secure eMMC boot; On board 16GB offers Higher Capacity to Manage User & Events. u In-built Secure Access Module; supporting ISO7816 compliant Contact Smart Card u Contactless Smart Card Module; supporting ISO14443 compliant Contactless Smart Card u Tamper Detection and Protected. u Battery Operated Devices with back-time of 5 hours. u Multi Finger Capacitive touch display with Scratch proof Gorilla Glass.

* * *

ATTENDANCE AND ACCESS CONTROL DEVICE BioNIC8

At a Glance

| Hardware&System | Reader cum Controller |
| --- | --- |
| CPU |  |
| Memory |  |
| Storage |  |
| Touch |  |
| LCD |  |
| Touch |  |
| Operating System |  |
| LED Indicators |  |
| Audio |  |
| RTC |  |
| Operating/Storage Temperature |  |
| Operating Humidity |  |
| Dimensions |  |
| Weight |  |
| Certifications |  |

|  | : Wall mounted smart card and biometric controller cum reader as one single Terminal |
| --- | --- |
|  | : ARM Cortex®-A7 core, 900MHz |
|  | : 1GB RAM & 16GB eMMC |
|  | : Memory Sufficient for application software to store one day data |
|  | : Scratch Resistant Multi-Point Capacitive Touch Screen with 6H Toughen Glass |
|  | : 3.5" TFT LCD with 320x480 Resolution, 500 NIT, 16-Bit RGB |
|  | : Scratch Resistant Multi-Point Capacitive Touch Screen with 6H Toughen Glass |
|  | : Linux OS |
|  | : Battery Charging Status, User Defined |
|  | : 1W, 8 Ohm Speaker for Announcements |
|  | : Yes (Coin Cell, On Board Reachargabale) |
| re | : Operating :0 Deg - 60 Deg C Storage:0 Deg - 70 Deg C |
|  | : 10%-90% RH(Non-Condensing) |
|  | : (L x W x H) 86.29 mm x 40.40 mm x 214.61 mm |
|  | : Approx 550 grams |
|  | : CE, RoHS,BIS,IP65 |

| Fingerprint Sensor | Fingerprint Type |
| --- | --- |
| Fingerprint Image |  |
| Image Specs |  |
| Certifications |  |
| Smart Card Reader | Contactless Card |
| SAM |  |

|  | :Scratch Free Optical Sensor |
| --- | --- |
|  | :316x354 Pixels(16x18mm) |
|  | :500DPI,8Bit Grayscale |
|  | :CE,FCC,RoHS,STQC,PIV,IEC60950,IS13252PartI |
|  | :ISO14443TypeA/BCards&SCOSTACardSupport,424Kbpsorotherlowerspeed,Antenna should readfrom50mmreadrange. |
|  | :ISO7816ClassA |

* * *

# ATTENDANCE AND ACCESS CONTROL DEVICE BioNIC8

# At a Glance

**Micro USB** : 4-Pin Micro USB, Through Aux Connector (Development Only) **Interfaces** : 5 Pin On Board USB Connector for Finger Print Module **USB OTG**

**Power Adaptor** : Input AC: 100~280V, 47Hz to 53Hz; Output DC: 5V/3.0A **Electrical** **Battery Back-Up** : Li-Po 4000 mAH Rechargeable & Replaceable Battery

* * *

# Support : [servico@mantratec.com](mailto:servico@mantratec.com) Sales : [sales@mantratec.com](mailto:sales@mantratec.com)